from json import decoder
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
from einops import rearrange
from einops.layers.torch import Rearrange
import torchvision.models.video as models

from impl.head_cls import GroupedConvHead, GroupedConvHeadV2

class AttentionPooling(nn.Module):
    """
    Implements a query-based attention pooling layer.
    It uses a set of learnable queries to pool a sequence of features.
    """
    def __init__(self, dim, n_output, num_heads=8, dropout=0.1):
        super().__init__()
        self.n_output = n_output
        self.dim = dim
        self.num_heads = num_heads

        # Các queries có thể học, đóng vai trò là "câu hỏi" để tổng hợp thông tin
        # Shape: (1, n_output, dim) để dễ dàng broadcast qua batch
        self.queries = nn.Parameter(torch.randn(1, n_output, dim))

        # Lớp Multi-Head Attention cốt lõi
        self.attention = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        # Các thành phần tiêu chuẩn trong một khối Transformer
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, dim]
        Returns:
            Tensor, shape [batch_size, n_output, dim]
        """
        b = x.shape[0]
        # Mở rộng queries cho toàn bộ batch
        queries = self.queries.repeat(b, 1, 1)

        # Attention: queries hỏi, x (keys, values) trả lời
        # attn_output có shape (B, n_output, D)
        attn_output, _ = self.attention(query=queries, key=x, value=x)

        # Residual connection and LayerNorm (phong cách Pre-Norm)
        queries = self.norm1(queries + attn_output)

        # Feed-Forward Network
        ffn_output = self.ffn(queries)

        # Residual connection and LayerNorm
        pooled_output = self.norm2(queries + ffn_output)

        return pooled_output

class VectorGatedShift(nn.Module):
    """
    Applies a gated temporal shift to 1D feature vectors (B, T, C).
    This is inspired by the GSF module but adapted for pre-extracted features
    without spatial dimensions.
    """
    def __init__(self, dim, n_div=4):
        super().__init__()
        self.dim = dim

        self.n_div = n_div
        self.fold_dim = dim // n_div

        # A small network to learn the gates dynamically from input
        # Using Conv1d to capture a small local temporal context (kernel_size=3)
        self.gate_network = nn.Sequential(
            nn.Conv1d(self.fold_dim * 2, self.fold_dim, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(self.fold_dim, 2, kernel_size=1), # 2 output channels for forward/backward gates
            nn.Tanh()
        )
        
        # A small network to learn the fusion weights (how to combine shifted and residual)
        self.fusion_weight_network = nn.Sequential(
            nn.Linear(self.fold_dim * 2, self.fold_dim // 2),
            nn.ReLU(),
            nn.Linear(self.fold_dim // 2, 2), # 2 weights: 1 for shifted, 1 for residual
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        # Input shape: (B, T, C) where T is n_segment
        b, t, c = x.shape
        
        # Part that remains unchanged
        unaffected_part = x[:, :, self.fold_dim * 2:]

        # Part that will be processed
        gated_part = x[:, :, :self.fold_dim * 2]

        # Learn gates from the data
        # (B, T, C) -> (B, C, T) for Conv1D
        gates = self.gate_network(gated_part.permute(0, 2, 1)).permute(0, 2, 1) # Shape: (B, T, 2)
        gate_fwd, gate_bwd = gates.chunk(2, dim=-1) # Shapes: (B, T, 1) and (B, T, 1)

        # Split into two groups for forward and backward shift
        group1, group2 = gated_part.chunk(2, dim=-1) # Shape: (B, T, fold_dim)

        # Apply gates
        gated_group1 = gate_fwd * group1
        gated_group2 = gate_bwd * group2
        
        # The residual (un-gated) part
        residual_group1 = group1 - gated_group1
        residual_group2 = group2 - gated_group2

        # Perform temporal shift
        shifted_group1 = torch.roll(gated_group1, shifts=-1, dims=1)
        shifted_group1[:, -1, :] = 0 # Zero-pad the last frame
        shifted_group2 = torch.roll(gated_group2, shifts=1, dims=1)
        shifted_group2[:, 0, :] = 0 # Zero-pad the first frame

        # Learn fusion weights
        # Weights for group 1
        weights_input1 = torch.cat([shifted_group1, residual_group1], dim=-1)
        fusion_weights1 = self.fusion_weight_network(weights_input1)
        w_shifted1, w_residual1 = fusion_weights1.chunk(2, dim=-1)
        
        # Weights for group 2
        weights_input2 = torch.cat([shifted_group2, residual_group2], dim=-1)
        fusion_weights2 = self.fusion_weight_network(weights_input2)
        w_shifted2, w_residual2 = fusion_weights2.chunk(2, dim=-1)

        # Fuse the shifted and residual parts
        fused_group1 = shifted_group1 * w_shifted1 + residual_group1 * w_residual1
        fused_group2 = shifted_group2 * w_shifted2 + residual_group2 * w_residual2
        
        # Concatenate all parts back together
        out = torch.cat([fused_group1, fused_group2, unaffected_part], dim=-1)
        return out

class DilatedConvBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        # Chồng các lớp Conv với dilation tăng theo cấp số nhân
        self.conv1 = nn.Conv1d(dim, dim, kernel_size=3, padding=1, dilation=1)
        self.conv2 = nn.Conv1d(dim, dim, kernel_size=3, padding=2, dilation=2)
        self.conv3 = nn.Conv1d(dim, dim, kernel_size=3, padding=4, dilation=4)
        self.norm = nn.BatchNorm1d(dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        # x_in -> conv1 -> conv2 -> conv3 -> x_out
        # Có thể thêm residual connection trong khối này
        x_in = x
        x = self.relu(self.norm(self.conv1(x)))
        x = self.relu(self.norm(self.conv2(x)))
        x = self.relu(self.norm(self.conv3(x)))
        return x + x_in

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 1024):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        pe_tensor = torch.as_tensor(self.pe)  # ✅ Cast để tránh lỗi type checker
        pe_slice = pe_tensor[:, :x.size(1), :].to(x.device)
        x = x + pe_slice
        return self.dropout(x)

class DilatedConvBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        # Chồng các lớp Conv với dilation tăng theo cấp số nhân
        self.conv1 = nn.Conv1d(dim, dim, kernel_size=3, padding=1, dilation=1)
        self.conv2 = nn.Conv1d(dim, dim, kernel_size=3, padding=2, dilation=2)
        self.conv3 = nn.Conv1d(dim, dim, kernel_size=3, padding=4, dilation=4)
        self.norm = nn.BatchNorm1d(dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        # x_in -> conv1 -> conv2 -> conv3 -> x_out
        # Có thể thêm residual connection trong khối này
        x_in = x
        x = self.relu(self.norm(self.conv1(x)))
        x = self.relu(self.norm(self.conv2(x)))
        x = self.relu(self.norm(self.conv3(x)))
        return x + x_in

class ConvRefinementHead(nn.Module):
    """
    Sử dụng Conv1d để tinh chỉnh các feature đầu ra của decoder
    dựa trên ngữ cảnh cục bộ trước khi phân loại.
    """
    def __init__(self, 
                 embed_dim=512, 
                 hidden_channels=512, 
                 num_groups=2):
        super().__init__()
        # Để sử dụng grouped convolutions, số kênh vào và ra phải chia hết cho số nhóm
        if embed_dim % num_groups != 0 or hidden_channels % num_groups != 0:
            raise ValueError("embed_dim và hidden_channels phải chia hết cho num_groups.")

        # --- Layer 1: Trích xuất đặc trưng ngữ cảnh với kernel=3 ---
        self.conv_k3 = nn.Conv1d(
            in_channels=embed_dim,
            out_channels=hidden_channels,
            kernel_size=3,
            groups=num_groups,
            padding=1,
            bias=False
        )
        self.norm = nn.BatchNorm1d(hidden_channels) # Hoặc LayerNorm
        self.activation = nn.ReLU()
        
        # --- Layer 2: Chiếu trở lại chiều embedding gốc với kernel=1 ---
        # Lớp này trộn thông tin và đảm bảo chiều đầu ra đúng.
        self.conv_k1 = nn.Conv1d(
            in_channels=hidden_channels,
            out_channels=embed_dim, # QUAN TRỌNG: Chiếu trở lại embed_dim
            kernel_size=1,
            groups=1
        )

    def forward(self, x):
        # Input x shape: (B, n_output, D)
        
        # Conv1d cần (B, D, n_output)
        x = x.permute(0, 2, 1)
        
        # Áp dụng các lớp
        x = self.conv_k3(x)
        x = self.norm(x)
        x = self.activation(x)
        x = self.conv_k1(x)
        
        # Trả về định dạng ban đầu (B, n_output, D)
        x = x.permute(0, 2, 1)
        
        return x

class ASTRAQ(nn.Module):
    """
    ASTRAQ model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg

        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048, 768]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'], max_len= self.n_output)
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096)
            self.vggish_embeddings[4] = nn.Linear(4096, model_cfg['dim'])
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])

        #Transformer decoder
        if model_cfg['queries'] is not None:
            print("=> loading queries '{}'".format(model_cfg['queries']))
            self.queries = nn.Parameter(torch.from_numpy(np.load(model_cfg['queries'])).float(), requires_grad = True)
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
            
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])

        
        self.fusion_layer = nn.Linear(model_cfg['dim'] * 2, model_cfg['dim'])
        
        self.residual_transform = nn.Sequential(
            # Chuyển từ (B, L, D) -> (B, D, L) cho Conv1D
            Rearrange('b l d -> b d l'),
            DilatedConvBlock(model_cfg['dim']),
            # Chuyển ngược lại (B, D, L) -> (B, L, D) cho Attention Pooling
            Rearrange('b d l -> b l d'),
            # Áp dụng Attention Pooling để tổng hợp chuỗi thành n_output vector
            AttentionPooling(
                dim=model_cfg['dim'],
                n_output=self.n_output,
                num_heads=model_cfg.get('nhead', 8)
            )
        )
        
        #Prediction heads
        self.clas_head = GroupedConvHead()

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = GroupedConvHead()


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 512))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        b= 0
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        if self.audio and featsA is not None:
            featsA = featsA.float()
            if b == 0: # Chỉ gán nếu chưa được gán từ video
                b = featsA.shape[0]

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach() 

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()

        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)
        processed_feats = []
        #Baidu features
        if self.baidu:

            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            featsB = self.video_pos_encoder(rearrange(featsB, 'l b cs d -> (l b) cs d'))
            featsB = rearrange(featsB, '(l b) cs d -> l b cs d', l=l)
            
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')
            processed_feats.append(featsB)
        #Audio features
        if self.audio and featsA is not None:
            # (Bạn có thể thêm Augmentation cho Audio ở đây nếu muốn)
            # VGGish backbone
            fA = featsA.shape[1] // 96 # number of 0.96s segments
            featsA_seg = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA)
            with torch.no_grad(): # Thường thì backbone audio được giữ cố định
                 featsA_vgg = self.vggish_features(featsA_seg)
            featsA_vgg = featsA_vgg.flatten(1)
            featsA_embed = self.vggish_embeddings(featsA_vgg)
            
            # Positional and Modality Encoding
            featsA_processed = rearrange(featsA_embed, '(b f) d -> b f d', f = fA)
            featsA_processed = featsA_processed + self.encTA.expand(b, -1, -1)[:, :fA, :] # Positional
            featsA_processed = featsA_processed + self.encA.expand(b, fA, -1) # Modality
            processed_feats.append(featsA_processed)
            
        x = torch.cat(processed_feats, dim=1)
        x_residual = x.clone()
        nB = featsB.shape[1]
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):

            current_seq_len = x.shape[1]
            
            if splits[i] == 1 or current_seq_len < splits[i]: # Nếu không đủ dài để chia, chạy global
                x = mod(x)

            #hierarchical attention layers (i.e. split > 1 - split in segments)
            else: 
                # Tính toán kích thước các đoạn
                segment_len = current_seq_len // splits[i]
                num_segments = splits[i]
                
                # Chia thành các đoạn
                segments = list(torch.split(x, segment_len, dim=1))
                
                # Xử lý các đoạn có đủ độ dài
                main_segments = torch.cat(segments[:-1], dim=0) # Shape: ((ns-1)*b, ls, d)
                main_segments = mod(main_segments)
                
                # Xử lý đoạn cuối (có thể ngắn hơn)
                last_segment = segments[-1]
                last_segment = mod(last_segment)
                
                # Ghép lại
                processed_main = rearrange(main_segments, '(ns b) ls d -> b (ns ls) d', ns=num_segments-1)
                x = torch.cat((processed_main, last_segment), dim=1)
        
        # x  += x_residual # Residual connection after TE
        
        #Transformer decoder
        queries = self.queries.expand((b, -1, -1)).cuda()
        decoder_output = self.Tdecoder(queries, x)
        ### Có nên làm positional encoding cho decoder không? --- IGNORE ---
        refine_feats = self.residual_transform(x)

        decoder_output = torch.cat([decoder_output,refine_feats], dim = -1) #Concatenate decoder output with residual features
        decoder_output = self.fusion_layer(decoder_output)
        
        #Classification head
        y1 = self.clas_head(decoder_output)
        y2 = self.displ_head(decoder_output)

        output = dict()
        output['preds'] = y1
        output['predsD'] = y2
        output['labels'] = labels
        output['labelsD'] = labelsD

        return output



class TimeSASTRA(nn.Module):
    """
    ASTRA model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg

        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [768] #2048, 2048, 384, 2048, 2048, 
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            self.gated_shift_modules = nn.ModuleList([
                VectorGatedShift(dim=model_cfg['dim'], n_div=8)
                for _ in range(len(self.Bfeat_dim))
            ])
            
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'], max_len= self.n_output)
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096)
            self.vggish_embeddings[4] = nn.Linear(4096, model_cfg['dim'])
            # self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            # self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish
            
            self.audio_temporal_align = nn.Sequential(
                Rearrange('b f d -> b d f'),
                nn.AdaptiveAvgPool1d(self.chunk_size), # Đưa về cùng chiều dài chunk_size
                Rearrange('b d cs -> b cs d')
            )
        self.modality_enc = nn.Parameter(torch.rand(1, model_cfg['dim']))
        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model
    
        self.encoder_layers = nn.ModuleList()
        num_layers = model_cfg.get('TE_layers', 8)
        dim = model_cfg.get('dim', 512)
        num_heads = model_cfg.get('nhead', 8)
        
        for _ in range(num_layers):
            self.encoder_layers.append(
                nn.TransformerEncoderLayer(
                    d_model=dim,
                    nhead=num_heads,
                    dim_feedforward=dim * 4,
                    dropout= 0.1,
                    batch_first=True
                )
            )
        
        
        #Transformer decoder
        if model_cfg['queries'] is not None:
            print("=> loading queries '{}'".format(model_cfg['queries']))
            self.queries = nn.Parameter(torch.from_numpy(np.load(model_cfg['queries'])).float(), requires_grad = True)
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model=model_cfg['dim'], nhead=8, dim_feedforward=model_cfg['dim'] * 4, batch_first=True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])

        self.residual_transform = nn.Sequential(
            DilatedConvBlock(model_cfg['dim']),
            nn.AdaptiveAvgPool1d(self.n_output)
        )
        self.fusion_layer = nn.Linear(model_cfg['dim'] * 2, model_cfg['dim'])
        #Prediction heads
        self.clas_head = GroupedConvHead(input_dim = model_cfg['dim'], hidden_channels = model_cfg['dim']//2)

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = GroupedConvHead()


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 512))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)

        if self.audio and featsA is not None:
            featsA = featsA.float()
            #log mel spectrogram
            featsA = rearrange(featsA, 'b f h -> b f h')

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()

        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)


        # Baidu features
        # if self.baidu:
        #     if self.model_cfg.get('feature_augmentation', False) and not inference:
        #         featsB = self.temporal_dropB(featsB)
        #         featsB = self.random_switch(featsB)
            
        #     # PFFN
        #     # featsB có shape (b, cs, total_feat_dim)
        #     featsB_list = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
        #     shifted_feats_list = [self.gated_shift_modules[i](featsB_list[i]) for i in range(len(featsB_list))]

        #     # Stack các feature lại
        #     x_grid  = torch.stack(shifted_feats_list, dim=2)  # Shape: (b, cs, num_features, d) -> (8, 50, 5, 512)
        #     x_grid = x_grid + self.video_pos_encoder.pe[:, :self.chunk_size, :].unsqueeze(2)
        
        
        all_streams = []
        visual_stream_count = 0
        audio_stream_count = 0

        # --- 1. Xử lý Visual ---
        if self.baidu and featsB is not None:
            # (Augmentation)
            featsB_list = [self.baidu_LL[i](featsB[:, :, int(sum(self.Bfeat_dim[:i])):int(sum(self.Bfeat_dim[:i+1]))]) for i in range(len(self.Bfeat_dim))]
            shifted_feats_list = [self.gated_shift_modules[i](featsB_list[i]) for i in range(len(featsB_list))]
            all_streams.extend(shifted_feats_list)
            visual_stream_count = len(shifted_feats_list)
        # --- 2. Xử lý Audio ---
        if self.audio and featsA is not None:
            # (Augmentation)
            # VGGish backbone
            fA = featsA.shape[1] // 96
            featsA_seg = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f=fA)
            with torch.no_grad():
                featsA_vgg = self.vggish_features(featsA_seg)
            featsA_embed = self.vggish_embeddings(featsA_vgg.flatten(1))
            featsA_processed = rearrange(featsA_embed, '(b f) d -> b f d', f=fA)

            # ✅ [THỎA HIỆP] Căn chỉnh độ dài thời gian trước khi làm gì khác
            aligned_audio_feats = self.audio_temporal_align(featsA_processed)
            all_streams.append(aligned_audio_feats)
            audio_stream_count = 1
        # Xếp chồng các luồng (giờ đã có cùng chiều dài T) để tạo lưới
        x_grid = torch.stack(all_streams, dim=2)  # Shape: (B, T, M, D)
        
        # Thêm positional encoding cho chiều thời gian
        x_grid = x_grid + self.video_pos_encoder.pe[:, :x_grid.shape[1], :].unsqueeze(2) # Sửa lỗi cũ
        
        # ✅ Thêm modality encoding một cách an toàn
        if self.modality_enc is not None:
            active_modality_enc = self.modality_enc[:visual_stream_count + audio_stream_count]
            x_grid = x_grid + active_modality_enc

        
        # ✅ Áp dụng Timesformer Encoder hai trục
        num_features = x_grid.shape[2]
        temporal_len = x_grid.shape[1]

        for i, layer in enumerate(self.encoder_layers):
            # Mỗi lớp TransformerEncoderLayer sẽ xử lý một chuỗi (B_new, L, D)
            # Do đó chúng ta cần reshape trước mỗi lần attention

            # 1. Temporal Attention
            # Reshape để trục thời gian (T) là trục sequence
            # (B, T, M, D) -> (B*M, T, D)
            x_for_temporal = rearrange(x_grid, 'b t m d -> (b m) t d')
            x_after_temporal = layer(x_for_temporal) # Áp dụng lớp Transformer
            x_grid = rearrange(x_after_temporal, '(b m) t d -> b t m d', m=num_features)
            
            # 2. Feature-wise Attention (trong cùng một lớp, đây là một biến thể)
            # Chúng ta có thể dùng cùng một lớp TransformerEncoderLayer hoặc một lớp khác
            # Reshape để trục feature (M) là trục sequence
            # (B, T, M, D) -> (B*T, M, D)
            x_for_feature = rearrange(x_grid, 'b t m d -> (b t) m d')
            x_after_feature = layer(x_for_feature) # Áp dụng lại cùng lớp Transformer
            x_grid = rearrange(x_after_feature, '(b t) m d -> b t m d', t= temporal_len) # chunksize
            
        x_encoded_flat = rearrange(x_grid, 'b t m d -> b (t m) d')
        # --- Transformer decoder ---
        # Logic decoder giữ nguyên, nhưng nó sẽ hoạt động với tensor có số chiều và độ dài khác
        queries = self.queries.expand((b, -1, -1)).to(x_encoded_flat.device)
        decoder_output = self.Tdecoder(queries, x_encoded_flat)

        refine_feats = x_encoded_flat.permute(0, 2, 1)
        refine_feats = self.residual_transform(refine_feats)
        refine_residual_feats = refine_feats.permute(0, 2, 1)
        #Apdatation with only for resize window 
        # decoder_output = F.adaptive_avg_pool1d(
        #     decoder_output.transpose(1, 2), output_size=128
        # ).transpose(1, 2) 
        decoder_output = torch.cat([decoder_output,refine_residual_feats], dim = -1) #Concatenate decoder output with residual features
        decoder_output = self.fusion_layer(decoder_output)
    
        #Classification head
        y1 = self.clas_head(decoder_output)
        y2 = self.displ_head(decoder_output)

        output = dict()
        output['preds'] = y1
        output['predsD'] = y2
        output['labels'] = labels
        output['labelsD'] = labelsD

        return output

# class pred_head(nn.Module):
#     """
#     Standard prediction head
#     """
#     def __init__(self, input_dim, output_dim, sigmoid = True, drop = 0.2):
#         super().__init__()
#         self.head = nn.Sequential(
#             nn.Dropout(drop),
#             nn.Linear(input_dim, input_dim),
#             nn.ReLU(),
#             nn.Dropout(drop),
#             nn.Linear(input_dim, output_dim)
#         )
#         if sigmoid:
#             self.head.add_module('sigmoid', nn.Sigmoid())

#     def forward(self, x: torch.Tensor):
#         return self.head(x) 


    
class uncertainty_head(nn.Module):
    """
    Uncertainty-aware prediction head
    """
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.shared_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),    
            nn.ReLU()
        )
        self.mean_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )
        self.logvar_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )

    def forward(self, x: torch.Tensor):

        x = self.shared_head(x)
        mean = self.mean_head(x)
        logvar = self.logvar_head(x)
        x = torch.stack((mean, logvar), dim = 3)
        return x

class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU()
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        self.n_queues = 2
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        idxnq = torch.randint(0, self.n_queues, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 512):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        mask = torch.rand(x_aux.shape[1]) < self.p
        x_aux[:, mask] = self.embedding
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        idxs = torch.arange(x_aux.shape[1]-1)[torch.rand(x_aux.shape[1]-1) < self.p]
        x_aux[:, idxs, :], x_aux[:, idxs+1, :] = x_aux[:, idxs+1, :], x_aux[:, idxs, :]
        return x_aux


# self.residual_transform = nn.Sequential(
#     GatedDilatedConvBlock(model_cfg['dim'], kernel_size=3, dilation=1),
#     GatedDilatedConvBlock(model_cfg['dim'], kernel_size=3, dilation=2),
#     GatedDilatedConvBlock(model_cfg['dim'], kernel_size=3, dilation=4),
#     nn.AdaptiveAvgPool1d(self.n_output) # Lưu ý: AdaptiveAvgPool1d nhận đầu vào (B, D, T)
# )

class GatedDilatedConvBlock(nn.Module):
    def __init__(self, dim, kernel_size=5, dilation=1):
        super().__init__()
        padding = (kernel_size - 1) * dilation // 2

        self.conv_features = nn.Conv1d(
            dim, dim, kernel_size=kernel_size, padding=padding, dilation=dilation
        )
        self.conv_gate = nn.Conv1d(
            dim, dim, kernel_size=kernel_size, padding=padding, dilation=dilation
        )
        # BatchNorm1d hoạt động trên channel (dim), nên nó phù hợp với input (B, D, T)
        self.norm = nn.BatchNorm1d(dim)
        self.activation = nn.ReLU()

    def forward(self, x):
        # x có shape (B, D, T)
        x_in = x
        
        features = self.conv_features(x)
        gate = self.conv_gate(x)
        
        gated_features = self.activation(features) * torch.sigmoid(gate)
        
        # Norm và residual connection
        output = self.norm(gated_features)
        return output + x_in


class TemporalConvModule(nn.Module):
    """
    A simple 1D Convolutional module to capture local temporal patterns.
    This is inspired by the Convolutional module in the Conformer architecture.
    """
    def __init__(self, embed_dim, kernel_size=3, dropout=0.1):
        super().__init__()
        # Ensures that the sequence length remains the same
        padding = (kernel_size - 1) // 2 
        
        self.layer_norm = nn.LayerNorm(embed_dim)
        self.conv = nn.Sequential(
            # Conv1D expects (Batch, Channels, Length) = (B, D, T)
            nn.Conv1d(embed_dim, embed_dim * 2, kernel_size=kernel_size, padding=padding),
            nn.ReLU(),
            nn.Conv1d(embed_dim * 2, embed_dim, kernel_size=1), # Pointwise conv to project back
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        """
        Input x has shape (Batch, Time, Dim)
        """
        # Apply layer norm before conv
        x_norm = self.layer_norm(x)
        
        # Permute to (B, D, T) for Conv1D
        x_permuted = x_norm.permute(0, 2, 1)
        
        # Apply convolution
        conv_output = self.conv(x_permuted)
        
        # Permute back to (B, T, D)
        conv_output = conv_output.permute(0, 2, 1)
        
        # Return with a residual connection
        return self.dropout(conv_output)


class ASTRAQA(nn.Module):
    """
    ASTRAQ model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg

        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048, 768]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'], max_len= self.n_output)
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096)
            self.vggish_embeddings[4] = nn.Linear(4096, model_cfg['dim'])
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])

        #Transformer decoder
        if model_cfg['queries'] is not None:
            print("=> loading queries '{}'".format(model_cfg['queries']))
            self.queries = nn.Parameter(torch.from_numpy(np.load(model_cfg['queries'])).float(), requires_grad = True)
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
            
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])


        self.fusion_layer = nn.Linear(model_cfg['dim'] * 2, model_cfg['dim'])

        self.residual_transform = nn.Sequential(
            # Chuyển từ (B, L, D) -> (B, D, L) cho Conv1D
            Rearrange('b l d -> b d l'),
            DilatedConvBlock(model_cfg['dim']),
            # Chuyển ngược lại (B, D, L) -> (B, L, D) cho Attention Pooling
            Rearrange('b d l -> b l d'),
            # Áp dụng Attention Pooling để tổng hợp chuỗi thành n_output vector
            AttentionPooling(
                dim=model_cfg['dim'],
                n_output=self.n_output,
                num_heads=model_cfg.get('nhead', 8)
            )
        )
        
        #Prediction heads
        self.refinement_head = ConvRefinementHead(
            embed_dim=model_cfg['dim'],
            hidden_channels=model_cfg['dim']//2, # Có thể điều chỉnh
            num_groups=2 # Có thể điều chỉnh
        )
        embed_path = model_cfg['class_embeddings_cls']
        
        print(f"=> Loading precomputed class embeddings from: '{embed_path}'")
        
        # Bước 1: Tải file numpy
        class_embeds_numpy = np.load(embed_path)
        class_embeds_tensor = torch.from_numpy(class_embeds_numpy).float()
        self.register_buffer('class_embeddings', class_embeds_tensor)
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

        self.classifier = GroupedConvHeadV2(
            input_dim=model_cfg['dim'], # Ví dụ: 512
            num_classes=model_cfg['num_classes'] + 1, # Ví dụ: 18
            hidden_channels=256, # Chiều trung gian, có thể điều chỉnh
            num_groups=2,
            num_attn_heads=8,
            dropout_p=model_cfg['dropout']
        )
        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = GroupedConvHead()


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 9344))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        b= 0
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        if self.audio and featsA is not None:
            featsA = featsA.float()
            if b == 0: # Chỉ gán nếu chưa được gán từ video
                b = featsA.shape[0]

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach() 

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()

        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)
        processed_feats = []
        #Baidu features
        if self.baidu:

            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            featsB = self.video_pos_encoder(rearrange(featsB, 'l b cs d -> (l b) cs d'))
            featsB = rearrange(featsB, '(l b) cs d -> l b cs d', l=l)
            
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')
            processed_feats.append(featsB)
        #Audio features
        if self.audio and featsA is not None:
            # (Bạn có thể thêm Augmentation cho Audio ở đây nếu muốn)
            # VGGish backbone
            fA = featsA.shape[1] // 96 # number of 0.96s segments
            featsA_seg = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA)
            with torch.no_grad(): # Thường thì backbone audio được giữ cố định
                 featsA_vgg = self.vggish_features(featsA_seg)
            featsA_vgg = featsA_vgg.flatten(1)
            featsA_embed = self.vggish_embeddings(featsA_vgg)
            
            # Positional and Modality Encoding
            featsA_processed = rearrange(featsA_embed, '(b f) d -> b f d', f = fA)
            featsA_processed = featsA_processed + self.encTA.expand(b, -1, -1)[:, :fA, :] # Positional
            featsA_processed = featsA_processed + self.encA.expand(b, fA, -1) # Modality
            processed_feats.append(featsA_processed)
            
        x = torch.cat(processed_feats, dim=1)
        x_residual = x.clone()
        nB = featsB.shape[1]
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):

            current_seq_len = x.shape[1]
            
            if splits[i] == 1 or current_seq_len < splits[i]: # Nếu không đủ dài để chia, chạy global
                x = mod(x)

            #hierarchical attention layers (i.e. split > 1 - split in segments)
            else: 
                # Tính toán kích thước các đoạn
                segment_len = current_seq_len // splits[i]
                num_segments = splits[i]
                
                # Chia thành các đoạn
                segments = list(torch.split(x, segment_len, dim=1))
                
                # Xử lý các đoạn có đủ độ dài
                main_segments = torch.cat(segments[:-1], dim=0) # Shape: ((ns-1)*b, ls, d)
                main_segments = mod(main_segments)
                
                # Xử lý đoạn cuối (có thể ngắn hơn)
                last_segment = segments[-1]
                last_segment = mod(last_segment)
                
                # Ghép lại
                processed_main = rearrange(main_segments, '(ns b) ls d -> b (ns ls) d', ns=num_segments-1)
                x = torch.cat((processed_main, last_segment), dim=1)
        
        x  += x_residual # Residual connection after TE
        
        #Transformer decoder
        queries = self.queries.expand((b, -1, -1)).cuda()
        decoder_output = self.Tdecoder(queries, x)
        ### Có nên làm positional encoding cho decoder không? --- IGNORE ---
        refine_feats = self.residual_transform(x)

        # decoder_output = decoder_output + refine_feats #Concatenate decoder output with residual features
        decoder_output = torch.cat([decoder_output, refine_feats], dim = -1) #Concatenate decoder output with residual features
        decoder_output = self.fusion_layer(decoder_output)
        
        
        #Classification head
        y1 = self.classifier(decoder_output, self.class_embeddings)
        y2 = self.displ_head(decoder_output)

        output = dict()
        output['preds'] = y1
        output['predsD'] = y2
        output['labels'] = labels
        output['labelsD'] = labelsD

        return output
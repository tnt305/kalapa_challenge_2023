import srt
import re
import math
import numpy as np
import torch
import torchvision.transforms as T
from decord import VideoReader, cpu
from PIL import Image
from torchvision.transforms.functional import InterpolationMode
from datetime import timedelta
from typing import List


def chunk_subtitles(srt_file, chunk_size=5, overlap=0):
    # Đọc nội dung file SRT
    with open(srt_file, "r", encoding="utf-8") as f:
        subs = list(srt.parse(f.read()))

    chunks = []
    stride = chunk_size - overlap
    if stride <= 0:
        raise ValueError("overlap must be smaller than chunk_size")

    for i in range(0, len(subs), stride):
        group = subs[i:i+chunk_size]
        if not group:
            break

        # Gom text lại
        text = " ".join([s.content.replace("\n", " ") for s in group])

        # Lấy thời gian bắt đầu và kết thúc
        start_time = group[0].start
        end_time = group[-1].end

        chunks.append({
            "chunk_id": len(chunks) + 1,
            "start": str(start_time),
            "end": str(end_time),
            "text": text
        })

        # Nếu đã tới cuối thì dừng
        if i + chunk_size >= len(subs):
            break

    return chunks


def text_cleaner(text: str) -> str:
    # Loại bỏ ** và *
    text = re.sub(r"\*+", "", text)
    # Loại bỏ các ký tự xuống dòng
    text = re.sub(r"\n+", " ", text)
    # Loại bỏ double whitespace
    text = re.sub(r"\s{2,}", " ", text)
    # Loại bỏ whitespace ở đầu và cuối
    text = text.strip()
    return text

################ Video Utility ################
################ Subtitle Utility ################
def chunk_subtitles(srt_file, chunk_size=5, overlap=0):
    """Chia nhỏ subtitle thành các đoạn, có thể chồng lấn."""
    with open(srt_file, "r", encoding="utf-8") as f:
        subs = list(srt.parse(f.read()))

    chunks = []
    stride = chunk_size - overlap
    if stride <= 0:
        raise ValueError("overlap must be smaller than chunk_size")

    for i in range(0, len(subs), stride):
        group = subs[i:i+chunk_size]
        if not group:
            break

        text = " ".join([s.content.replace("\n", " ") for s in group])
        start_time = group[0].start
        end_time = group[-1].end

        chunks.append({
            "chunk_id": len(chunks) + 1,
            "start": str(start_time),
            "end": str(end_time),
            "text": text
        })

        if i + chunk_size >= len(subs):
            break

    return chunks


def text_cleaner(text: str) -> str:
    """Làm sạch subtitle text."""
    text = re.sub(r"\*+", "", text)          # bỏ * và **
    text = re.sub(r"\n+", " ", text)         # bỏ xuống dòng
    text = re.sub(r"\s{2,}", " ", text)      # bỏ double space
    return text.strip()


################ Video Utility ################
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

def parse_timestamp(ts: str) -> float:
    """HH:MM:SS.ssssss -> giây (float)."""
    h, m, s = ts.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)

def build_transform(input_size):
    """Resize + Normalize theo ImageNet chuẩn."""
    return T.Compose([
        T.Lambda(lambda img: img.convert('RGB') if img.mode != 'RGB' else img),
        T.Resize((input_size, input_size), interpolation=InterpolationMode.BICUBIC),
        T.ToTensor(),
        T.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    ])

def find_closest_aspect_ratio(aspect_ratio, target_ratios, width, height, image_size):
    """Tìm aspect ratio gần nhất để cắt tile."""
    best_ratio_diff = float('inf')
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        ratio_diff = abs(aspect_ratio - target_aspect_ratio)
        if ratio_diff < best_ratio_diff:
            best_ratio_diff = ratio_diff
            best_ratio = ratio
        elif ratio_diff == best_ratio_diff:
            if area > 0.5 * image_size * image_size * ratio[0] * ratio[1]:
                best_ratio = ratio
    return best_ratio

def dynamic_preprocess(image, min_num=1, max_num=12, image_size=448, use_thumbnail=False):
    """Cắt ảnh thành nhiều patch giữ nguyên tỉ lệ."""
    orig_width, orig_height = image.size
    aspect_ratio = orig_width / orig_height

    target_ratios = set(
        (i, j) for n in range(min_num, max_num + 1)
        for i in range(1, n + 1) for j in range(1, n + 1)
        if i * j <= max_num and i * j >= min_num
    )
    target_ratios = sorted(target_ratios, key=lambda x: x[0] * x[1])

    target_aspect_ratio = find_closest_aspect_ratio(
        aspect_ratio, target_ratios, orig_width, orig_height, image_size)

    target_width = image_size * target_aspect_ratio[0]
    target_height = image_size * target_aspect_ratio[1]
    blocks = target_aspect_ratio[0] * target_aspect_ratio[1]

    resized_img = image.resize((target_width, target_height))
    processed_images = []
    for i in range(blocks):
        box = (
            (i % (target_width // image_size)) * image_size,
            (i // (target_width // image_size)) * image_size,
            ((i % (target_width // image_size)) + 1) * image_size,
            ((i // (target_width // image_size)) + 1) * image_size
        )
        processed_images.append(resized_img.crop(box))

    if use_thumbnail and len(processed_images) != 1:
        thumbnail_img = image.resize((image_size, image_size))
        processed_images.append(thumbnail_img)
    return processed_images

def process_frame(frame_array, input_size=448, max_num=12):
    """Tiền xử lý 1 frame từ numpy -> tensor."""
    image = Image.fromarray(frame_array).convert('RGB')
    transform = build_transform(input_size=input_size)
    images = dynamic_preprocess(image, image_size=input_size, use_thumbnail=True, max_num=max_num)
    pixel_values = [transform(img) for img in images]
    return torch.stack(pixel_values)  # (N, 3, H, W)

def extract_and_preprocess(video_path, start_ts, end_ts, input_size=448, max_num=1, num_segments=16):
    """Extract frames từ video trong [start_ts, end_ts], rồi preprocess."""
    vr = VideoReader(video_path, ctx=cpu(0), num_threads=1)
    fps = float(vr.get_avg_fps())
    max_frame = len(vr) - 1

    start_sec = parse_timestamp(start_ts)
    end_sec = parse_timestamp(end_ts)

    start_idx = int(start_sec * fps)
    end_idx = min(int(end_sec * fps), max_frame)

    frame_indices = np.linspace(start_idx, end_idx, num_segments, dtype=int)

    pixel_values_list, num_patches_list = [], []
    transform = build_transform(input_size=input_size)

    for frame_index in frame_indices:
        img = Image.fromarray(vr[frame_index].asnumpy()).convert("RGB")
        tiles = dynamic_preprocess(img, image_size=input_size, use_thumbnail=True, max_num=max_num)
        pixel_values = [transform(tile) for tile in tiles]
        pixel_values = torch.stack(pixel_values)
        num_patches_list.append(pixel_values.shape[0])
        pixel_values_list.append(pixel_values)

    video_tensor = torch.cat(pixel_values_list)
    return video_tensor, num_patches_list, frame_indices

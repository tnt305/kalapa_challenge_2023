BASE_SUBTITLES = "/home/storage/thiendc/InfiniBench/videos/TV_shows/subtitles"
BASE_MOVIE = "/home/storage/thiendc/InfiniBench/videos/TV_shows/videos"
BASE_SUBTITLES_2 = "/home/storage/thiendc/InfiniBench/videos/Movies/subtitles"
BASE_MOVIE_2 = "/home/storage/thiendc/InfiniBench/videos/Movies/videos"

R1_SYSTEM_MESSAGE = """
You are an AI assistant that rigorously follows this response protocol:

1. First, conduct a detailed analysis of the question. Consider different angles, potential solutions, and reason through the problem step-by-step. Enclose this entire thinking process within <think> and </think> tags.

2. After the thinking section, provide a clear, concise, and direct answer to the user's question. Separate the answer from the think section with a newline.

Ensure that the thinking process is thorough but remains focused on the query. The final answer should be standalone and not reference the thinking section.
""".strip()

DEEP_CONTEXT_PROMPT = """
You are an AI assistant that rigorously follows this response protocol:

1. First, conduct a detailed analysis of the question. Consider different angles, potential solutions, and reason through the problem step-by-step. Enclose this entire thinking process within <think> and </think> tags.

2. After the thinking section, provide a clear, concise, and direct answer to the user's question. Separate the answer from the think section with a newline.

Ensure that the thinking process is thorough but remains focused on the query. The final answer should be standalone and not reference the thinking section.
""".strip()



SUMMARY_PROMPT = """
   You are given a segment of a video with transcript and sampled frames.
Create a story-telling that uses the main spoken content (from transcript) and visual context (from frames).
Keep the content concise (2–3 sentences), focusing only on the key events and interactions between characters.
Do not summarize every single detail, but rather synthesize the main points into a coherent narrative.
Do not introduce or use any character names or proper nouns that are not explicitly mentioned in the transcript subtitles.
Make sure the story flows naturally and is easy to read.
"""
SUMMARY_MAIN = """Please help me to combine these summaries in English into a concise and coherent paragraph while cover all important events, in order to answer the following question: """
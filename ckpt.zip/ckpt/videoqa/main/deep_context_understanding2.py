import os
import json
import pandas
from tqdm import tqdm
import re
import requests

with open("/home/thiendc/projects/iccv/long_video_understanding/results/deep_context.json", "r") as f:
    data = json.load(f)
    
question_deep_context = pandas.read_csv("/home/thiendc/projects/iccv/long_video_understanding/data_statics/deep_context_understanding.csv") 

def remove_thinking(text: str, **kwargs) -> str:
    """
    Xóa đoạn <think>...</think> và trả về phần còn lại.
    """
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    return cleaned.strip()

question_ids = []
for key, value in data.items():
    if value.startswith("<think>"):
        question_ids.append(int(key))

for key, value in data.items():
    val = str(value).lower()
    if "the provided information" in val:
        question_ids.append(int(key))
    elif "the provided conversation" in val:
        question_ids.append(int(key))
    elif "the provided dialog" in val:
        question_ids.append(int(key))
    elif "the provided text" in val:
        question_ids.append(int(key))
    elif "the provided interactions" in val:
        question_ids.append(int(key))
filtered = question_deep_context[question_deep_context['question_id'].isin(question_ids)]

# sort theo đúng thứ tự trong list question_ids
filtered_sorted = filtered.set_index("question_id").loc[question_ids].reset_index()

BASE_SUBTITLES = "/home/storage/thiendc/InfiniBench/videos/TV_shows/subtitles"
save_path = "/home/thiendc/projects/iccv/long_video_understanding/results/deep_context2.json"
API_URL = "http://localhost:23333/v1/chat/completions"
MODEL_NAME = "OpenGVLab/InternVL3_5-1B-Instruct"

def lmdeploy_generate(prompt, max_tokens=2048, temperature=0.6):
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    response = requests.post(API_URL, json=payload)
    result = response.json()
    return result["choices"][0]["message"]["content"]

results = {}
for idx, row in tqdm(filtered_sorted.iterrows(), total=len(filtered_sorted), desc="Processing deep context task"):
    question_id = row['question_id']
    question = row['question']
    subtitle_text = ""
    if row['source'] == 'tvqa':
        video_sub = row['video_subtitles']
        video_sub_path = os.path.join(BASE_SUBTITLES, video_sub)
        with open(video_sub_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        cleaned = []
        for line in lines:
            if re.match(r'^\d+$', line.strip()):  # subtitle index
                continue
            if "-->" in line:  # timestamp line
                continue
            if line.strip() == "":
                continue
            if len(line.strip().split()) > 4:
                cleaned.append(line.strip())
        subtitle_text = "\n".join(cleaned)
    prompt = (
        "Please answer the following question in English: "
        + question
        + "\nGiven the following subtitles are context information:\n"
        + subtitle_text
    )
    response = lmdeploy_generate(prompt, max_tokens=1024, temperature=0.6)
    response = remove_thinking(response)
    results[question_id] = response

    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
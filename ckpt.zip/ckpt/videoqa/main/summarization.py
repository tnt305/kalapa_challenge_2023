import os
import re
import pandas
import json
from tqdm import tqdm
os.environ['CUDA_VISIBLE_DEVICES'] = "5"
from typing import List

import torch
import transformers
from transformers import AutoModel, AutoTokenizer
from sentence_transformers import SentenceTransformer, util

from long_video_understanding.task.registry import register, run_pipeline
from long_video_understanding.utility.helper import chunk_subtitles, extract_and_preprocess
from long_video_understanding.utility.base import (
    SUMMARY_PROMPT, 
    SUMMARY_MAIN, 
    R1_SYSTEM_MESSAGE, 
    BASE_SUBTITLES, 
    BASE_SUBTITLES_2,
    BASE_MOVIE,
    BASE_MOVIE_2
)

transformers.logging.set_verbosity_error()

_qa_cache = None
@register("setup_qa_model")
def create_model(qa_model_name: str = "OpenGVLab/InternVL3_5-1B-Instruct", **kwargs):
    global _qa_cache
    if _qa_cache is None:
        qa_model = AutoModel.from_pretrained(
            qa_model_name,
            torch_dtype=torch.bfloat16,
            load_in_8bit=False,
            low_cpu_mem_usage=True,
            use_flash_attn=False,
            trust_remote_code=True).eval().to("cuda")
        qa_model.system_message = R1_SYSTEM_MESSAGE

        tokenizer = AutoTokenizer.from_pretrained(qa_model_name, trust_remote_code=True, use_fast=False)

        # Default config
        default_config = dict(
            max_new_tokens=1024,
            do_sample=True,
            temperature= 0.6,
        )
        # Override từ kwargs nếu có
        generation_config = {**default_config, **kwargs}
        _qa_cache = (qa_model, tokenizer, generation_config)
    return _qa_cache

@register("chunking_subtitles")
def chunking_subtitles(srt_file: str, chunk_size: int = 5, overlapping: int = 1, **kwargs) -> List[dict]:
    return chunk_subtitles(srt_file, chunk_size, overlapping)


@register("extract_and_preprocess_chunks")
def extract_and_preprocess_chunks(video_path, start_ts, end_ts, input_size=448, max_num=1, num_segments=16):
    return extract_and_preprocess(video_path, start_ts, end_ts, input_size, max_num, num_segments)


@register("context_understanding")
def context_understanding(
    subtitle: str,
    video_path: str,
    start_ts,
    end_ts,
    input_size=448,
    max_num=1,
    num_segments=16,
    model=None,
    tokenizer=None,
    generation_config=None,
    **kwargs
) -> List[str]:
    """
    Với 1 chunk thì lấy ra mô tả cho chunk đó
    """
    pixel_values, num_patches_list, _ = extract_and_preprocess_chunks(video_path, start_ts, end_ts, input_size, max_num, num_segments)
    
    video_prefix = ''.join([f'Frame{i+1}: <image>\n' for i in range(len(num_patches_list))])
    question = video_prefix + SUMMARY_PROMPT + "given this are transcripts: " + subtitle.strip()
    
    if model is None or tokenizer is None or generation_config is None:
        model, tokenizer, generation_config = create_model()
    pixel_values = pixel_values.to(dtype=model.dtype, device=model.device)
    
    response = model.chat(
        tokenizer, pixel_values, question, generation_config,
        num_patches_list=num_patches_list, history=None, return_history=False
    )
    
    if ("<think>" in response) and (not "</think>" in response):
        extend_thinking = dict(
            max_new_tokens=2048,
            do_sample=True,
            temperature= 0.6,
        )
        response = model.chat(
            tokenizer, pixel_values, question, extend_thinking,
            num_patches_list=num_patches_list, history=None, return_history=False
        )
    
    return response, pixel_values, num_patches_list

@register("summarization")
def generate_summary(question: str, video_path: str, srt_file: str, chunk_size: int = 5, overlapping: int = 1, **kwargs) -> List[str]:
    chunks = chunking_subtitles(srt_file, chunk_size, overlapping)
    summaries = []
    model, tokenizer, generation_config = create_model()
    for chunk in tqdm(chunks):
        start_ts, end_ts, text = chunk['start'], chunk['end'], chunk['text']
        summary, pixel_values, num_patches_list = context_understanding(
            subtitle=text,
            video_path=video_path,
            start_ts=start_ts,
            end_ts=end_ts,
            input_size=448,
            max_num=1,
            num_segments=8,
            model=model,
            tokenizer=tokenizer,
            generation_config=generation_config
        )
        summaries.append(summary)
        del pixel_values
        del num_patches_list
        torch.cuda.empty_cache()
    del model
    del tokenizer
    del generation_config
    # final_prompt = SUMMARY_MAIN + question + "\n".join([f"- {item}" for item in summaries])
    # response = model.chat(tokenizer, None, final_prompt, generation_config, history=None, return_history=False)
    # torch.cuda.empty_cache()
    return summaries

def main():
    df = pandas.read_csv("/home/thiendc/projects/iccv/long_video_understanding/data_statics/summarization.csv")
    save_path = "/home/thiendc/projects/iccv/long_video_understanding/results/summarization.json"
    results = {}
    df = df.iloc[:65]
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Processing summarization task"):
        question_id = str(row['question_id'])
        question = row['question']
        video_path = f"{BASE_MOVIE}/{row['video_path_mp4']}"
        srt_file = f"{BASE_SUBTITLES}/{row['video_subtitles']}"
        
        # Nếu không tồn tại thì đổi sang BASE_SUBTITLE2
        if not os.path.exists(video_path):
            video_path = f"{BASE_MOVIE_2}/{row['video_path_mp4']}"
        if not os.path.exists(srt_file):
            srt_file = f"{BASE_SUBTITLES_2}/{row['video_subtitles']}"
        
        chunk_size = row.get('chunk_size', 10)
        overlapping = row.get('overlapping', 2)

        answer = run_pipeline(
            [
                "setup_qa_model",
                "chunking_subtitles",
                "summarization"
            ],
            question=question,
            video_path=video_path,
            srt_file=srt_file,
            chunk_size=chunk_size,
            overlapping=overlapping
        )

        results[question_id] = answer

        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
            
if __name__ == "__main__":
    main()

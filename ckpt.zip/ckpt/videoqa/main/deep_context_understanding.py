import os
import re
import pandas
import json
from tqdm import tqdm
os.environ['CUDA_VISIBLE_DEVICES'] = "5"
from typing import List


import torch
from transformers import AutoModel, AutoTokenizer
from sentence_transformers import SentenceTransformer, util

from long_video_understanding.task.registry import register, run_pipeline
from long_video_understanding.utility.helper import chunk_subtitles, text_cleaner
from long_video_understanding.utility.base import BASE_SUBTITLES_2, DEEP_CONTEXT_PROMPT, BASE_SUBTITLES


_qa_cache = None
@register("setup_qa_model")
def create_model(qa_model_name: str = "OpenGVLab/InternVL3_5-1B-Instruct", **kwargs):
    global _qa_cache
    if _qa_cache is None:
        qa_model = AutoModel.from_pretrained(
            qa_model_name,
            torch_dtype=torch.bfloat16,
            load_in_8bit=False,
            low_cpu_mem_usage=True,
            use_flash_attn=False,
            trust_remote_code=True).eval().to("cuda")
        tokenizer = AutoTokenizer.from_pretrained(qa_model_name, trust_remote_code=True, use_fast=False)
        qa_model.system_message = DEEP_CONTEXT_PROMPT

        # Default config
        default_config = dict(
            max_new_tokens=1024,
            do_sample=True,
            temperature= 0.6,
        )
        # Override từ kwargs nếu có
        generation_config = {**default_config, **kwargs}
        _qa_cache = (qa_model, tokenizer, generation_config)
    return _qa_cache

_embedding_cache = None
@register("setup_embedding_model")
def create_embedding_model(embedding_model_name: str = "Qwen/Qwen3-Embedding-0.6B", **kwargs):
    global _embedding_cache
    if _embedding_cache is None:
        _embedding_cache = SentenceTransformer(embedding_model_name, device="cuda")
    return _embedding_cache

@register("chunking_subtitles")
def chunking_subtitles(srt_file: str, chunk_size: int = 5, **kwargs) -> List[dict]:
    return chunk_subtitles(srt_file, chunk_size)


@register("context_retrieval")
def context_retrieval(question: str, top_k: int = 3, **kwargs) -> List[str]:
    
    embedding_model = create_embedding_model()
    chunked_subtitles = chunking_subtitles(f"{BASE_SUBTITLES}/bbt/season_9/episode_5.srt", chunk_size=5)
    corpus_embeddings = embedding_model.encode([c["text"] for c in chunked_subtitles], convert_to_tensor=True)
    query_embedding = embedding_model.encode(question, convert_to_tensor=True)
    
    cos_scores = util.cos_sim(query_embedding, corpus_embeddings)[0]
    top_results = torch.topk(cos_scores, k=top_k)
    return top_results, chunked_subtitles


@register("answer_generation")
def generate_answer(question: str, **kwargs) -> str:
    question_prefix = "Based on these information:\n"
    top_results, chunks = context_retrieval(question, top_k=5)
    for _, idx in zip(top_results.values, top_results.indices):
        c = chunks[idx]
        question_prefix += f"- {c['text']}\n\n"

    question_prefix += f"Please answer the following question in English: {question}."

    qa_model, tokenizer, generation_config = create_model()
    response = qa_model.chat(tokenizer, None, question_prefix, generation_config, history=None, return_history=False)
    return str(response)


@register("remove_thinking")
def remove_thinking(text: str, **kwargs) -> str:
    """
    Xóa đoạn <think>...</think> và trả về phần còn lại.
    """
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    return cleaned.strip()

@register("cleanse")
def cleanse(text: str, **kwargs) -> str:
    return text_cleaner(text)

def main():
    df = pandas.read_csv("/home/thiendc/projects/iccv/long_video_understanding/data_statics/deep_context_understanding.csv")
    save_path = "/home/thiendc/projects/iccv/long_video_understanding/results/deep_context.json"
    results = {}
    
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Processing deep context task"):
        question_id = str(row['question_id'])
        question = row['question']
        srt_file = f"{BASE_SUBTITLES}/{row['video_subtitles']}"
        if not os.path.exists(srt_file):
            srt_file = f"{BASE_SUBTITLES_2}/{row['video_subtitles']}"
        
        answer = None
        found_think = False

        max_new_tokens_list = [1024, 2048, 3072, 4096]
        temperature = 0.6
        chunk_size = 5

        for _, max_new_tokens in enumerate(max_new_tokens_list):
            try:
                # Chỉ lấy kết quả từ answer_generation để kiểm tra </think>
                answer_raw = run_pipeline(
                    [
                        "setup_qa_model",
                        "setup_embedding_model",
                        "chunking_subtitles",
                        "context_retrieval",
                        "answer_generation"
                    ],
                    question=question,
                    srt_file=srt_file,
                    top_k=3,
                    max_new_tokens=max_new_tokens,
                    temperature=temperature,
                    chunk_size=chunk_size
                )
                if "</think>" in answer_raw:
                    found_think = True
                    # Sau khi kiểm tra, tiếp tục qua các bước làm sạch
                    answer = run_pipeline(
                        [
                            "remove_thinking",
                            "cleanse"
                        ],
                        text=answer_raw
                    )
                    break
            except Exception as e:
                answer = f"Error: {e}"
                break

        # Nếu sau 4 lần vẫn không có </think>, thử lại với cấu hình đặc biệt
        if not found_think:
            try:
                answer_raw = run_pipeline(
                    [
                        "setup_qa_model",
                        "setup_embedding_model",
                        "chunking_subtitles",
                        "context_retrieval",
                        "answer_generation"
                    ],
                    question=question,
                    srt_file=srt_file,
                    top_k=3,
                    max_new_tokens=1024,
                    temperature=0.8,
                    chunk_size=chunk_size
                )
                answer = run_pipeline(
                    [
                        "remove_thinking",
                        "cleanse"
                    ],
                    text=answer_raw
                )
            except Exception as e:
                answer = f"Error: {e}"

        if isinstance(answer, str) and answer.strip().lower().startswith("the provided"):
            try:
                answer_raw = run_pipeline(
                    [
                        "setup_qa_model",
                        "setup_embedding_model",
                        "chunking_subtitles",
                        "context_retrieval",
                        "answer_generation"
                    ],
                    question=question,
                    srt_file=srt_file,
                    top_k=5,
                    max_new_tokens=1024,
                    temperature=0.6,
                    chunk_size=7
                )
                answer = run_pipeline(
                    [
                        "remove_thinking",
                        "cleanse"
                    ],
                    text=answer_raw
                )
            except Exception as e:
                answer = f"Error: {e}"
        
        results[question_id] = answer

        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
from tqdm import tqdm
import json
import re
import os
import ast
from tqdm import tqdm
import requests
import pandas

BASE_SUBTITLES = "/home/storage/thiendc/InfiniBench/videos/TV_shows/subtitles"
BASE_SUBTITLES_2 = "/home/storage/thiendc/InfiniBench/videos/Movies/subtitles"
save_path = "/home/thiendc/projects/iccv/long_video_understanding/results/linking_multiple_events.json"
API_URL = "http://localhost:30305/v1/chat/completions"
MODEL_NAME = "OpenGVLab/InternVL3_5-1B-Instruct"

def lmdeploy_generate(prompt, max_tokens=2048, temperature=0.6):
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    response = requests.post(API_URL, json=payload)
    result = response.json()
    return result["choices"][0]["message"]["content"]

def remove_thinking(text: str, **kwargs) -> str:
    """
    Xóa đoạn <think>...</think> và trả về phần còn lại.
    """
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    return cleaned.strip()

if os.path.exists(save_path):
    with open(save_path, "r", encoding="utf-8") as f:
        results = json.load(f)
else:
    results = {}
linking_multiple_events = pandas.read_csv("/home/thiendc/projects/iccv/long_video_understanding/data_statics/linking_multiple_events.csv")
for idx, row in tqdm(linking_multiple_events.iterrows(), total=len(linking_multiple_events), desc="Processing linking_multiple_events task"):
    question_id = row['question_id']
    question = row['question']
    video_sub = row['video_subtitles']


    if row['source'] == 'tvqa':
        video_sub_path = os.path.join(BASE_SUBTITLES, video_sub)
    else:
        video_sub_path = os.path.join(BASE_SUBTITLES_2, video_sub)
    
    if not os.path.exists(video_sub_path): 
        video_sub_path = f"{BASE_SUBTITLES_2}{video_sub}"
        if not os.path.exists(video_sub_path):
            video_sub_path = f"{BASE_SUBTITLES}{video_sub}"
    with open(video_sub_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    cleaned = []
    for line in lines:
        if re.match(r'^\d+$', line.strip()):  # subtitle index
            continue
        if "-->" in line:  # timestamp line
            continue
        if line.strip() == "":
            continue
        if len(line.strip().split()) > 3:
            cleaned.append(line.strip())
    
    subtitle_text = "\n".join(cleaned)
    # options_text = format_options(row['options'])
    
    prompt = (
        "Please answer the following question in English.\n"
        f"Question: {question}\n"
        "Given the following subtitles as contextual information:\n"
        f"{subtitle_text}\n"
        "focus on the character and their action to analyze the situation, then provide a concise answer.\n"
    )
    
    response = lmdeploy_generate(prompt, max_tokens=1024, temperature=0.6)
    response = remove_thinking(response)
    results[question_id] = response

    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
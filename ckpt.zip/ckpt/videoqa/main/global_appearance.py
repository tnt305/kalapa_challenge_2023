from tqdm import tqdm
import json
import re
import os
import ast
from tqdm import tqdm
import requests
import pandas

BASE_SUBTITLES = "/home/storage/thiendc/InfiniBench/videos/TV_shows/subtitles"
BASE_SUBTITLES_2 = "/home/storage/thiendc/InfiniBench/videos/Movies/subtitles"
save_path = "/home/thiendc/projects/iccv/long_video_understanding/results/global_appearance.json"
API_URL = "http://localhost:23333/v1/chat/completions"
MODEL_NAME = "OpenGVLab/InternVL3_5-1B-Instruct"

def lmdeploy_generate(prompt, max_tokens=2048, temperature=0.6):
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    response = requests.post(API_URL, json=payload)
    result = response.json()
    return result["choices"][0]["message"]["content"]

def remove_thinking(text: str, **kwargs) -> str:
    """
    Xóa đoạn <think>...</think> và trả về phần còn lại.
    """
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    return cleaned.strip()

def format_options(options):
    # Nếu options là chuỗi biểu diễn list, chuyển sang list bằng ast.literal_eval
    if isinstance(options, str):
        try:
            options = ast.literal_eval(options)
        except Exception:
            options = [options]

    # Đánh số A/B/C/D... cho từng phần tử ngoài cùng
    formatted = []
    for i, opt in enumerate(options):
        if isinstance(opt, list):
            opt_str = ", ".join(opt)
        else:
            opt_str = str(opt)
        formatted.append(f"{chr(65+i)}. {opt_str}")
    return "\n".join(formatted)

results = {}
global_appearance = pandas.read_csv("/home/thiendc/projects/iccv/long_video_understanding/data_statics/global_appearance.csv")
for idx, row in tqdm(global_appearance.iterrows(), total=len(global_appearance), desc="Processing global qa task"):
    question_id = row['question_id']
    question = row['question']
    video_sub = row['video_subtitles']
    if row['source'] == 'tvqa':
        video_sub_path = os.path.join(BASE_SUBTITLES, video_sub)
    else:
        video_sub_path = os.path.join(BASE_SUBTITLES_2, video_sub)

    with open(video_sub_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    cleaned = []
    for line in lines:
        if re.match(r'^\d+$', line.strip()):  # subtitle index
            continue
        if "-->" in line:  # timestamp line
            continue
        if line.strip() == "":
            continue
        if len(line.strip().split()) > 4:
            cleaned.append(line.strip())

    subtitle_text = "\n".join(cleaned)
    options_text = format_options(row['options'])
    
    prompt = (
        "Please answer the following multiple choice question in English.\n"
        f"Question: {question}\n"
        f"Choices:\n{options_text}\n"
        "Given the following subtitles as context information:\n"
        f"{subtitle_text}\n"
        "Reply with the letter of the correct answer (A, B, C, D or E if exists)."
    )
    
    response = lmdeploy_generate(prompt, max_tokens=2048, temperature=0.6)
    response = remove_thinking(response)
    results[question_id] = response

    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
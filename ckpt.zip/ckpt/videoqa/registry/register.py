from typing import Callable, Dict, Any
import inspect

# Registry lưu tất cả subtasks
TASK_REGISTRY: Dict[str, Callable] = {}

def register(name: str):
    """Decorator để đăng ký sub_task vào TASK_REGISTRY."""
    def decorator(func: Callable) -> Callable:
        TASK_REGISTRY[name] = func
        return func
    return decorator


def run_pipeline(pipeline, **kwargs):
    data = dict(kwargs)  # copy để không thay đổi kwargs gốc
    result = None

    for name in pipeline:
        func = TASK_REGISTRY[name]
        sig = inspect.signature(func)

        # Lọc ra các arg hợp lệ cho func hiện tại
        valid_args = {k: v for k, v in data.items() if k in sig.parameters}

        result = func(**valid_args)

        # Update result vào data cho step tiếp theo
        if isinstance(result, dict):
            data.update(result)
        else:
            data[name] = result
            # Nếu result là string, cho vào key "text"
            if isinstance(result, str):
                data["text"] = result

    return result

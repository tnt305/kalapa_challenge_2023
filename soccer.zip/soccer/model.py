import math
import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as T
from einops import rearrange
from einops.layers.torch import Rearrange
import torchvision.models.video as models

from impl.head_cls import pred_head, uncertainty_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead, FastGELU

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

class ASTRA(nn.Module):
    """
    ASTRA model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None,
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        
        #Register from dinov2
        self.num_registers = model_cfg.get('num_registers', 4)  # Lấy từ config, ví dụ 4
        if self.num_registers > 0:
            # Khởi tạo ngẫu nhiên, mô hình sẽ học chúng
            self.register_tokens = nn.Parameter(torch.randn(1, self.num_registers, model_cfg['dim']))
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        if self.use_text_gated_fusion:
            print("Using text gated fusion")
            embedding_path = model_cfg.get('text_embedding_path', "/home/thiendc/projects/video_summarization/train_soccernet/class_emb.npy")
            try:
                # Tải embedding và đăng ký như một buffer (không học)
                text_embeddings = torch.from_numpy(np.load(embedding_path)).float()
                self.register_buffer('text_label_embeddings', text_embeddings)
            except FileNotFoundError:
                raise FileNotFoundError(f"Cannot find text embedding file: {embedding_path}")
                
            text_dim = text_embeddings.shape[-1]
            model_dim = model_cfg['dim']

            # 2. Lớp chiếu (Projection Layer)
            # Chiếu text embedding về chiều của mô 
            if text_dim == model_dim:
                self.text_proj = nn.Identity()
            else:
                self.text_proj = nn.Linear(text_dim, model_dim)

            # 3. Gating Mechanism
            # Đầu vào của gate là sự kết hợp của decoder_output và text_embedding
            # Nó sẽ học cách tạo ra một trọng số (gate value) cho mỗi query và mỗi class
            self.fusion_gate = nn.Sequential(
                nn.Linear(model_dim * 2, model_dim),
                FastGELU(),
                nn.Linear(model_dim, 1), # Ra một giá trị scalar cho mỗi cặp
                nn.Sigmoid() # Đưa giá trị về khoảng [0, 1]
            )
            
            # 4. Lớp chuẩn hóa cuối cùng (tùy chọn nhưng nên có)
            self.post_fusion_norm = nn.LayerNorm(model_dim)
            
        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 2048)
            self.vggish_embeddings[4] = nn.Linear(2048, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder - with memory optimization
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])
        
        # Enable gradient checkpointing for memory efficiency
        # if hasattr(self.Tencoder, 'gradient_checkpointing_enable'):
        #     self.Tencoder.gradient_checkpointing_enable()

        #Transformer decoder - with memory optimization
        if self.n_output == self.text_label_embeddings.shape[0]:
            print("Using text label embeddings")
            text_embed_dim = self.text_label_embeddings.shape[1]
            if text_embed_dim != model_cfg['dim']:
                text_projection = nn.Linear(text_embed_dim, model_cfg['dim'])
                # Áp dụng projection và tạo queries
                with torch.no_grad():
                    projected_embeddings = text_projection(self.text_label_embeddings)
                self.queries = nn.Parameter(projected_embeddings.clone())
            else:
                self.queries = nn.Parameter(self.text_label_embeddings.clone())
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])
            
        # 2. Lớp MultiheadAttention để thực hiện pooling.
        # Nó sẽ tính toán sự tương đồng giữa query và các text info,
        # sau đó tổng hợp chúng lại theo trọng số attention.
        self.text_aggregation_query = nn.Parameter(torch.randn(1, 1, model_cfg['dim']))
        self.text_aggregator = nn.MultiheadAttention(
            embed_dim=model_cfg['dim'], 
            num_heads=8, # Bạn có thể dùng 4 hoặc 8 heads
            batch_first=True,
            dropout=model_cfg['dropout'] # Dùng dropout từ config
        )

        #Prediction heads
        self.clas_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = True, drop = model_cfg['dropout'])

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = False, drop = model_cfg['dropout'])


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            # Tính tổng feature dimension từ self.Bfeat_dim thay vì hard-code
            total_feat_dim = sum(self.Bfeat_dim) if self.baidu else 0
            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, total_feat_dim))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
            
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()
            #log mel spectrogram
            # featsA = 10.0 * (torch.log10(torch.maximum(torch.tensor(1e-10), featsA)) - torch.log10(torch.tensor(7430.77))) #7430.77 is the maximum value of the log mel spectrogram
            # featsA = torch.maximum(featsA, featsA.max() - 80)
            # featsA = rearrange(featsA, 'b f h -> b f h')

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if self.audio:
                del xA
            
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)

        #Baidu features
        if self.baidu:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB_reshaped = rearrange(featsB, 'l b cs d -> (l b) cs d')
            featsB_with_pe = self.video_pos_encoder(featsB_reshaped)
            featsB = rearrange(featsB_with_pe, '(l b) cs d -> l b cs d', l=l)
            
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')

        #Audio features
        if use_audio_in_batch:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
            #VGGish backbone with memory optimization
            # fA = featsA.shape[1] // 96 #number of 0.96 segments
            # featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            
            # # Process audio in smaller chunks to avoid OOM
            # chunk_size = 8  # Process 4 segments at a time (reduced from 8)
            # audio_outputs = []
            # for i in range(0, featsA.shape[0], chunk_size):
            #     chunk = featsA[i:i+chunk_size]
            #     with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            #         chunk_features = self.vggish_features(chunk)
            #         chunk_features = chunk_features.flatten(1)
            #         chunk_features = self.vggish_embeddings(chunk_features)
            #     audio_outputs.append(chunk_features)
                # Clear cache after each chunk
            fA = featsA.shape[1] // 96 #number of 0.96 segments
            featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            featsA = self.vggish_features(featsA)
            featsA = featsA.flatten(1)
            featsA = self.vggish_embeddings(featsA)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            # featsA = torch.cat(audio_outputs, dim=0)
            #Positional Encoding
            featsA = rearrange(featsA, '(b f) d -> b f d', f = fA) + self.encTA.expand(b, -1, -1) #batch x segments x d
            featsA += self.encA.expand(b, fA, -1) #batch x segments x d
    
        
        #Transformer encoder
        nB = featsB.shape[1]
        nA = featsA.shape[1] if use_audio_in_batch else 0
        
        if use_audio_in_batch:
            x = torch.cat((featsB, featsA), dim=1)
        else:
            x = featsB
        
        if self.register_tokens is not None:
            current_regs = self.register_tokens.expand(b, -1, -1)
            # Ghép registers vào `x` ban đầu
            x = torch.cat((current_regs, x), dim=1)
        else:
            current_regs = None
        
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):
            if splits[i] == 1: # Global attention
                x = mod(x)
                if current_regs is not None:
                    current_regs = x[:, :self.num_registers]
                    data_out = x[:, self.num_registers:]
                else:
                    data_out = x
                
                featsB = data_out[:, :nB]
                if use_audio_in_batch:
                    featsA = data_out[:, nB:nB+nA]
            else: # Hierarchical attention
                # Logic này phức tạp và cần được kiểm tra cẩn thận. 
                # Đây là phiên bản đơn giản hóa giả sử bạn muốn xử lý toàn cục nếu thiếu audio
                # Một cách tiếp cận an toàn hơn là luôn áp dụng hierarchical cho video
                
                # Tách video
                xB_seg_len = (splits[i] - 1) * (nB // splits[i])
                xB_seg = featsB[:, :xB_seg_len]
                xB_res = featsB[:, xB_seg_len:]
                xB_seg = rearrange(xB_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                
                # 2. Xử lý phần video riêng (trong trường hợp không có audio)
                # Ghép registers với mỗi phần video
                if current_regs is not None:
                    # Mở rộng registers cho batch đã được rearrange (b*ns)
                    regs_for_seg = current_regs.repeat_interleave(splits[i]-1, dim=0)
                    xB_seg_in = torch.cat((regs_for_seg, xB_seg), dim=1)
                    xB_res_in = torch.cat((current_regs, xB_res), dim=1)
                else:
                    xB_seg_in = xB_seg
                    xB_res_in = xB_res
                    
                # Áp dụng TE
                xB_seg_out_full = mod(xB_seg_in)
                xB_res_out_full = mod(xB_res_in)

                # Tách registers và data ra
                if current_regs is not None:
                    xB_seg_out = xB_seg_out_full[:, self.num_registers:]
                    xB_res_out = xB_res_out_full[:, self.num_registers:]
                    # Lấy các registers đã được cập nhật
                    regs_from_xB_seg = xB_seg_out_full[:, :self.num_registers]
                    regs_from_xB_res = xB_res_out_full[:, :self.num_registers]
                else:
                    xB_seg_out = xB_seg_out_full
                    xB_res_out = xB_res_out_full

                # Ghép lại video
                featsB_updated = torch.cat((rearrange(xB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), xB_res_out), dim=1)

                # 3. Nếu có audio, xử lý lại với dữ liệu kết hợp
                if use_audio_in_batch:
                    # Tách audio
                    xA_seg_len = (splits[i] - 1) * (nA // splits[i])
                    xA_seg = featsA[:, :xA_seg_len]
                    xA_res = featsA[:, xA_seg_len:]
                    
                    # Chuyển đổi shape
                    xA_seg = rearrange(xA_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                    
                    # Ghép các phần tương ứng
                    seg_data = torch.cat((xB_seg, xA_seg), dim=1)
                    res_data = torch.cat((xB_res, xA_res), dim=1)
                    
                    # Ghép registers
                    if current_regs is not None:
                        # `regs_for_seg` đã được tạo ở trên
                        seg_input = torch.cat((regs_for_seg, seg_data), dim=1)
                        res_input = torch.cat((current_regs, res_data), dim=1)
                    else:
                        seg_input = seg_data
                        res_input = res_data
                        
                    # Áp dụng TE
                    seg_output_full = mod(seg_input)
                    res_output_full = mod(res_input)

                    # Tách registers và data ra
                    if current_regs is not None:
                        seg_output = seg_output_full[:, self.num_registers:]
                        res_output = res_output_full[:, self.num_registers:]
                        regs_from_seg = seg_output_full[:, :self.num_registers]
                        regs_from_res = res_output_full[:, :self.num_registers]
                    else:
                        seg_output = seg_output_full
                        res_output = res_output_full

                    # Tách kết quả data ra lại thành video và audio
                    nB_seg_chunk = xB_seg.shape[1] # Kích thước chunk video
                    
                    featsB_seg_out = seg_output[:, :nB_seg_chunk]
                    featsA_seg_out = seg_output[:, nB_seg_chunk:]
                    
                    featsB_res_out = res_output[:, :nB]
                    featsA_res_out = res_output[:, nB:]
                    
                    # Ghép lại featsB và featsA cuối cùng
                    featsB = torch.cat((rearrange(featsB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsB_res_out), dim=1)
                    featsA = torch.cat((rearrange(featsA_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsA_res_out), dim=1)

                else: # Nếu không có audio
                    featsB = featsB_updated

                # 4. Cập nhật `current_regs` cho lớp tiếp theo
                if current_regs is not None:
                    if use_audio_in_batch:
                        # Lấy trung bình registers từ các lần gọi khác nhau
                        # Phải reshape lại regs_from_seg để match batch size gốc
                        regs_from_seg_reshaped = rearrange(regs_from_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        # Lấy trung bình trên chiều `ns` (các segment)
                        avg_regs_from_seg = regs_from_seg_reshaped.mean(dim=1)
                        # Lấy trung bình giữa 2 nguồn (seg và res)
                        current_regs = (avg_regs_from_seg + regs_from_res) / 2
                    else:
                        # Tương tự cho trường hợp chỉ có video
                        regs_from_xB_seg_reshaped = rearrange(regs_from_xB_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        avg_regs_from_xB_seg = regs_from_xB_seg_reshaped.mean(dim=1)
                        current_regs = (avg_regs_from_xB_seg + regs_from_xB_res) / 2

                # 5. Cập nhật `x` cho debug hoặc các lớp global tiếp theo
                if use_audio_in_batch:
                    x = torch.cat((featsB, featsA), dim=1)
                else:
                    x = featsB
                
                if current_regs is not None:
                    x = torch.cat((current_regs, x), dim=1)
        
        # --- BƯỚC 5: TRANSFORMER DECODER VÀ HEADS ---
        memory  = x
        queries = self.queries.expand((b, -1, -1))
        # 'x' từ vòng lặp cuối cùng của encoder là đầu vào cho decoder
        decoder_output = self.Tdecoder(queries, memory)
        
        if self.use_text_gated_fusion:
            # 1. Chuẩn bị các embedding text
            # Chiếu text_embeddings về đúng chiều
            projected_text_embeds = self.text_proj(self.text_label_embeddings) # Shape: [num_classes+1, d]
            
            # 2. Mở rộng kích thước để thực hiện fusion
            # decoder_output: [b, n_output, d] -> [b, n_output, 1, d]
            # text_embeds:    [num_classes+1, d] -> [1, 1, num_classes+1, d]
            
            decoder_out_expanded = decoder_output.unsqueeze(2) # Shape: [b, n_output, 1, d]
            text_embeds_expanded = projected_text_embeds.unsqueeze(0).unsqueeze(0) # Shape: [1, 1, num_classes+1, d]

            # Lặp lại (tile) để tạo ra mọi cặp (query, text_embedding)
            # decoder_tiled: [b, n_output, num_classes+1, d]
            # text_tiled:    [b, n_output, num_classes+1, d]
            decoder_tiled = decoder_out_expanded.expand(-1, -1, projected_text_embeds.shape[0], -1)
            text_tiled = text_embeds_expanded.expand(b, self.n_output, -1, -1)
            
            # 3. Tính toán Gate values
            # Ghép các cặp lại với nhau
            fusion_input = torch.cat((decoder_tiled, text_tiled), dim=-1) # Shape: [b, n_output, num_classes+1, d*2]
            
            # Cho qua cổng để có trọng số
            gate_values = self.fusion_gate(fusion_input) # Shape: [b, n_output, num_classes+1, 1]

            # 4. Áp dụng Gating
            # Điều chỉnh thông tin text dựa trên gate
            gated_text_info = text_tiled * gate_values # Shape: [b, n_output, num_classes+1, d]

            # Lấy trung bình thông tin text đã được "gated" trên tất cả các lớp
            # để tạo ra một vector điều chỉnh duy nhất cho mỗi query
            ### REPLACE BEFORE
            # contextual_text_adjustment = gated_text_info.mean(dim=2) # Shape: [b, n_output, d]
            # fused_output = decoder_output + contextual_text_adjustment
            # fused_output = self.post_fusion_norm(fused_output)
            
            # # Gán lại output đã được fusion để đưa vào các head
            # final_decoder_output = fused_output
            b, n_out, n_cls, d = gated_text_info.shape
            
            # Làm phẳng hai chiều đầu (batch và n_output) để xử lý hiệu quả
            # Shape: [B * n_output, num_classes+1, D]
            gated_text_info_flat = gated_text_info.view(b * n_out, n_cls, d)
            aggregation_query_flat = self.text_aggregation_query.expand(b * n_out, -1, -1)
            
            # Áp dụng attention để tổng hợp thông tin
            # Query "hỏi", Key và Value là các gated text info
            contextual_adjustment_flat, _ = self.text_aggregator(
                query=aggregation_query_flat, 
                key=gated_text_info_flat, 
                value=gated_text_info_flat
            ) # Đầu ra có shape: [B * n_output, 1, D]
            
            # Reshape kết quả về lại đúng shape mong muốn
            # Bỏ chiều 1 không cần thiết và reshape lại
            # Shape: [B * n_output, D] -> [B, n_output, D]
            contextual_text_adjustment = contextual_adjustment_flat.squeeze(1).view(b, n_out, d)
            
            # 5. Kết hợp với decoder_output gốc (giữ nguyên)
            fused_output = decoder_output + contextual_text_adjustment
            fused_output = self.post_fusion_norm(fused_output)
            
            final_decoder_output = fused_output
        else:
            # Nếu không dùng fusion, giữ nguyên output gốc
            final_decoder_output = decoder_output

        y1 = self.clas_head(final_decoder_output)
        y2 = self.displ_head(final_decoder_output)

        output = {
            'preds': y1,
            'predsD': y2,
            'labels': labels,
            'labelsD': labelsD
        }
        return output


class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU()
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        self.n_queues = 2
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        idxnq = torch.randint(0, self.n_queues, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        mask = torch.rand(x_aux.shape[1]) < self.p
        x_aux[:, mask] = self.embedding
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        idxs = torch.arange(x_aux.shape[1]-1)[torch.rand(x_aux.shape[1]-1) < self.p]
        x_aux[:, idxs, :], x_aux[:, idxs+1, :] = x_aux[:, idxs+1, :], x_aux[:, idxs, :]
        return x_aux
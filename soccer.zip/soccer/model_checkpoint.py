import __future__

import numpy as np
import warnings
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from netvlad import NetVLAD, NetRVLAD
from transformers import CLIPTextModel, CLIPTokenizer


class GroupWiseLinear(nn.Module):
    """
    GroupWiseLinear from TriModal implementation
    Efficient way to compute multiple linear transformations in parallel
    """
    def __init__(self, num_class, hidden_dim, bias=True):
        super().__init__()
        self.num_class = num_class
        self.hidden_dim = hidden_dim
        self.bias = bias

        self.W = nn.Parameter(torch.Tensor(1, num_class, hidden_dim))
        if bias:
            self.b = nn.Parameter(torch.Tensor(1, num_class))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(2))
        for i in range(self.num_class):
            self.W[0][i].data.uniform_(-stdv, stdv)
        if self.bias:
            for i in range(self.num_class):
                self.b[0][i].data.uniform_(-stdv, stdv)

    def forward(self, x):
        # x: B,K,d
        x = (self.W * x).sum(-1)
        if self.bias:
            x = x + self.b
        return x


class Model(nn.Module):
    def __init__(self, weights=None, input_size=512, num_classes=17, vocab_size=64, window_size=15, framerate=2, pool="NetVLAD"):
        """
        INPUT: a Tensor of shape (batch_size,window_size,feature_size)
        OUTPUTS: a Tensor of shape (batch_size,num_classes+1)
        """

        super(Model, self).__init__()

        self.num_classes = num_classes
        self.framerate = framerate
        self.pool = pool
        self.vlad_k = vocab_size
        self.window_size = window_size

        if not self.pool == "NetVLAD++Query" and not self.pool == "NetRVLAD++Query":
            
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = int(input_size/8)
                
            # create pooling layers
            if self.pool == "MAX":
                self.pool_layer = nn.MaxPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "MAX++":
                self.pool_layer_before = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "AVG":
                self.pool_layer = nn.AvgPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "AVG++":
                self.pool_layer_before = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "NetVLAD":
                self.pool_layer = NetVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetVLAD++":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD":
                self.pool_layer = NetRVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD++":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)
                
        else:
            # NetVLAD++Query and NetRVLAD++Query paths
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = vocab_size
            
            # create pooling layers for half segments
            if self.pool == "NetVLAD++Query":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
            elif self.pool == "NetRVLAD++Query":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)

            # Memory projection layer
            pooled_dim = self.vlad_k * input_size
            self.memory_proj = nn.Linear(pooled_dim, 512)
            
            # Get class embeddings using CLIP
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            class_embed = self._get_class_embeddings(self.num_classes, device)
            self._build_query_pooling_branch(512, class_embed)
            
        self.drop = nn.Dropout(p=0.5)
        self.sigm = nn.Sigmoid()

        self.load_weights(weights=weights)

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))
    
    def _get_class_embeddings(self, num_classes, device):
        """
        Hàm nội bộ để tải CLIP và tạo embeddings.
        """
        if CLIPTextModel is object: # Kiểm tra nếu import transformers thất bại
            return None
        
        try:
            model_name = "/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model"
            text_model = CLIPTextModel.from_pretrained(model_name).to(device)
            tokenizer = CLIPTokenizer.from_pretrained(model_name)
            text_model.eval() # Đặt ở chế độ eval
        except Exception as e:
            return None

        # Danh sách prompt chuẩn cho SoccerNet-v2 (17 lớp + 1 background)
        if num_classes == 17:
            prompts = [
            'Penalty', 'Kick-off', 'Goal', 'Substitution', 'Offside',
            'Shots on target', 'Shots off target', 'Clearance', 'Ball out of play',
            'Throw-in', 'Foul', 'Indirect free-kick', 'Direct free-kick', 'Corner',
            'Yellow card', 'Red card', 'Yellow->red card'
            ]
        else: # Fallback cho số lớp khác
            prompts = [f"a video of a class {i}" for i in range(num_classes)]

        with torch.no_grad():
            inputs = tokenizer(prompts, padding=True, return_tensors="pt").to(device)
            text_features = text_model(**inputs)
            class_embed = text_features.pooler_output.detach()
        
        # logging.info(f"Successfully generated {class_embed.shape[0]} class embeddings with dimension {class_embed.shape[1]}.")
        return class_embed

    def _build_query_pooling_branch(self, input_dim, class_embed=None):
        """
        Query-based attention: Queries attend to frame sequence
        """
        self.hidden_size = input_dim
        self.num_queries = self.num_classes
        
        num_pooling_layers = 4 if "Query" in self.pool else 1
        num_attention_heads = 8

        # Class queries (learnable hoặc từ CLIP)
        if class_embed is not None:
            clip_dim = class_embed.shape[1]
            if clip_dim != self.hidden_size:
                self.clip_proj = nn.Linear(clip_dim, self.hidden_size)
                device = next(self.parameters()).device if list(self.parameters()) else torch.device('cpu')
                class_embed = class_embed.to(device)
                projected_class_embed = self.clip_proj(class_embed)
            else:
                self.clip_proj = nn.Identity()
                projected_class_embed = class_embed
            self.query_embeds = nn.Parameter(projected_class_embed.clone(), requires_grad=True)
        else:
            self.query_embeds = nn.Parameter(torch.randn(self.num_queries, self.hidden_size), requires_grad=True)

        # 🔥 CHÍNH: Cross-attention từ queries tới frames
        self.query_to_frames_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=num_attention_heads,
            dropout=0.1,
            batch_first=True
        )
        
        # 🔥 THÊM: Temporal position encoding cho frames
        max_frames = 512  # Support up to 512 frames
        self.temporal_pos_encoding = nn.Parameter(torch.randn(max_frames, self.hidden_size))
        
        # 🔥 THÊM: Query refinement layers
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=self.hidden_size, nhead=num_attention_heads,
            dim_feedforward=self.hidden_size * 4, dropout=0.5, batch_first=True
        )
        self.query_pooling_layers = nn.ModuleList([decoder_layer for _ in range(num_pooling_layers)])
        
        # Classifiers
        self.class_classifier = GroupWiseLinear(self.num_queries, self.hidden_size, bias=True)
        self.background_classifier = nn.Linear(self.hidden_size, 1)


    def forward(self, inputs):
        # input_shape: (batch,frames,dim_features)
        BS, FR, IC = inputs.shape
        
        # 🔥 FIX: Feature extractor cho tất cả paths
        if not IC == 512:
            inputs = inputs.reshape(BS*FR, IC)
            inputs = self.feature_extractor(inputs)
            inputs = inputs.reshape(BS, FR, -1)

        # Temporal pooling operation
        if self.pool == "MAX" or self.pool == "AVG":
            inputs_pooled = self.pool_layer(inputs.permute((0, 2, 1))).squeeze(-1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "MAX++" or self.pool == "AVG++":
            nb_frames_50 = int(inputs.shape[1]/2)    
            input_before = inputs[:, :nb_frames_50, :]        
            input_after = inputs[:, nb_frames_50:, :]  
            inputs_before_pooled = self.pool_layer_before(input_before.permute((0, 2, 1))).squeeze(-1)
            inputs_after_pooled = self.pool_layer_after(input_after.permute((0, 2, 1))).squeeze(-1)
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD" or self.pool == "NetRVLAD":
            nb_frames_50 = int(inputs.shape[1]/2)
            inputs_before_pooled = self.pool_layer_before(inputs[:, :nb_frames_50, :])
            inputs_after_pooled = self.pool_layer_after(inputs[:, nb_frames_50:, :])
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD++Query" or self.pool == "NetRVLAD++Query":
            # 🔥 NEW APPROACH: Query-to-Frames Attention
            
            # Step 1: Add temporal position encoding to frames
            pos_enc = self.temporal_pos_encoding[:FR, :].unsqueeze(0).expand(BS, -1, -1)
            frames_with_pos = inputs + pos_enc  # [B, 30, 512]
            
            # Step 2: Prepare queries - "What events am I looking for?"
            queries = self.query_embeds.unsqueeze(0).repeat(BS, 1, 1)  # [B, 17, 512]
            
            # Step 3: 🔥 MAIN: Cross-attention Query-to-Frames
            attended_features, attention_weights = self.query_to_frames_attention(
                query=queries,           # [B, 17, 512] - "What to look for?"
                key=frames_with_pos,     # [B, 30, 512] - "Frame features as keys"
                value=frames_with_pos    # [B, 30, 512] - "Frame features as values"
            )
            # attended_features: [B, 17, 512] - Each query attended to relevant frames
            # attention_weights: [B, 17, 30] - Which frames each query focused on
            
            # Step 4: Multi-layer refinement với memory từ all frames
            refined_queries = attended_features
            for layer in self.query_pooling_layers:
                refined_queries = layer(
                    tgt=refined_queries,     # [B, 17, 512] - Current query states  
                    memory=frames_with_pos   # [B, 30, 512] - All frame information
                )
            
            # Step 5: Classification
            class_logits = self.class_classifier(self.drop(refined_queries)).squeeze(-1)  # [B, 17]
            
            # Background classification từ global frame representation
            global_frame_features = frames_with_pos.mean(dim=1)  # [B, 512] - Average pooling over time
            bg_logit = self.background_classifier(self.drop(global_frame_features))  # [B, 1]
            
            # Combine
            final_logits = torch.cat([bg_logit, class_logits], dim=1)  # [B, 18]
            output = self.sigm(final_logits)
            
            return output  # 🔥 FIX: Consistent return cho tất cả paths

        else:
            # Fallback cho unknown pooling methods
            raise ValueError(f"Unknown pooling method: {self.pool}")


if __name__ == "__main__":
    BS = 256
    T = 15
    framerate = 2
    D = 512
    pool = "NetVLAD++Query"  # 🔥 FIX: Test Query method
    model = Model(pool=pool, input_size=D, framerate=framerate, window_size=T)
    print(model)
    inp = torch.rand([BS, T*framerate, D])
    print("Input shape:", inp.shape)
    output = model(inp)  # 🔥 FIX: Only expect output, not attention_weights
    print("Output shape:", output.shape)
    
### NEWW CHECKPOINT
# import __future__

# import numpy as np
# import warnings
# import math

# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from netvlad import NetVLAD, NetRVLAD
# from transformers import CLIPTextModel, CLIPTokenizer
# from torch import Tensor


# class GroupWiseLinear(nn.Module):
#     """
#     GroupWiseLinear from TriModal implementation
#     Efficient way to compute multiple linear transformations in parallel
#     """
#     def __init__(self, num_class, hidden_dim, bias=True):
#         super().__init__()
#         self.num_class = num_class
#         self.hidden_dim = hidden_dim
#         self.bias = bias

#         self.W = nn.Parameter(torch.Tensor(1, num_class, hidden_dim))
#         if bias:
#             self.b = nn.Parameter(torch.Tensor(1, num_class))
#         self.reset_parameters()

#     def reset_parameters(self):
#         stdv = 1. / math.sqrt(self.W.size(2))
#         for i in range(self.num_class):
#             self.W[0][i].data.uniform_(-stdv, stdv)
#         if self.bias:
#             for i in range(self.num_class):
#                 self.b[0][i].data.uniform_(-stdv, stdv)

#     def forward(self, x):
#         # x: B,K,d
#         x = (self.W * x).sum(-1)
#         if self.bias:
#             x = x + self.b
#         return x


class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


# class Model(nn.Module):
#     def __init__(self, weights=None, input_size=512, num_classes=17, vocab_size=64, window_size=15, framerate=2, pool="NetVLAD"):
#         """
#         INPUT: a Tensor of shape (batch_size,window_size,feature_size)
#         OUTPUTS: a Tensor of shape (batch_size,num_classes+1)
#         """

#         super(Model, self).__init__()

#         self.num_classes = num_classes
#         self.framerate = framerate
#         self.pool = pool
#         self.vlad_k = vocab_size
#         self.window_size = window_size

#         if not self.pool == "NetVLAD++Query" and not self.pool == "NetRVLAD++Query":
            
#             # create feature extractor based on the input size
#             if input_size == 512:
#                 self.feature_extractor = nn.Identity()
#             else:
#                 self.feature_extractor = nn.Linear(input_size, 512)
#                 input_size = 512
#                 self.vlad_k = int(input_size/8)
                
#             # create pooling layers
#             if self.pool == "MAX":
#                 self.pool_layer = nn.MaxPool1d(self.window_size*framerate, stride=1)
#                 self.fc = nn.Linear(input_size, num_classes+1)

#             elif self.pool == "MAX++":
#                 self.pool_layer_before = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
#                 self.pool_layer_after = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
#                 self.fc = nn.Linear(2*input_size, num_classes+1)

#             elif self.pool == "AVG":
#                 self.pool_layer = nn.AvgPool1d(self.window_size*framerate, stride=1)
#                 self.fc = nn.Linear(input_size, num_classes+1)

#             elif self.pool == "AVG++":
#                 self.pool_layer_before = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
#                 self.pool_layer_after = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
#                 self.fc = nn.Linear(2*input_size, num_classes+1)

#             elif self.pool == "NetVLAD":
#                 self.pool_layer = NetVLAD(cluster_size=self.vlad_k, feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

#             elif self.pool == "NetVLAD++":
#                 self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

#             elif self.pool == "NetRVLAD":
#                 self.pool_layer = NetRVLAD(cluster_size=self.vlad_k, feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

#             elif self.pool == "NetRVLAD++":
#                 self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)
                
#         else:
#             # NetVLAD++Query and NetRVLAD++Query paths
#             # create feature extractor based on the input size
#             if input_size == 512:
#                 self.feature_extractor = nn.Identity()
#             else:
#                 self.feature_extractor = nn.Linear(input_size, 512)
#                 input_size = 512
#                 self.vlad_k = vocab_size
            
#             # create pooling layers for half segments
#             if self.pool == "NetVLAD++Query":
#                 self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#             elif self.pool == "NetRVLAD++Query":
#                 self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)
#                 self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
#                                                 add_batch_norm=True)

#             # Memory projection layer
#             pooled_dim = self.vlad_k * input_size
#             self.memory_proj = nn.Linear(pooled_dim, 512)
            
#             # Get class embeddings using CLIP
#             device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#             class_embed = self._get_class_embeddings(self.num_classes, device)
#             self._build_query_pooling_branch(512, class_embed)
            
#         self.drop = nn.Dropout(p=0.5)
#         self.sigm = nn.Sigmoid()

#         self.load_weights(weights=weights)

#     def load_weights(self, weights=None):
#         if(weights is not None):
#             print("=> loading checkpoint '{}'".format(weights))
#             checkpoint = torch.load(weights)
#             self.load_state_dict(checkpoint['state_dict'])
#             print("=> loaded checkpoint '{}' (epoch {})"
#                 .format(weights, checkpoint['epoch']))
    
#     def _get_class_embeddings(self, num_classes, device):
#         """
#         Hàm nội bộ để tải CLIP và tạo embeddings.
#         """
#         if CLIPTextModel is object: # Kiểm tra nếu import transformers thất bại
#             return None
        
#         try:
#             model_name = "/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model"
#             text_model = CLIPTextModel.from_pretrained(model_name).to(device)
#             tokenizer = CLIPTokenizer.from_pretrained(model_name)
#             text_model.eval() # Đặt ở chế độ eval
#         except Exception as e:
#             return None

#         # Danh sách prompt chuẩn cho SoccerNet-v2 (17 lớp + 1 background)
#         if num_classes == 17:
#             prompts = [
#             'Penalty', 'Kick-off', 'Goal', 'Substitution', 'Offside',
#             'Shots on target', 'Shots off target', 'Clearance', 'Ball out of play',
#             'Throw-in', 'Foul', 'Indirect free-kick', 'Direct free-kick', 'Corner',
#             'Yellow card', 'Red card', 'Yellow->red card'
#             ]
#         else: # Fallback cho số lớp khác
#             prompts = [f"a video of a class {i}" for i in range(num_classes)]

#         with torch.no_grad():
#             inputs = tokenizer(prompts, padding=True, return_tensors="pt").to(device)
#             text_features = text_model(**inputs)
#             class_embed = text_features.pooler_output.detach()
        
#         # logging.info(f"Successfully generated {class_embed.shape[0]} class embeddings with dimension {class_embed.shape[1]}.")
#         return class_embed

#     def _build_query_pooling_branch(self, input_dim, class_embed=None):
#         """
#         Query-based attention: Queries attend to frame sequence
#         """
#         self.hidden_size = input_dim
#         self.num_queries = self.num_classes
        
#         num_pooling_layers = 4 if "Query" in self.pool else 1
#         num_attention_heads = 8

#         # Class queries (learnable hoặc từ CLIP)
#         if class_embed is not None:
#             clip_dim = class_embed.shape[1]
#             if clip_dim != self.hidden_size:
#                 self.clip_proj = nn.Linear(clip_dim, self.hidden_size)
#                 device = next(self.parameters()).device if list(self.parameters()) else torch.device('cpu')
#                 class_embed = class_embed.to(device)
#                 projected_class_embed = self.clip_proj(class_embed)
#             else:
#                 self.clip_proj = nn.Identity()
#                 projected_class_embed = class_embed
#             self.query_embeds = nn.Parameter(projected_class_embed.clone(), requires_grad=True)
#         else:
#             self.query_embeds = nn.Parameter(torch.randn(self.num_queries, self.hidden_size), requires_grad=True)

#         # 🔥 NEW: Standard sinusoidal positional encoding
#         self.temporal_pos_encoding = PositionalEncoding(
#             d_model=self.hidden_size,
#             dropout=0.1,  # Light dropout cho positional encoding
#             max_len=512   # Support up to 512 frames
#         )
        
#         # 🔥 CHÍNH: Cross-attention từ queries tới frames
#         self.query_to_frames_attention = nn.MultiheadAttention(
#             embed_dim=self.hidden_size,
#             num_heads=num_attention_heads,
#             dropout=0.1,
#             batch_first=True
#         )
        
#         # 🔥 THÊM: Query refinement layers
#         decoder_layer = nn.TransformerDecoderLayer(
#             d_model=self.hidden_size, nhead=num_attention_heads,
#             dim_feedforward=self.hidden_size * 4, dropout=0.5, batch_first=True
#         )
#         self.query_pooling_layers = nn.ModuleList([decoder_layer for _ in range(num_pooling_layers)])
        
#         # Classifiers
#         self.class_classifier = GroupWiseLinear(self.num_queries, self.hidden_size, bias=True)
#         self.background_classifier = nn.Linear(self.hidden_size, 1)


#     def forward(self, inputs):
#         # input_shape: (batch,frames,dim_features)
#         BS, FR, IC = inputs.shape
        
#         # 🔥 FIX: Feature extractor cho tất cả paths
#         if not IC == 512:
#             inputs = inputs.reshape(BS*FR, IC)
#             inputs = self.feature_extractor(inputs)
#             inputs = inputs.reshape(BS, FR, -1)

#         # Temporal pooling operation
#         if self.pool == "MAX" or self.pool == "AVG":
#             inputs_pooled = self.pool_layer(inputs.permute((0, 2, 1))).squeeze(-1)
#             output = self.sigm(self.fc(self.drop(inputs_pooled)))
#             return output

#         elif self.pool == "MAX++" or self.pool == "AVG++":
#             nb_frames_50 = int(inputs.shape[1]/2)    
#             input_before = inputs[:, :nb_frames_50, :]        
#             input_after = inputs[:, nb_frames_50:, :]  
#             inputs_before_pooled = self.pool_layer_before(input_before.permute((0, 2, 1))).squeeze(-1)
#             inputs_after_pooled = self.pool_layer_after(input_after.permute((0, 2, 1))).squeeze(-1)
#             inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
#             output = self.sigm(self.fc(self.drop(inputs_pooled)))
#             return output

#         elif self.pool == "NetVLAD" or self.pool == "NetRVLAD":
#             nb_frames_50 = int(inputs.shape[1]/2)
#             inputs_before_pooled = self.pool_layer_before(inputs[:, :nb_frames_50, :])
#             inputs_after_pooled = self.pool_layer_after(inputs[:, nb_frames_50:, :])
#             inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
#             output = self.sigm(self.fc(self.drop(inputs_pooled)))
#             return output

#         elif self.pool == "NetVLAD++Query" or self.pool == "NetRVLAD++Query":
#             # 🔥 NEW: Apply sinusoidal positional encoding
#             frames_with_pos = self.temporal_pos_encoding(inputs)  # [B, 30, 512]
            
#             # Prepare queries
#             queries = self.query_embeds.unsqueeze(0).repeat(BS, 1, 1)  # [B, 17, 512]
            
#             # Cross-attention Query-to-Frames
#             attended_features, attention_weights = self.query_to_frames_attention(
#                 query=queries,           # [B, 17, 512] - "What to look for?"
#                 key=frames_with_pos,     # [B, 30, 512] - "Frame features with temporal info"
#                 value=frames_with_pos    # [B, 30, 512] - "Frame features with temporal info"
#             )
            
#             # Multi-layer refinement
#             refined_queries = attended_features
#             for layer in self.query_pooling_layers:
#                 refined_queries = layer(
#                     tgt=refined_queries,     # [B, 17, 512]
#                     memory=frames_with_pos   # [B, 30, 512]
#                 )
            
#             # Classification
#             class_logits = self.class_classifier(self.drop(refined_queries)).squeeze(-1)  # [B, 17]
            
#             # Background classification từ global frame representation
#             global_frame_features = frames_with_pos.mean(dim=1)  # [B, 512] - Average pooling over time
#             bg_logit = self.background_classifier(self.drop(global_frame_features))  # [B, 1]
            
#             # Combine
#             final_logits = torch.cat([bg_logit, class_logits], dim=1)  # [B, 18]
#             output = self.sigm(final_logits)
            
#             return output  # 🔥 FIX: Consistent return cho tất cả paths

#         else:
#             # Fallback cho unknown pooling methods
#             raise ValueError(f"Unknown pooling method: {self.pool}")


# if __name__ == "__main__":
#     BS = 256
#     T = 15
#     framerate = 2
#     D = 512
#     pool = "NetVLAD++Query"  # 🔥 FIX: Test Query method
#     model = Model(pool=pool, input_size=D, framerate=framerate, window_size=T)
#     print(model)
#     inp = torch.rand([BS, T*framerate, D])
#     print("Input shape:", inp.shape)
#     output = model(inp)  # 🔥 FIX: Only expect output, not attention_weights
#     print("Output shape:", output.shape)


### NEW CHECKPOINT WITH POSITIONAL ENCODING
    
import __future__

import numpy as np
import warnings
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from netvlad import NetVLAD, NetRVLAD
from transformers import CLIPTextModel, CLIPTokenizer
from torch import Tensor


class GroupWiseLinear(nn.Module):
    """
    GroupWiseLinear from TriModal implementation
    Efficient way to compute multiple linear transformations in parallel
    """
    def __init__(self, num_class, hidden_dim, bias=True):
        super().__init__()
        self.num_class = num_class
        self.hidden_dim = hidden_dim
        self.bias = bias

        self.W = nn.Parameter(torch.Tensor(1, num_class, hidden_dim))
        if bias:
            self.b = nn.Parameter(torch.Tensor(1, num_class))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(2))
        for i in range(self.num_class):
            self.W[0][i].data.uniform_(-stdv, stdv)
        if self.bias:
            for i in range(self.num_class):
                self.b[0][i].data.uniform_(-stdv, stdv)

    def forward(self, x):
        # x: B,K,d
        x = (self.W * x).sum(-1)
        if self.bias:
            x = x + self.b
        return x


class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


class Model(nn.Module):
    def __init__(self, weights=None, input_size=512, num_classes=17, vocab_size=64, window_size=15, framerate=2, pool="NetVLAD"):
        """
        INPUT: a Tensor of shape (batch_size,window_size,feature_size)
        OUTPUTS: a Tensor of shape (batch_size,num_classes+1)
        """

        super(Model, self).__init__()

        self.num_classes = num_classes
        self.framerate = framerate
        self.pool = pool
        self.vlad_k = vocab_size
        self.window_size = window_size

        if not self.pool == "NetVLAD++Query" and not self.pool == "NetRVLAD++Query":
            
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = int(input_size/8)
                
            # create pooling layers
            if self.pool == "MAX":
                self.pool_layer = nn.MaxPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "MAX++":
                self.pool_layer_before = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "AVG":
                self.pool_layer = nn.AvgPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "AVG++":
                self.pool_layer_before = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "NetVLAD":
                self.pool_layer = NetVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetVLAD++":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD":
                self.pool_layer = NetRVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD++":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)
                
        else:
            # NetVLAD++Query and NetRVLAD++Query paths
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = vocab_size
            
            # create pooling layers for half segments
            if self.pool == "NetVLAD++Query":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
            elif self.pool == "NetRVLAD++Query":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)

            # Memory projection layer
            pooled_dim = self.vlad_k * input_size
            self.memory_proj = nn.Linear(pooled_dim, 512)
            
            # Get class embeddings using CLIP
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            class_embed = self._get_class_embeddings(self.num_classes, device)
            self._build_query_pooling_branch(512, class_embed)
            
        self.drop = nn.Dropout(p=0.5)
        self.sigm = nn.Sigmoid()

        self.load_weights(weights=weights)

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))
    
    def _get_class_embeddings(self, num_classes, device):
        """
        Hàm nội bộ để tải CLIP và tạo embeddings.
        """
        if CLIPTextModel is object: # Kiểm tra nếu import transformers thất bại
            return None
        
        try:
            model_name = "/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model"
            text_model = CLIPTextModel.from_pretrained(model_name).to(device)
            tokenizer = CLIPTokenizer.from_pretrained(model_name)
            text_model.eval() # Đặt ở chế độ eval
        except Exception as e:
            return None

        # Danh sách prompt chuẩn cho SoccerNet-v2 (17 lớp + 1 background)
        if num_classes == 17:
            prompts = [
            'Penalty', 'Kick-off', 'Goal', 'Substitution', 'Offside',
            'Shots on target', 'Shots off target', 'Clearance', 'Ball out of play',
            'Throw-in', 'Foul', 'Indirect free-kick', 'Direct free-kick', 'Corner',
            'Yellow card', 'Red card', 'Yellow->red card'
            ]
        else: # Fallback cho số lớp khác
            prompts = [f"a video of a class {i}" for i in range(num_classes)]

        with torch.no_grad():
            inputs = tokenizer(prompts, padding=True, return_tensors="pt").to(device)
            text_features = text_model(**inputs)
            class_embed = text_features.pooler_output.detach()
        
        # logging.info(f"Successfully generated {class_embed.shape[0]} class embeddings with dimension {class_embed.shape[1]}.")
        return class_embed

    def _build_query_pooling_branch(self, input_dim, class_embed=None):
        """
        Query-based attention: Queries attend to frame sequence
        """
        self.hidden_size = input_dim
        self.num_queries = self.num_classes
        
        num_pooling_layers = 4 if "Query" in self.pool else 1
        num_attention_heads = 8

        # Class queries (learnable hoặc từ CLIP)
        if class_embed is not None:
            clip_dim = class_embed.shape[1]
            if clip_dim != self.hidden_size:
                self.clip_proj = nn.Linear(clip_dim, self.hidden_size)
                device = next(self.parameters()).device if list(self.parameters()) else torch.device('cpu')
                class_embed = class_embed.to(device)
                projected_class_embed = self.clip_proj(class_embed)
            else:
                self.clip_proj = nn.Identity()
                projected_class_embed = class_embed
            self.query_embeds = nn.Parameter(projected_class_embed.clone(), requires_grad=True)
        else:
            self.query_embeds = nn.Parameter(torch.randn(self.num_queries, self.hidden_size), requires_grad=True)

        # 🔥 NEW: Standard sinusoidal positional encoding
        self.temporal_pos_encoding = PositionalEncoding(
            d_model=self.hidden_size,
            dropout=0.1,  # Light dropout cho positional encoding
            max_len=512   # Support up to 512 frames
        )
        
        # 🔥 CHÍNH: Cross-attention từ queries tới frames
        self.query_to_frames_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=num_attention_heads,
            dropout=0.1,
            batch_first=True
        )
        
        # 🔥 THÊM: Query refinement layers
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=self.hidden_size, nhead=num_attention_heads,
            dim_feedforward=self.hidden_size * 4, dropout=0.1, batch_first=True #0.2 -> 0.5
        )
        self.query_pooling_layers = nn.ModuleList([decoder_layer for _ in range(num_pooling_layers)])  
        
        # Classifiers
        self.class_classifier = GroupWiseLinear(self.num_queries, self.hidden_size, bias=True)
        self.background_classifier = nn.Linear(self.hidden_size, 1)


    def forward(self, inputs):
        # input_shape: (batch,frames,dim_features)
        BS, FR, IC = inputs.shape
        
        # 🔥 FIX: Feature extractor cho tất cả paths
        if not IC == 512:
            # print(f"Feature extractor: {BS}x{FR}x{IC} -> {BS}x{FR}x768")
            inputs = inputs.reshape(BS*FR, IC)
            inputs = self.feature_extractor(inputs)
            inputs = inputs.reshape(BS, FR, -1)

        # Temporal pooling operation
        if self.pool == "MAX" or self.pool == "AVG":
            inputs_pooled = self.pool_layer(inputs.permute((0, 2, 1))).squeeze(-1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "MAX++" or self.pool == "AVG++":
            nb_frames_50 = int(inputs.shape[1]/2)    
            input_before = inputs[:, :nb_frames_50, :]        
            input_after = inputs[:, nb_frames_50:, :]  
            inputs_before_pooled = self.pool_layer_before(input_before.permute((0, 2, 1))).squeeze(-1)
            inputs_after_pooled = self.pool_layer_after(input_after.permute((0, 2, 1))).squeeze(-1)
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD" or self.pool == "NetRVLAD":
            nb_frames_50 = int(inputs.shape[1]/2)
            inputs_before_pooled = self.pool_layer_before(inputs[:, :nb_frames_50, :])
            inputs_after_pooled = self.pool_layer_after(inputs[:, nb_frames_50:, :])
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD++Query" or self.pool == "NetRVLAD++Query":
            # 🔥 NEW: Apply sinusoidal positional encoding
            frames_with_pos = self.temporal_pos_encoding(inputs)  # [B, 30, 512]
            # Prepare queries
            queries = self.query_embeds.unsqueeze(0).repeat(BS, 1, 1)  # [B, 17, 512]
            
            # Cross-attention Query-to-Frames
            attended_features, attention_weights = self.query_to_frames_attention(
                query=queries,           # [B, 17, 512] - "What to look for?"
                key=frames_with_pos,     # [B, 30, 512] - "Frame features with temporal info"
                value=frames_with_pos    # [B, 30, 512] - "Frame features with temporal info"
            )
            
            # Multi-layer refinement
            refined_queries = attended_features
            for layer in self.query_pooling_layers:
                refined_queries = layer(
                    tgt=refined_queries,     # [B, 17, 512]
                    memory=frames_with_pos   # [B, 30, 512]
                )
    
            # Classification
            class_logits = self.class_classifier(self.drop(refined_queries)).squeeze(-1)  # [B, 17]
            
            # Background classification từ global frame representation
            global_frame_features = frames_with_pos.mean(dim=1)  # [B, 512] - Average pooling over time
            bg_logit = self.background_classifier(self.drop(global_frame_features))  # [B, 1]
            
            # Combine
            final_logits = torch.cat([bg_logit, class_logits], dim=1)  # [B, 18]
            output = self.sigm(final_logits)
            
            return output  # 🔥 FIX: Consistent return cho tất cả paths

        else:
            # Fallback cho unknown pooling methods
            raise ValueError(f"Unknown pooling method: {self.pool}")


if __name__ == "__main__":
    BS = 256
    T = 15
    framerate = 2
    D = 512
    pool = "NetVLAD++Query"  # 🔥 FIX: Test Query method
    model = Model(pool=pool, input_size=D, framerate=framerate, window_size=T)
    print(model)
    inp = torch.rand([BS, T*framerate, D])
    print("Input shape:", inp.shape)
    output = model(inp)  # 🔥 FIX: Only expect output, not attention_weights
    print("Output shape:", output.shape)
    
    
### ANOTHER MODEL
import __future__

import numpy as np
import warnings
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from netvlad import NetVLAD, NetRVLAD
from transformers import CLIPTextModel, CLIPTokenizer
from torch import Tensor
from typing import Optional


class GroupWiseLinear(nn.Module):
    """
    GroupWiseLinear from TriModal implementation
    Efficient way to compute multiple linear transformations in parallel
    """
    def __init__(self, num_class, hidden_dim, bias=True):
        super().__init__()
        self.num_class = num_class
        self.hidden_dim = hidden_dim
        self.bias = bias

        self.W = nn.Parameter(torch.Tensor(1, num_class, hidden_dim))
        if bias:
            self.b = nn.Parameter(torch.Tensor(1, num_class))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(2))
        for i in range(self.num_class):
            self.W[0][i].data.uniform_(-stdv, stdv)
        if self.bias:
            for i in range(self.num_class):
                self.b[0][i].data.uniform_(-stdv, stdv)

    def forward(self, x):
        # x: B,K,d
        x = (self.W * x).sum(-1)
        if self.bias:
            x = x + self.b
        return x


class PositionalEncoding(nn.Module):
    """
    Enhanced Sinusoidal positional encoding for temporal sequences with multimodal support
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000, modality_dim: Optional[int] = None):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        self.d_model = d_model
        self.modality_dim = modality_dim
        
        # Standard sinusoidal positional encoding
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        # 🔥 FIX: Register as buffer với explicit type
        self.register_buffer('pe', pe, persistent=False)
        
        # 🔥 NEW: Multimodal support - learnable modality embeddings
        self.modality_embed: Optional[nn.Parameter] = None
        self.modality_proj: Optional[nn.Module] = None
        
        if modality_dim is not None:
            self.modality_embed = nn.Parameter(torch.randn(1, 1, modality_dim))
            if modality_dim != d_model:
                self.modality_proj = nn.Linear(modality_dim, d_model)
            else:
                self.modality_proj = nn.Identity()

    def forward(self, x: Tensor, modality_features: Optional[Tensor] = None) -> Tensor:
        """
        Enhanced forward with multimodal support
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
            modality_features: Optional[Tensor], shape [batch_size, modality_dim] for multimodal input
        """
        batch_size, seq_len, _ = x.shape
        
        # 🔥 FIX: Type assertion to fix linter error
        pe_buffer = getattr(self, 'pe')  # Get registered buffer safely
        if isinstance(pe_buffer, torch.Tensor):
            positional_encoding = pe_buffer[:, :seq_len, :].expand(batch_size, -1, -1)
        else:
            raise RuntimeError("Positional encoding buffer not found")
        
        # Apply positional encoding
        x = x + positional_encoding
        
        # 🔥 NEW: Add modality information if provided
        if modality_features is not None and self.modality_embed is not None and self.modality_proj is not None:
            # Project modality features to same dimension
            modality_proj = self.modality_proj(modality_features)  # [B, d_model]
            modality_expanded = modality_proj.unsqueeze(1).expand(-1, seq_len, -1)  # [B, seq_len, d_model]
            
            # Add modality information
            x = x + modality_expanded
        
        return self.dropout(x)

class Model(nn.Module):
    def __init__(self, weights=None, input_size=512, num_classes=17, vocab_size=64, window_size=15, framerate=2, pool="NetVLAD", audio_dim=768, multimodal=False):
        """
        INPUT: a Tensor of shape (batch_size,window_size,feature_size) OR Dict with 'video' and 'audio' keys
        OUTPUTS: a Tensor of shape (batch_size,num_classes+1)
        """

        super(Model, self).__init__()

        self.num_classes = num_classes
        self.framerate = framerate
        self.pool = pool
        self.vlad_k = vocab_size
        self.window_size = window_size
        self.audio_dim = audio_dim  # Dimension of audio features
        self.multimodal = multimodal  # Flag to enable multimodal processing
        
        # 🔥 NEW: Multimodal support flag
        self.supports_multimodal = pool in ["NetVLAD++Query", "NetRVLAD++Query", "NetVLAD++Query+Audio", "NetRVLAD++Query+Audio"] and multimodal
        
        # 🔥 NEW: Audio feature processor for multimodal inputs
        if self.supports_multimodal:
            self.audio_processor = nn.Sequential(
                nn.Linear(audio_dim, 512),  # Project audio to same dim as video
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(512, 512)
            )
            
            # Multimodal fusion strategy
            self.fusion_strategy = "attention"  # "concat", "add", "attention"
            if self.fusion_strategy == "concat":
                self.video_proj = nn.Linear(input_size, 256)
                self.audio_proj = nn.Linear(512, 256) 
                self.fusion_proj = nn.Linear(512, 512)  # 256 + 256 = 512
            elif self.fusion_strategy == "attention":
                self.cross_modal_attention = nn.MultiheadAttention(
                    embed_dim=512,
                    num_heads=8,
                    dropout=0.1,
                    batch_first=True
                )
        
        if not self.pool == "NetVLAD++Query" and not self.pool == "NetRVLAD++Query" and not self.pool == "NetVLAD++Query+Audio":
            
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = int(input_size/8)
                
            # create pooling layers
            if self.pool == "MAX":
                self.pool_layer = nn.MaxPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "MAX++":
                self.pool_layer_before = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.MaxPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "AVG":
                self.pool_layer = nn.AvgPool1d(self.window_size*framerate, stride=1)
                self.fc = nn.Linear(input_size, num_classes+1)

            elif self.pool == "AVG++":
                self.pool_layer_before = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.pool_layer_after = nn.AvgPool1d(int(self.window_size*framerate/2), stride=1)
                self.fc = nn.Linear(2*input_size, num_classes+1)

            elif self.pool == "NetVLAD":
                self.pool_layer = NetVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetVLAD++":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD":
                self.pool_layer = NetRVLAD(cluster_size=self.vlad_k, feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)

            elif self.pool == "NetRVLAD++":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.fc = nn.Linear(self.vlad_k*input_size, num_classes+1)
                
        else:
            # NetVLAD++Query and NetRVLAD++Query paths
            # create feature extractor based on the input size
            if input_size == 512:
                self.feature_extractor = nn.Identity()
            else:
                self.feature_extractor = nn.Linear(input_size, 512)
                input_size = 512
                self.vlad_k = vocab_size
            
            # create pooling layers for half segments
            if self.pool == "NetVLAD++Query":
                self.pool_layer_before = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
            elif self.pool == "NetRVLAD++Query":
                self.pool_layer_before = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)
                self.pool_layer_after = NetRVLAD(cluster_size=int(self.vlad_k/2), feature_size=input_size,
                                                add_batch_norm=True)

            # Memory projection layer
            pooled_dim = self.vlad_k * input_size
            self.memory_proj = nn.Linear(pooled_dim, 512)
            
            # Get class embeddings using CLIP
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            class_embed = self._get_class_embeddings(self.num_classes, device)
            self._build_query_pooling_branch(512, class_embed)
            
        self.drop = nn.Dropout(p=0.5)
        self.sigm = nn.Sigmoid()

        self.load_weights(weights=weights)

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))
    
    def _get_class_embeddings(self, num_classes, device):
        """
        Hàm nội bộ để tải CLIP và tạo embeddings.
        """
        if CLIPTextModel is object: # Kiểm tra nếu import transformers thất bại
            return None
        
        try:
            model_name = "/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model"
            text_model = CLIPTextModel.from_pretrained(model_name).to(device)
            tokenizer = CLIPTokenizer.from_pretrained(model_name)
            text_model.eval() # Đặt ở chế độ eval
        except Exception as e:
            return None

        # Danh sách prompt chuẩn cho SoccerNet-v2 (17 lớp + 1 background)
        if num_classes == 17:
            prompts = [
            'Penalty', 'Kick-off', 'Goal', 'Substitution', 'Offside',
            'Shots on target', 'Shots off target', 'Clearance', 'Ball out of play',
            'Throw-in', 'Foul', 'Indirect free-kick', 'Direct free-kick', 'Corner',
            'Yellow card', 'Red card', 'Yellow->red card'
            ]
        else: # Fallback cho số lớp khác
            prompts = [f"a video of a class {i}" for i in range(num_classes)]

        with torch.no_grad():
            inputs = tokenizer(prompts, padding=True, return_tensors="pt").to(device)
            text_features = text_model(**inputs)
            class_embed = text_features.pooler_output.detach()
        
        # logging.info(f"Successfully generated {class_embed.shape[0]} class embeddings with dimension {class_embed.shape[1]}.")
        return class_embed

    def _build_query_pooling_branch(self, input_dim, class_embed=None):
        """
        Enhanced Query-based attention with multimodal support
        Optimized for NetVLAD++Query paths
        """
        self.hidden_size = input_dim
        self.num_queries = self.num_classes
        
        # 🔥 ENHANCED: Deeper architecture for Query methods
        num_pooling_layers = 4 if "Query" in self.pool else 1 
        num_attention_heads = 8

        # Class queries (learnable hoặc từ CLIP)
        if class_embed is not None:
            clip_dim = class_embed.shape[1]
            if clip_dim != self.hidden_size:
                self.clip_proj = nn.Linear(clip_dim, self.hidden_size)
                device = next(self.parameters()).device if list(self.parameters()) else torch.device('cpu')
                class_embed = class_embed.to(device)
                projected_class_embed = self.clip_proj(class_embed)
            else:
                self.clip_proj = nn.Identity()
                projected_class_embed = class_embed
            self.query_embeds = nn.Parameter(projected_class_embed.clone(), requires_grad=True)
        else:
            self.query_embeds = nn.Parameter(torch.randn(self.num_queries, self.hidden_size), requires_grad=True)

        # 🔥 ENHANCED: Positional encoding (without multimodal dim - handled separately in forward)
        self.temporal_pos_encoding = PositionalEncoding(
            d_model=self.hidden_size,
            dropout=0.1,
            max_len=1024  # Increased from 512 to support longer sequences
        )
        
        # 🔥 NEW: Frame encoder layers for better temporal modeling
        # frame_encoder_layer = nn.TransformerEncoderLayer(
        #     d_model=self.hidden_size,
        #     nhead=num_attention_heads,
        #     dim_feedforward=self.hidden_size * 4,
        #     dropout=0.1,
        #     batch_first=True,
        #     activation='gelu'  # GELU activation for better performance
        # )
        self.frame_encoder = nn.GRU(
            self.hidden_size, 
            self.hidden_size//2, 
            num_layers=2, 
            batch_first=True, 
            bidirectional=True,
            dropout=0.1
        )
        
        # 🔥 ENHANCED: Multi-scale cross-attention
        self.query_to_frames_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=num_attention_heads,
            dropout=0.1,
            batch_first=True
        )
        
        # 🔥 NEW: Additional cross-attention for fine-grained features
        self.fine_grained_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=4,  # Fewer heads for fine-grained attention
            dropout=0.1,
            batch_first=True
        )
        
        # 🔥 ENHANCED: Query refinement with residual connections
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=self.hidden_size,
            nhead=num_attention_heads,
            dim_feedforward=self.hidden_size * 4,
            dropout=0.1,
            batch_first=True,
            activation='gelu'
        )
        self.query_pooling_layers = nn.ModuleList([decoder_layer for _ in range(num_pooling_layers)])
        
        # 🔥 NEW: Query normalization layers for stable training
        self.query_norm_layers = nn.ModuleList([
            nn.LayerNorm(self.hidden_size) for _ in range(num_pooling_layers)
        ])
        
        # 🔥 ENHANCED: Classifiers with better architecture
        self.class_classifier = nn.Sequential(
            GroupWiseLinear(self.num_queries, self.hidden_size, bias=True),
            nn.LayerNorm(self.num_queries),  # Normalize across classes
        )
        
        # 🔥 ENHANCED: Background classifier (reverted to simple as user requested)
        self.background_classifier = nn.Linear(self.hidden_size, 1)


    def forward(self, inputs):
        # 🔥 NEW: Handle both Dict (multimodal) and Tensor (single modal) inputs
        video_features = None
        audio_features = None
        
        # Parse input based on type
        if isinstance(inputs, dict):
            # Multimodal input from dataset
            video_features = inputs['video']  # [B, T, D_video]
            audio_features = inputs['audio'] if 'audio' in inputs else None  # [B, T, D_audio]
            inputs = video_features  # Use video as main input for compatibility
        else:
            # Single modal tensor input
            video_features = inputs
            audio_features = None
        
        # input_shape: (batch,frames,dim_features)
        BS, FR, IC = inputs.shape
        
        # 🔥 NEW: Process audio features if available and model supports multimodal
        processed_audio = None
        if self.supports_multimodal and audio_features is not None:
            # Process audio features: [B, T, D_audio] -> [B, T, 512]
            batch_size, seq_len, audio_dim = audio_features.shape
            audio_flat = audio_features.reshape(batch_size * seq_len, audio_dim)
            processed_audio_flat = self.audio_processor(audio_flat)  # [B*T, 512]
            processed_audio = processed_audio_flat.reshape(batch_size, seq_len, 512)  # [B, T, 512]
        
        # 🔥 ENHANCED: Feature extraction and fusion for multimodal
        if not IC == 512:
            # Feature extractor cho video features
            inputs = inputs.reshape(BS*FR, IC)
            inputs = self.feature_extractor(inputs)
            inputs = inputs.reshape(BS, FR, -1)
        
        # 🔥 NEW: Multimodal fusion for non-Query methods ONLY
        # Query methods handle multimodal fusion separately with positional encoding
        if (self.supports_multimodal and processed_audio is not None and 
            self.pool not in ["NetVLAD++Query", "NetRVLAD++Query", "NetVLAD++Query+Audio", "NetRVLAD++Query+Audio"]):
            if self.fusion_strategy == "concat":
                # Project both modalities to lower dimension then concatenate
                video_proj = self.video_proj(inputs)  # [B, T, 256]
                audio_proj = self.audio_proj(processed_audio)  # [B, T, 256]
                fused_features = torch.cat([video_proj, audio_proj], dim=-1)  # [B, T, 512]
                inputs = self.fusion_proj(fused_features)  # [B, T, 512]
            elif self.fusion_strategy == "add":
                # Simple addition after ensuring same dimensions
                inputs = inputs + processed_audio
            elif self.fusion_strategy == "attention":
                # Cross-modal attention between video and audio
                attended_features, _ = self.cross_modal_attention(
                    query=inputs,  # Video as query
                    key=processed_audio,  # Audio as key
                    value=processed_audio  # Audio as value
                )
                inputs = inputs + attended_features  # Residual connection

        # Temporal pooling operation
        if self.pool == "MAX" or self.pool == "AVG":
            inputs_pooled = self.pool_layer(inputs.permute((0, 2, 1))).squeeze(-1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "MAX++" or self.pool == "AVG++":
            nb_frames_50 = int(inputs.shape[1]/2)    
            input_before = inputs[:, :nb_frames_50, :]        
            input_after = inputs[:, nb_frames_50:, :]  
            inputs_before_pooled = self.pool_layer_before(input_before.permute((0, 2, 1))).squeeze(-1)
            inputs_after_pooled = self.pool_layer_after(input_after.permute((0, 2, 1))).squeeze(-1)
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD" or self.pool == "NetRVLAD":
            nb_frames_50 = int(inputs.shape[1]/2)
            inputs_before_pooled = self.pool_layer_before(inputs[:, :nb_frames_50, :])
            inputs_after_pooled = self.pool_layer_after(inputs[:, nb_frames_50:, :])
            inputs_pooled = torch.cat((inputs_before_pooled, inputs_after_pooled), dim=1)
            output = self.sigm(self.fc(self.drop(inputs_pooled)))
            return output

        elif self.pool == "NetVLAD++Query" or self.pool == "NetRVLAD++Query" or self.pool == "NetVLAD++Query+Audio" or self.pool == "NetRVLAD++Query+Audio":
            # 🔥 ENHANCED: NetVLAD++Query path with proper multimodal support
            
            # 🔥 NEW: Apply temporal positional encoding to video BEFORE multimodal fusion
            video_with_pos = self.temporal_pos_encoding(inputs)  # [B, 30, 512]
            
            # 🔥 NEW: Apply positional encoding to audio if available
            audio_with_pos = None
            if self.supports_multimodal and processed_audio is not None:
                # Use same temporal encoding for audio (shared temporal understanding)
                audio_with_pos = self.temporal_pos_encoding(processed_audio)  # [B, 30, 512]
                
                # 🔥 ENHANCED: Cross-modal fusion with positionally encoded features
                if self.fusion_strategy == "concat":
                    # Project both modalities to lower dimension then concatenate
                    video_proj = self.video_proj(video_with_pos)  # [B, T, 256]
                    audio_proj = self.audio_proj(audio_with_pos)  # [B, T, 256]
                    fused_features = torch.cat([video_proj, audio_proj], dim=-1)  # [B, T, 512]
                    frames_with_pos = self.fusion_proj(fused_features)  # [B, T, 512]
                elif self.fusion_strategy == "add":
                    # Simple addition of positionally encoded features
                    frames_with_pos = video_with_pos + audio_with_pos
                elif self.fusion_strategy == "attention":
                    # Cross-modal attention between positionally encoded features
                    attended_features, _ = self.cross_modal_attention(
                        query=video_with_pos,  # Video as query
                        key=audio_with_pos,    # Audio as key
                        value=audio_with_pos   # Audio as value
                    )
                    frames_with_pos = video_with_pos + attended_features  # Residual connection
                else:
                    frames_with_pos = video_with_pos  # Fallback to video only
            else:
                # Single modal case - use video with positional encoding
                frames_with_pos = video_with_pos
            
            # 🔥 NEW: Frame-level encoding for better temporal understanding
            encoded_frames, _ = self.frame_encoder(frames_with_pos)  # [B, 30, 512]
            
            # Prepare queries with better initialization
            queries = self.query_embeds.unsqueeze(0).repeat(BS, 1, 1)  # [B, 17, 512]
            
            # 🔥 ENHANCED: Multi-scale cross-attention
            # Primary cross-attention (coarse-grained)
            coarse_attended, coarse_weights = self.query_to_frames_attention(
                query=queries,           # [B, 17, 512] - "What to look for?"
                key=encoded_frames,      # [B, 30, 512] - "Enhanced frame features"
                value=encoded_frames     # [B, 30, 512] - "Enhanced frame features"
            )
            
            # Fine-grained cross-attention for detailed features
            fine_attended, fine_weights = self.fine_grained_attention(
                query=coarse_attended,   # [B, 17, 512] - "Refined queries"
                key=frames_with_pos,     # [B, 30, 512] - "Original positioned frames"
                value=frames_with_pos    # [B, 30, 512] - "Original positioned frames"
            )
            
            # 🔥 NEW: Combine multi-scale features (simplified without fusion layer)
            attended_features = coarse_attended + 0.5 * fine_attended  # [B, 17, 512]
            
            # 🔥 ENHANCED: Multi-layer refinement with residual connections and normalization
            refined_queries = attended_features
            for i, (layer, norm_layer) in enumerate(zip(self.query_pooling_layers, self.query_norm_layers)):
                # Apply transformer decoder layer
                layer_output = layer(
                    tgt=refined_queries,     # [B, 17, 512]
                    memory=encoded_frames    # [B, 30, 512] - Use encoded frames as memory
                )
                
                # Residual connection with normalization
                refined_queries = norm_layer(layer_output + refined_queries)
                
                # Apply dropout for regularization (except last layer)
                if i < len(self.query_pooling_layers) - 1:
                    refined_queries = F.dropout(refined_queries, p=0.1, training=self.training)
    
            # 🔥 ENHANCED: Classification with better features
            class_logits = self.class_classifier(self.drop(refined_queries))
            if isinstance(class_logits, tuple):
                class_logits = class_logits[0]  # Handle case where LayerNorm might return tuple
            class_logits = class_logits.squeeze(-1)  # [B, 17]
            
            # 🔥 ENHANCED: Background classification with richer global features
            # Combine multiple global representations
            global_mean = encoded_frames.mean(dim=1)  # [B, 512] - Mean pooling
            global_max = encoded_frames.max(dim=1)[0]  # [B, 512] - Max pooling
            
            # Attention-weighted global features
            attention_weights = (coarse_weights + fine_weights) / 2  # [B, 17, 30] - Average attention
            global_attention = attention_weights.mean(dim=1, keepdim=True)  # [B, 1, 30] - Average across queries
            global_attended = torch.bmm(global_attention, encoded_frames).squeeze(1)  # [B, 512]
            
            # Combine global features
            global_combined = global_mean + 0.3 * global_max + 0.4 * global_attended  # [B, 512]
            
            bg_logit = self.background_classifier(self.drop(global_combined))  # [B, 1]
            
            # 🔥 FIX: Ensure correct output format
            final_logits = torch.cat([bg_logit, class_logits], dim=1)  # [B, 18]
            output = self.sigm(final_logits)
            
            return output

        else:
            # Fallback cho unknown pooling methods
            raise ValueError(f"Unknown pooling method: {self.pool}")


#### Checkpoint good stuff
import math
import torch
import torch.nn as nn
import torchvision.transforms as T
from einops import rearrange
from einops.layers.torch import Rearrange
import torchvision.models.video as models

from impl.head_cls import pred_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

class ASTRA(nn.Module):
    """
    ASTRA model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        
        #Register from dinov2
        self.num_registers = model_cfg.get('num_registers', 4)  # Lấy từ config, ví dụ 4
        if self.num_registers > 0:
            # Khởi tạo ngẫu nhiên, mô hình sẽ học chúng
            self.register_tokens = nn.Parameter(torch.randn(1, self.num_registers, model_cfg['dim']))
        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 2048)
            self.vggish_embeddings[4] = nn.Linear(2048, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder - with memory optimization
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])
        
        # Enable gradient checkpointing for memory efficiency
        # if hasattr(self.Tencoder, 'gradient_checkpointing_enable'):
        #     self.Tencoder.gradient_checkpointing_enable()

        #Transformer decoder - with memory optimization
        self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])
        
        # # Enable gradient checkpointing for memory efficiency  
        # if hasattr(self.Tdecoder, 'gradient_checkpointing_enable'):
        #     self.Tdecoder.gradient_checkpointing_enable()

        #Prediction heads
        self.clas_head = GroupedConvHead(model_cfg['dim'], model_cfg['num_classes'] + 1,sigmoid = True, num_groups=2)

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = GroupedConvHead(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = False, num_groups=2)


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 8576))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
            
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()
            #log mel spectrogram
            # featsA = 10.0 * (torch.log10(torch.maximum(torch.tensor(1e-10), featsA)) - torch.log10(torch.tensor(7430.77))) #7430.77 is the maximum value of the log mel spectrogram
            # featsA = torch.maximum(featsA, featsA.max() - 80)
            # featsA = rearrange(featsA, 'b f h -> b f h')

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if self.audio:
                del xA
            
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)

        #Baidu features
        if self.baidu:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB_reshaped = rearrange(featsB, 'l b cs d -> (l b) cs d')
            featsB_with_pe = self.video_pos_encoder(featsB_reshaped)
            featsB = rearrange(featsB_with_pe, '(l b) cs d -> l b cs d', l=l)
            
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')

        #Audio features
        if use_audio_in_batch:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
            #VGGish backbone with memory optimization
            # fA = featsA.shape[1] // 96 #number of 0.96 segments
            # featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            
            # # Process audio in smaller chunks to avoid OOM
            # chunk_size = 8  # Process 4 segments at a time (reduced from 8)
            # audio_outputs = []
            # for i in range(0, featsA.shape[0], chunk_size):
            #     chunk = featsA[i:i+chunk_size]
            #     with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            #         chunk_features = self.vggish_features(chunk)
            #         chunk_features = chunk_features.flatten(1)
            #         chunk_features = self.vggish_embeddings(chunk_features)
            #     audio_outputs.append(chunk_features)
                # Clear cache after each chunk
            fA = featsA.shape[1] // 96 #number of 0.96 segments
            featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            featsA = self.vggish_features(featsA)
            featsA = featsA.flatten(1)
            featsA = self.vggish_embeddings(featsA)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            # featsA = torch.cat(audio_outputs, dim=0)
            #Positional Encoding
            featsA = rearrange(featsA, '(b f) d -> b f d', f = fA) + self.encTA.expand(b, -1, -1) #batch x segments x d
            featsA += self.encA.expand(b, fA, -1) #batch x segments x d

        
        current_regs = None
        if self.register_tokens is not None:
            current_regs = self.register_tokens.expand(b, -1, -1)
        
        
        #Transformer encoder
        nB = featsB.shape[1]
        nA = featsA.shape[1] if use_audio_in_batch else 0

        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):
            if splits[i] == 1: # Global attention
                x = mod(x)
            else: # Hierarchical attention
                # Logic này phức tạp và cần được kiểm tra cẩn thận. 
                # Đây là phiên bản đơn giản hóa giả sử bạn muốn xử lý toàn cục nếu thiếu audio
                # Một cách tiếp cận an toàn hơn là luôn áp dụng hierarchical cho video
                
                # Tách video
                xB_seg = rearrange(featsB[:, :(splits[i]-1) * (nB // splits[i])], 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                xB_res = featsB[:, (splits[i]-1) * (nB // splits[i]):]
                
                # Áp dụng TE cho video
                xB_seg_out = mod(xB_seg)
                xB_res_out = mod(xB_res)

                # Ghép lại video
                featsB = torch.cat((rearrange(xB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), xB_res_out), dim=1)

                # Nếu có audio, xử lý audio và ghép lại
                if use_audio_in_batch:
                    # Tách audio
                    xA_seg = rearrange(featsA[:, :(splits[i]-1) * (nA // splits[i])], 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                    xA_res = featsA[:, (splits[i]-1) * (nA // splits[i]):]
                    
                    # Ghép các phần tương ứng để đưa vào TE
                    seg_input = torch.cat((xB_seg, xA_seg), dim=1)
                    res_input = torch.cat((xB_res, xA_res), dim=1)

                    # Áp dụng TE
                    seg_output = mod(seg_input)
                    res_output = mod(res_input)

                    # Tách kết quả ra lại
                    nB_seg = xB_seg.shape[1]
                    nB_res = xB_res.shape[1]
                    featsB = torch.cat((rearrange(seg_output[:, :nB_seg], '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), res_output[:, :nB_res]), dim=1)
                    featsA = torch.cat((rearrange(seg_output[:, nB_seg:], '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), res_output[:, nB_res:]), dim=1)
                    x = torch.cat((featsB, featsA), dim=1)
                else:
                    x = featsB # Nếu không có audio, đầu ra cho lớp tiếp theo chỉ là video
        
        # --- BƯỚC 5: TRANSFORMER DECODER VÀ HEADS ---
        queries = self.queries.expand((b, -1, -1))
        # 'x' từ vòng lặp cuối cùng của encoder là đầu vào cho decoder
        decoder_output = self.Tdecoder(queries, x)

        y1 = self.clas_head(decoder_output)
        y2 = self.displ_head(decoder_output)

        output = {
            'preds': y1,
            'predsD': y2,
            'labels': labels,
            'labelsD': labelsD
        }
        return output

    
class uncertainty_head(nn.Module):
    """
    Uncertainty-aware prediction head
    """
    def __init__(self, input_dim, output_dim, drop = 0.2):
        """
        Initializes the uncertainty-aware prediction head

        Parameters
        ----------
        input_dim : int
            Input dimension of the head
        output_dim : int
            Output dimension of the head
        drop : float, optional
            Dropout probability, by default 0.2
        """
        super().__init__()
        self.shared_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),
            nn.GELU(),
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),
            nn.GELU()
        )
        self.mean_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )
        self.logvar_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )

    def forward(self, x: torch.Tensor):

        x = self.shared_head(x)
        mean = self.mean_head(x)
        logvar = self.logvar_head(x)
        x = torch.stack((mean, logvar), dim = 3)
        return x

class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU()
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        self.n_queues = 2
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        idxnq = torch.randint(0, self.n_queues, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        mask = torch.rand(x_aux.shape[1]) < self.p
        x_aux[:, mask] = self.embedding
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        idxs = torch.arange(x_aux.shape[1]-1)[torch.rand(x_aux.shape[1]-1) < self.p]
        x_aux[:, idxs, :], x_aux[:, idxs+1, :] = x_aux[:, idxs+1, :], x_aux[:, idxs, :]
        return x_aux

### This still good

import math
import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as T
from einops import rearrange
from einops.layers.torch import Rearrange
import torchvision.models.video as models

from impl.head_cls import pred_head, uncertainty_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

class ASTRA(nn.Module):
    """
    ASTRA model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None,
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        
        #Register from dinov2
        self.num_registers = model_cfg.get('num_registers', 4)  # Lấy từ config, ví dụ 4
        if self.num_registers > 0:
            # Khởi tạo ngẫu nhiên, mô hình sẽ học chúng
            self.register_tokens = nn.Parameter(torch.randn(1, self.num_registers, model_cfg['dim']))
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        if self.use_text_gated_fusion:
            print("Using text gated fusion")
            embedding_path = model_cfg.get('text_embedding_path', "/home/thiendc/projects/video_summarization/train_soccernet/label_embeddings.npy")
            try:
                # Tải embedding và đăng ký như một buffer (không học)
                text_embeddings = torch.from_numpy(np.load(embedding_path)).float()
                self.register_buffer('text_label_embeddings', text_embeddings)
            except FileNotFoundError:
                raise FileNotFoundError(f"Cannot find text embedding file: {embedding_path}")
                
            text_dim = text_embeddings.shape[-1]
            model_dim = model_cfg['dim']

            # 2. Lớp chiếu (Projection Layer)
            # Chiếu text embedding về chiều của mô 
            if text_dim == model_dim:
                self.text_proj = nn.Identity()
            else:
                self.text_proj = nn.Linear(text_dim, model_dim)

            # 3. Gating Mechanism
            # Đầu vào của gate là sự kết hợp của decoder_output và text_embedding
            # Nó sẽ học cách tạo ra một trọng số (gate value) cho mỗi query và mỗi class
            self.fusion_gate = nn.Sequential(
                nn.Linear(model_dim * 2, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, 1), # Ra một giá trị scalar cho mỗi cặp
                nn.Sigmoid() # Đưa giá trị về khoảng [0, 1]
            )
            
            # 4. Lớp chuẩn hóa cuối cùng (tùy chọn nhưng nên có)
            self.post_fusion_norm = nn.LayerNorm(model_dim)
            
        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 2048)
            self.vggish_embeddings[4] = nn.Linear(2048, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder - with memory optimization
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])
        
        # Enable gradient checkpointing for memory efficiency
        # if hasattr(self.Tencoder, 'gradient_checkpointing_enable'):
        #     self.Tencoder.gradient_checkpointing_enable()

        #Transformer decoder - with memory optimization
        if self.n_output == self.text_label_embeddings.shape[0]:
            print("Using text label embeddings")
            self.queries = nn.Parameter(self.text_label_embeddings.clone())
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])
        
        self.text_aggregation_query = nn.Parameter(torch.randn(1, 1, model_dim))
            
        # 2. Lớp MultiheadAttention để thực hiện pooling.
        # Nó sẽ tính toán sự tương đồng giữa query và các text info,
        # sau đó tổng hợp chúng lại theo trọng số attention.
        self.text_aggregator = nn.MultiheadAttention(
            embed_dim=model_dim, 
            num_heads=8, # Bạn có thể dùng 4 hoặc 8 heads
            batch_first=True,
            dropout=model_cfg['dim'] # Dùng dropout từ config
        )

        #Prediction heads
        self.clas_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = True, drop = model_cfg['dropout'])

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = False, drop = model_cfg['dropout'])


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 8576))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])
    
    def _load_embeddings(self, embedding_path):
        embeddings = torch.from_numpy(np.load(embedding_path)).float()
        return embeddings

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
            
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()
            #log mel spectrogram
            # featsA = 10.0 * (torch.log10(torch.maximum(torch.tensor(1e-10), featsA)) - torch.log10(torch.tensor(7430.77))) #7430.77 is the maximum value of the log mel spectrogram
            # featsA = torch.maximum(featsA, featsA.max() - 80)
            # featsA = rearrange(featsA, 'b f h -> b f h')

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if self.audio:
                del xA
            
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)

        #Baidu features
        if self.baidu:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB_reshaped = rearrange(featsB, 'l b cs d -> (l b) cs d')
            featsB_with_pe = self.video_pos_encoder(featsB_reshaped)
            featsB = rearrange(featsB_with_pe, '(l b) cs d -> l b cs d', l=l)
            
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')

        #Audio features
        if use_audio_in_batch:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
            #VGGish backbone with memory optimization
            # fA = featsA.shape[1] // 96 #number of 0.96 segments
            # featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            
            # # Process audio in smaller chunks to avoid OOM
            # chunk_size = 8  # Process 4 segments at a time (reduced from 8)
            # audio_outputs = []
            # for i in range(0, featsA.shape[0], chunk_size):
            #     chunk = featsA[i:i+chunk_size]
            #     with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            #         chunk_features = self.vggish_features(chunk)
            #         chunk_features = chunk_features.flatten(1)
            #         chunk_features = self.vggish_embeddings(chunk_features)
            #     audio_outputs.append(chunk_features)
                # Clear cache after each chunk
            fA = featsA.shape[1] // 96 #number of 0.96 segments
            featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            featsA = self.vggish_features(featsA)
            featsA = featsA.flatten(1)
            featsA = self.vggish_embeddings(featsA)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            # featsA = torch.cat(audio_outputs, dim=0)
            #Positional Encoding
            featsA = rearrange(featsA, '(b f) d -> b f d', f = fA) + self.encTA.expand(b, -1, -1) #batch x segments x d
            featsA += self.encA.expand(b, fA, -1) #batch x segments x d
    
        
        #Transformer encoder
        nB = featsB.shape[1]
        nA = featsA.shape[1] if use_audio_in_batch else 0
        
        if use_audio_in_batch:
            x = torch.cat((featsB, featsA), dim=1)
        else:
            x = featsB
        
        if self.register_tokens is not None:
            current_regs = self.register_tokens.expand(b, -1, -1)
            # Ghép registers vào `x` ban đầu
            x = torch.cat((current_regs, x), dim=1)
        else:
            current_regs = None
        
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):
            if splits[i] == 1: # Global attention
                x = mod(x)
                if current_regs is not None:
                    current_regs = x[:, :self.num_registers]
                    data_out = x[:, self.num_registers:]
                else:
                    data_out = x
                
                featsB = data_out[:, :nB]
                if use_audio_in_batch:
                    featsA = data_out[:, nB:nB+nA]
            else: # Hierarchical attention
                # Logic này phức tạp và cần được kiểm tra cẩn thận. 
                # Đây là phiên bản đơn giản hóa giả sử bạn muốn xử lý toàn cục nếu thiếu audio
                # Một cách tiếp cận an toàn hơn là luôn áp dụng hierarchical cho video
                
                # Tách video
                xB_seg_len = (splits[i] - 1) * (nB // splits[i])
                xB_seg = featsB[:, :xB_seg_len]
                xB_res = featsB[:, xB_seg_len:]
                xB_seg = rearrange(xB_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                
                # 2. Xử lý phần video riêng (trong trường hợp không có audio)
                # Ghép registers với mỗi phần video
                if current_regs is not None:
                    # Mở rộng registers cho batch đã được rearrange (b*ns)
                    regs_for_seg = current_regs.repeat_interleave(splits[i]-1, dim=0)
                    xB_seg_in = torch.cat((regs_for_seg, xB_seg), dim=1)
                    xB_res_in = torch.cat((current_regs, xB_res), dim=1)
                else:
                    xB_seg_in = xB_seg
                    xB_res_in = xB_res
                    
                # Áp dụng TE
                xB_seg_out_full = mod(xB_seg_in)
                xB_res_out_full = mod(xB_res_in)

                # Tách registers và data ra
                if current_regs is not None:
                    xB_seg_out = xB_seg_out_full[:, self.num_registers:]
                    xB_res_out = xB_res_out_full[:, self.num_registers:]
                    # Lấy các registers đã được cập nhật
                    regs_from_xB_seg = xB_seg_out_full[:, :self.num_registers]
                    regs_from_xB_res = xB_res_out_full[:, :self.num_registers]
                else:
                    xB_seg_out = xB_seg_out_full
                    xB_res_out = xB_res_out_full

                # Ghép lại video
                featsB_updated = torch.cat((rearrange(xB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), xB_res_out), dim=1)

                # 3. Nếu có audio, xử lý lại với dữ liệu kết hợp
                if use_audio_in_batch:
                    # Tách audio
                    xA_seg_len = (splits[i] - 1) * (nA // splits[i])
                    xA_seg = featsA[:, :xA_seg_len]
                    xA_res = featsA[:, xA_seg_len:]
                    
                    # Chuyển đổi shape
                    xA_seg = rearrange(xA_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                    
                    # Ghép các phần tương ứng
                    seg_data = torch.cat((xB_seg, xA_seg), dim=1)
                    res_data = torch.cat((xB_res, xA_res), dim=1)
                    
                    # Ghép registers
                    if current_regs is not None:
                        # `regs_for_seg` đã được tạo ở trên
                        seg_input = torch.cat((regs_for_seg, seg_data), dim=1)
                        res_input = torch.cat((current_regs, res_data), dim=1)
                    else:
                        seg_input = seg_data
                        res_input = res_data
                        
                    # Áp dụng TE
                    seg_output_full = mod(seg_input)
                    res_output_full = mod(res_input)

                    # Tách registers và data ra
                    if current_regs is not None:
                        seg_output = seg_output_full[:, self.num_registers:]
                        res_output = res_output_full[:, self.num_registers:]
                        regs_from_seg = seg_output_full[:, :self.num_registers]
                        regs_from_res = res_output_full[:, :self.num_registers]
                    else:
                        seg_output = seg_output_full
                        res_output = res_output_full

                    # Tách kết quả data ra lại thành video và audio
                    nB_seg_chunk = xB_seg.shape[1] # Kích thước chunk video
                    
                    featsB_seg_out = seg_output[:, :nB_seg_chunk]
                    featsA_seg_out = seg_output[:, nB_seg_chunk:]
                    
                    featsB_res_out = res_output[:, :nB]
                    featsA_res_out = res_output[:, nB:]
                    
                    # Ghép lại featsB và featsA cuối cùng
                    featsB = torch.cat((rearrange(featsB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsB_res_out), dim=1)
                    featsA = torch.cat((rearrange(featsA_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsA_res_out), dim=1)

                else: # Nếu không có audio
                    featsB = featsB_updated

                # 4. Cập nhật `current_regs` cho lớp tiếp theo
                if current_regs is not None:
                    if use_audio_in_batch:
                        # Lấy trung bình registers từ các lần gọi khác nhau
                        # Phải reshape lại regs_from_seg để match batch size gốc
                        regs_from_seg_reshaped = rearrange(regs_from_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        # Lấy trung bình trên chiều `ns` (các segment)
                        avg_regs_from_seg = regs_from_seg_reshaped.mean(dim=1)
                        # Lấy trung bình giữa 2 nguồn (seg và res)
                        current_regs = (avg_regs_from_seg + regs_from_res) / 2
                    else:
                        # Tương tự cho trường hợp chỉ có video
                        regs_from_xB_seg_reshaped = rearrange(regs_from_xB_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        avg_regs_from_xB_seg = regs_from_xB_seg_reshaped.mean(dim=1)
                        current_regs = (avg_regs_from_xB_seg + regs_from_xB_res) / 2

                # 5. Cập nhật `x` cho debug hoặc các lớp global tiếp theo
                if use_audio_in_batch:
                    x = torch.cat((featsB, featsA), dim=1)
                else:
                    x = featsB
                
                if current_regs is not None:
                    x = torch.cat((current_regs, x), dim=1)
        
        # --- BƯỚC 5: TRANSFORMER DECODER VÀ HEADS ---
        memory  = x
        queries = self.queries.expand((b, -1, -1))
        # 'x' từ vòng lặp cuối cùng của encoder là đầu vào cho decoder
        decoder_output = self.Tdecoder(queries, memory)
        
        if self.use_text_gated_fusion:
            # 1. Chuẩn bị các embedding text
            # Chiếu text_embeddings về đúng chiều
            projected_text_embeds = self.text_proj(self.text_label_embeddings) # Shape: [num_classes+1, d]
            
            # 2. Mở rộng kích thước để thực hiện fusion
            # decoder_output: [b, n_output, d] -> [b, n_output, 1, d]
            # text_embeds:    [num_classes+1, d] -> [1, 1, num_classes+1, d]
            
            decoder_out_expanded = decoder_output.unsqueeze(2) # Shape: [b, n_output, 1, d]
            text_embeds_expanded = projected_text_embeds.unsqueeze(0).unsqueeze(0) # Shape: [1, 1, num_classes+1, d]

            # Lặp lại (tile) để tạo ra mọi cặp (query, text_embedding)
            # decoder_tiled: [b, n_output, num_classes+1, d]
            # text_tiled:    [b, n_output, num_classes+1, d]
            decoder_tiled = decoder_out_expanded.expand(-1, -1, projected_text_embeds.shape[0], -1)
            text_tiled = text_embeds_expanded.expand(b, self.n_output, -1, -1)
            
            # 3. Tính toán Gate values
            # Ghép các cặp lại với nhau
            fusion_input = torch.cat((decoder_tiled, text_tiled), dim=-1) # Shape: [b, n_output, num_classes+1, d*2]
            
            # Cho qua cổng để có trọng số
            gate_values = self.fusion_gate(fusion_input) # Shape: [b, n_output, num_classes+1, 1]

            # 4. Áp dụng Gating
            # Điều chỉnh thông tin text dựa trên gate
            gated_text_info = text_tiled * gate_values # Shape: [b, n_output, num_classes+1, d]

            # Lấy trung bình thông tin text đã được "gated" trên tất cả các lớp
            # để tạo ra một vector điều chỉnh duy nhất cho mỗi query
            ### REPLACE BEFORE
            # contextual_text_adjustment = gated_text_info.mean(dim=2) # Shape: [b, n_output, d]
            # fused_output = decoder_output + contextual_text_adjustment
            # fused_output = self.post_fusion_norm(fused_output)
            
            # # Gán lại output đã được fusion để đưa vào các head
            # final_decoder_output = fused_output
            b, n_out, n_cls, d = gated_text_info.shape
            
            # Làm phẳng hai chiều đầu (batch và n_output) để xử lý hiệu quả
            # Shape: [B * n_output, num_classes+1, D]
            gated_text_info_flat = gated_text_info.view(b * n_out, n_cls, d)
            aggregation_query_flat = self.text_aggregation_query.expand(b * n_out, -1, -1)
            
            # Áp dụng attention để tổng hợp thông tin
            # Query "hỏi", Key và Value là các gated text info
            contextual_adjustment_flat, _ = self.text_aggregator(
                query=aggregation_query_flat, 
                key=gated_text_info_flat, 
                value=gated_text_info_flat
            ) # Đầu ra có shape: [B * n_output, 1, D]
            
            # Reshape kết quả về lại đúng shape mong muốn
            # Bỏ chiều 1 không cần thiết và reshape lại
            # Shape: [B * n_output, D] -> [B, n_output, D]
            contextual_text_adjustment = contextual_adjustment_flat.squeeze(1).view(b, n_out, d)
            
            # 5. Kết hợp với decoder_output gốc (giữ nguyên)
            fused_output = decoder_output + contextual_text_adjustment
            fused_output = self.post_fusion_norm(fused_output)
            
            final_decoder_output = fused_output
        else:
            # Nếu không dùng fusion, giữ nguyên output gốc
            final_decoder_output = decoder_output

        y1 = self.clas_head(final_decoder_output)
        y2 = self.displ_head(final_decoder_output)

        output = {
            'preds': y1,
            'predsD': y2,
            'labels': labels,
            'labelsD': labelsD
        }
        return output


class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU()
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        self.n_queues = 2
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        idxnq = torch.randint(0, self.n_queues, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        mask = torch.rand(x_aux.shape[1]) < self.p
        x_aux[:, mask] = self.embedding
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        idxs = torch.arange(x_aux.shape[1]-1)[torch.rand(x_aux.shape[1]-1) < self.p]
        x_aux[:, idxs, :], x_aux[:, idxs+1, :] = x_aux[:, idxs+1, :], x_aux[:, idxs, :]
        return x_aux


#### THis is a good version breakpoint 

import math
import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as T
from einops import rearrange
from einops.layers.torch import Rearrange
import torchvision.models.video as models

from impl.head_cls import pred_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

class ASTRA(nn.Module):
    """
    ASTRA model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None,
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        
        #Register from dinov2
        self.num_registers = model_cfg.get('num_registers', 4)  # Lấy từ config, ví dụ 4
        if self.num_registers > 0:
            # Khởi tạo ngẫu nhiên, mô hình sẽ học chúng
            self.register_tokens = nn.Parameter(torch.randn(1, self.num_registers, model_cfg['dim']))
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        if self.use_text_gated_fusion:
            print("Using text gated fusion")
            embedding_path = model_cfg.get('text_embedding_path', "/home/thiendc/projects/video_summarization/train_soccernet/label_embeddings.npy")
            try:
                # Tải embedding và đăng ký như một buffer (không học)
                text_embeddings = torch.from_numpy(np.load(embedding_path)).float()
                self.register_buffer('text_label_embeddings', text_embeddings)
            except FileNotFoundError:
                raise FileNotFoundError(f"Cannot find text embedding file: {embedding_path}")
                
            text_dim = text_embeddings.shape[-1]
            model_dim = model_cfg['dim']

            # 2. Lớp chiếu (Projection Layer)
            # Chiếu text embedding về chiều của mô hình
            self.text_proj = nn.Linear(text_dim, model_dim)

            # 3. Gating Mechanism
            # Đầu vào của gate là sự kết hợp của decoder_output và text_embedding
            # Nó sẽ học cách tạo ra một trọng số (gate value) cho mỗi query và mỗi class
            self.fusion_gate = nn.Sequential(
                nn.Linear(model_dim * 2, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, 1), # Ra một giá trị scalar cho mỗi cặp
                nn.Sigmoid() # Đưa giá trị về khoảng [0, 1]
            )
            
            # 4. Lớp chuẩn hóa cuối cùng (tùy chọn nhưng nên có)
            self.post_fusion_norm = nn.LayerNorm(model_dim)
            
        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            # self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 2048)
            self.vggish_embeddings[4] = nn.Linear(2048, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder - with memory optimization
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])
        
        # Enable gradient checkpointing for memory efficiency
        # if hasattr(self.Tencoder, 'gradient_checkpointing_enable'):
        #     self.Tencoder.gradient_checkpointing_enable()

        #Transformer decoder - with memory optimization
        self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])
        
        # # Enable gradient checkpointing for memory efficiency  
        # if hasattr(self.Tdecoder, 'gradient_checkpointing_enable'):
        #     self.Tdecoder.gradient_checkpointing_enable()

        #Prediction heads
        self.clas_head = GroupedConvHead(model_cfg['dim'], model_cfg['num_classes'] + 1,sigmoid = True, num_groups=2)

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = GroupedConvHead(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = False, num_groups=2)


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, 8576))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])
    
    def _load_embeddings(self, embedding_path):
        embeddings = torch.from_numpy(np.load(embedding_path)).float()
        return embeddings

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        #Float type data
        if labels != None:
            labels = labels.float()
        if labelsD != None:
            labelsD = labelsD.float()
            
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()
            #log mel spectrogram
            # featsA = 10.0 * (torch.log10(torch.maximum(torch.tensor(1e-10), featsA)) - torch.log10(torch.tensor(7430.77))) #7430.77 is the maximum value of the log mel spectrogram
            # featsA = torch.maximum(featsA, featsA.max() - 80)
            # featsA = rearrange(featsA, 'b f h -> b f h')

        #Mixup (not inference)
        if self.model_cfg['mixup'] & (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device = 'cuda:0')
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if self.audio:
                del xA
            
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        #DATA AUGMENTATIONS + PREPROCESSING BEFORE TE (INCLUDING POSITIONAL ENCODING)

        #Baidu features
        if self.baidu:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            #PFFN
            featsB = [self.baidu_LL[i](featsB[:, :, int(torch.tensor(self.Bfeat_dim[:i]).sum()):int(torch.tensor(self.Bfeat_dim[:i+1]).sum())]) for i in range(len(self.Bfeat_dim))]
            featsB = torch.stack(featsB) #5 x b x cs x d
            #Positional Encoding
            l, b, cs, d = featsB.shape
            # featsB += self.encTB.expand(l, b, -1, -1)
            featsB_reshaped = rearrange(featsB, 'l b cs d -> (l b) cs d')
            featsB_with_pe = self.video_pos_encoder(featsB_reshaped)
            featsB = rearrange(featsB_with_pe, '(l b) cs d -> l b cs d', l=l)
            
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')

        #Audio features
        if use_audio_in_batch:
            #Feature Augmentation
            if self.model_cfg['feature_augmentation'] & (not inference):
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
            #VGGish backbone with memory optimization
            # fA = featsA.shape[1] // 96 #number of 0.96 segments
            # featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            
            # # Process audio in smaller chunks to avoid OOM
            # chunk_size = 8  # Process 4 segments at a time (reduced from 8)
            # audio_outputs = []
            # for i in range(0, featsA.shape[0], chunk_size):
            #     chunk = featsA[i:i+chunk_size]
            #     with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            #         chunk_features = self.vggish_features(chunk)
            #         chunk_features = chunk_features.flatten(1)
            #         chunk_features = self.vggish_embeddings(chunk_features)
            #     audio_outputs.append(chunk_features)
                # Clear cache after each chunk
            fA = featsA.shape[1] // 96 #number of 0.96 segments
            featsA = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f = fA) #batch*segments x d x 96 x 128
            featsA = self.vggish_features(featsA)
            featsA = featsA.flatten(1)
            featsA = self.vggish_embeddings(featsA)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            # featsA = torch.cat(audio_outputs, dim=0)
            #Positional Encoding
            featsA = rearrange(featsA, '(b f) d -> b f d', f = fA) + self.encTA.expand(b, -1, -1) #batch x segments x d
            featsA += self.encA.expand(b, fA, -1) #batch x segments x d
    
        
        #Transformer encoder
        nB = featsB.shape[1]
        nA = featsA.shape[1] if use_audio_in_batch else 0
        
        if use_audio_in_batch:
            x = torch.cat((featsB, featsA), dim=1)
        else:
            x = featsB
        
        if self.register_tokens is not None:
            current_regs = self.register_tokens.expand(b, -1, -1)
            # Ghép registers vào `x` ban đầu
            x = torch.cat((current_regs, x), dim=1)
        else:
            current_regs = None
        
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        for i, mod in enumerate(self.Tencoder.layers):
            if splits[i] == 1: # Global attention
                x = mod(x)
                if current_regs is not None:
                    current_regs = x[:, :self.num_registers]
                    data_out = x[:, self.num_registers:]
                else:
                    data_out = x
                
                featsB = data_out[:, :nB]
                if use_audio_in_batch:
                    featsA = data_out[:, nB:nB+nA]
            else: # Hierarchical attention
                # Logic này phức tạp và cần được kiểm tra cẩn thận. 
                # Đây là phiên bản đơn giản hóa giả sử bạn muốn xử lý toàn cục nếu thiếu audio
                # Một cách tiếp cận an toàn hơn là luôn áp dụng hierarchical cho video
                
                # Tách video
                xB_seg_len = (splits[i] - 1) * (nB // splits[i])
                xB_seg = featsB[:, :xB_seg_len]
                xB_res = featsB[:, xB_seg_len:]
                xB_seg = rearrange(xB_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                
                # 2. Xử lý phần video riêng (trong trường hợp không có audio)
                # Ghép registers với mỗi phần video
                if current_regs is not None:
                    # Mở rộng registers cho batch đã được rearrange (b*ns)
                    regs_for_seg = current_regs.repeat_interleave(splits[i]-1, dim=0)
                    xB_seg_in = torch.cat((regs_for_seg, xB_seg), dim=1)
                    xB_res_in = torch.cat((current_regs, xB_res), dim=1)
                else:
                    xB_seg_in = xB_seg
                    xB_res_in = xB_res
                    
                # Áp dụng TE
                xB_seg_out_full = mod(xB_seg_in)
                xB_res_out_full = mod(xB_res_in)

                # Tách registers và data ra
                if current_regs is not None:
                    xB_seg_out = xB_seg_out_full[:, self.num_registers:]
                    xB_res_out = xB_res_out_full[:, self.num_registers:]
                    # Lấy các registers đã được cập nhật
                    regs_from_xB_seg = xB_seg_out_full[:, :self.num_registers]
                    regs_from_xB_res = xB_res_out_full[:, :self.num_registers]
                else:
                    xB_seg_out = xB_seg_out_full
                    xB_res_out = xB_res_out_full

                # Ghép lại video
                featsB_updated = torch.cat((rearrange(xB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), xB_res_out), dim=1)

                # 3. Nếu có audio, xử lý lại với dữ liệu kết hợp
                if use_audio_in_batch:
                    # Tách audio
                    xA_seg_len = (splits[i] - 1) * (nA // splits[i])
                    xA_seg = featsA[:, :xA_seg_len]
                    xA_res = featsA[:, xA_seg_len:]
                    
                    # Chuyển đổi shape
                    xA_seg = rearrange(xA_seg, 'b (ns ls) d -> (b ns) ls d', ns=splits[i]-1)
                    
                    # Ghép các phần tương ứng
                    seg_data = torch.cat((xB_seg, xA_seg), dim=1)
                    res_data = torch.cat((xB_res, xA_res), dim=1)
                    
                    # Ghép registers
                    if current_regs is not None:
                        # `regs_for_seg` đã được tạo ở trên
                        seg_input = torch.cat((regs_for_seg, seg_data), dim=1)
                        res_input = torch.cat((current_regs, res_data), dim=1)
                    else:
                        seg_input = seg_data
                        res_input = res_data
                        
                    # Áp dụng TE
                    seg_output_full = mod(seg_input)
                    res_output_full = mod(res_input)

                    # Tách registers và data ra
                    if current_regs is not None:
                        seg_output = seg_output_full[:, self.num_registers:]
                        res_output = res_output_full[:, self.num_registers:]
                        regs_from_seg = seg_output_full[:, :self.num_registers]
                        regs_from_res = res_output_full[:, :self.num_registers]
                    else:
                        seg_output = seg_output_full
                        res_output = res_output_full

                    # Tách kết quả data ra lại thành video và audio
                    nB_seg_chunk = xB_seg.shape[1] # Kích thước chunk video
                    
                    featsB_seg_out = seg_output[:, :nB_seg_chunk]
                    featsA_seg_out = seg_output[:, nB_seg_chunk:]
                    
                    featsB_res_out = res_output[:, :nB]
                    featsA_res_out = res_output[:, nB:]
                    
                    # Ghép lại featsB và featsA cuối cùng
                    featsB = torch.cat((rearrange(featsB_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsB_res_out), dim=1)
                    featsA = torch.cat((rearrange(featsA_seg_out, '(b ns) ls d -> b (ns ls) d', ns=splits[i]-1), featsA_res_out), dim=1)

                else: # Nếu không có audio
                    featsB = featsB_updated

                # 4. Cập nhật `current_regs` cho lớp tiếp theo
                if current_regs is not None:
                    if use_audio_in_batch:
                        # Lấy trung bình registers từ các lần gọi khác nhau
                        # Phải reshape lại regs_from_seg để match batch size gốc
                        regs_from_seg_reshaped = rearrange(regs_from_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        # Lấy trung bình trên chiều `ns` (các segment)
                        avg_regs_from_seg = regs_from_seg_reshaped.mean(dim=1)
                        # Lấy trung bình giữa 2 nguồn (seg và res)
                        current_regs = (avg_regs_from_seg + regs_from_res) / 2
                    else:
                        # Tương tự cho trường hợp chỉ có video
                        regs_from_xB_seg_reshaped = rearrange(regs_from_xB_seg, '(b ns) nr d -> b ns nr d', ns=splits[i]-1)
                        avg_regs_from_xB_seg = regs_from_xB_seg_reshaped.mean(dim=1)
                        current_regs = (avg_regs_from_xB_seg + regs_from_xB_res) / 2

                # 5. Cập nhật `x` cho debug hoặc các lớp global tiếp theo
                if use_audio_in_batch:
                    x = torch.cat((featsB, featsA), dim=1)
                else:
                    x = featsB
                
                if current_regs is not None:
                    x = torch.cat((current_regs, x), dim=1)
        
        # --- BƯỚC 5: TRANSFORMER DECODER VÀ HEADS ---
        memory  = x
        queries = self.queries.expand((b, -1, -1))
        # 'x' từ vòng lặp cuối cùng của encoder là đầu vào cho decoder
        decoder_output = self.Tdecoder(queries, memory)
        
        if self.use_text_gated_fusion:
            # 1. Chuẩn bị các embedding text
            # Chiếu text_embeddings về đúng chiều
            projected_text_embeds = self.text_proj(self.text_label_embeddings) # Shape: [num_classes+1, d]
            
            # 2. Mở rộng kích thước để thực hiện fusion
            # decoder_output: [b, n_output, d] -> [b, n_output, 1, d]
            # text_embeds:    [num_classes+1, d] -> [1, 1, num_classes+1, d]
            
            decoder_out_expanded = decoder_output.unsqueeze(2) # Shape: [b, n_output, 1, d]
            text_embeds_expanded = projected_text_embeds.unsqueeze(0).unsqueeze(0) # Shape: [1, 1, num_classes+1, d]

            # Lặp lại (tile) để tạo ra mọi cặp (query, text_embedding)
            # decoder_tiled: [b, n_output, num_classes+1, d]
            # text_tiled:    [b, n_output, num_classes+1, d]
            decoder_tiled = decoder_out_expanded.expand(-1, -1, projected_text_embeds.shape[0], -1)
            text_tiled = text_embeds_expanded.expand(b, self.n_output, -1, -1)
            
            # 3. Tính toán Gate values
            # Ghép các cặp lại với nhau
            fusion_input = torch.cat((decoder_tiled, text_tiled), dim=-1) # Shape: [b, n_output, num_classes+1, d*2]
            
            # Cho qua cổng để có trọng số
            gate_values = self.fusion_gate(fusion_input) # Shape: [b, n_output, num_classes+1, 1]

            # 4. Áp dụng Gating
            # Điều chỉnh thông tin text dựa trên gate
            gated_text_info = text_tiled * gate_values # Shape: [b, n_output, num_classes+1, d]

            # Lấy trung bình thông tin text đã được "gated" trên tất cả các lớp
            # để tạo ra một vector điều chỉnh duy nhất cho mỗi query
            contextual_text_adjustment = gated_text_info.mean(dim=2) # Shape: [b, n_output, d]

            # 5. Kết hợp với decoder_output gốc
            # Sử dụng residual connection
            fused_output = decoder_output + contextual_text_adjustment
            fused_output = self.post_fusion_norm(fused_output)
            
            # Gán lại output đã được fusion để đưa vào các head
            final_decoder_output = fused_output
        else:
            # Nếu không dùng fusion, giữ nguyên output gốc
            final_decoder_output = decoder_output

        y1 = self.clas_head(final_decoder_output)
        y2 = self.displ_head(final_decoder_output)

        output = {
            'preds': y1,
            'predsD': y2,
            'labels': labels,
            'labelsD': labelsD
        }
        return output

    
class uncertainty_head(nn.Module):
    """
    Uncertainty-aware prediction head
    """
    def __init__(self, input_dim, output_dim, drop = 0.2):
        """
        Initializes the uncertainty-aware prediction head

        Parameters
        ----------
        input_dim : int
            Input dimension of the head
        output_dim : int
            Output dimension of the head
        drop : float, optional
            Dropout probability, by default 0.2
        """
        super().__init__()
        self.shared_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),
            nn.GELU(),
            nn.Dropout(drop),
            nn.Linear(input_dim, input_dim),
            nn.GELU()
        )
        self.mean_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )
        self.logvar_head = nn.Sequential(
            nn.Dropout(drop),
            nn.Linear(input_dim, output_dim)
        )

    def forward(self, x: torch.Tensor):

        x = self.shared_head(x)
        mean = self.mean_head(x)
        logvar = self.logvar_head(x)
        x = torch.stack((mean, logvar), dim = 3)
        return x

class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(),
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU()
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        self.n_queues = 2
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        idxnq = torch.randint(0, self.n_queues, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        mask = torch.rand(x_aux.shape[1]) < self.p
        x_aux[:, mask] = self.embedding
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        x_aux = x.clone()
        idxs = torch.arange(x_aux.shape[1]-1)[torch.rand(x_aux.shape[1]-1) < self.p]
        x_aux[:, idxs, :], x_aux[:, idxs+1, :] = x_aux[:, idxs+1, :], x_aux[:, idxs, :]
        return x_aux
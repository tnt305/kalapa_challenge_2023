## CLIP Frame-Level Feature Extraction
## 25/06/2025

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "6"
import torch
import torch.nn as nn
import numpy as np
from transformers import CLIPModel, CLIPProcessor
from torch.nn import functional as F
import cv2
from tqdm import tqdm
from typing import List, Tuple, Optional
import warnings
import subprocess
from torch.amp import autocast
from PIL import Image
warnings.filterwarnings('ignore')


class CLIPVideoFeatureExtractor:
    """
    CLIP Frame-Level Feature Extractor với:
    - Xử lý từng frame riêng biệt như một image
    - Batch processing cho nhiều frames cùng lúc
    - FFMPEG cho video loading nhanh hơn
    - Mixed precision training
    - Memory management tối ưu
    """
    
    def __init__(self, 
                 checkpoint_path: str = "/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model",
                 device: str = 'cuda' if torch.cuda.is_available() else 'cpu', 
                 batch_size: int = 32):
        self.device = device
        self.batch_size = batch_size
        self.checkpoint_path = checkpoint_path
        
        print(f"Loading CLIP model from {checkpoint_path}...")
        
        # Load CLIP model và processor
        self.model = CLIPModel.from_pretrained(
            checkpoint_path,
            torch_dtype=torch.float16,  # Mixed precision
        ).to(device)
        
        self.processor = CLIPProcessor.from_pretrained(checkpoint_path)
        
        # Set model to eval mode
        self.model.eval()
        
        # Get embedding dimension from config
        self.embed_dim = self.model.config.projection_dim  # 512 từ config
        self.vision_embed_dim = self.model.config.vision_config.hidden_size  # 768
        
        print(f"CLIP Model loaded:")
        print(f"  - Vision embedding dim: {self.vision_embed_dim}")
        print(f"  - Projection dim: {self.embed_dim}")
        print(f"  - Batch size: {batch_size}")
        print(f"  - Device: {device}")
    
    def load_video_with_ffmpeg(self, video_path: str, target_fps: int = 2) -> np.ndarray:
        """
        Sử dụng FFMPEG để load video nhanh hơn OpenCV
        """
        print(f"Loading video with FFMPEG at {target_fps} FPS...")
        width, height = 398, 224
        
        cmd = [
            'ffmpeg',
            '-i', video_path,
            '-vf', f'fps={target_fps},scale={width}:{height}',
            '-f', 'image2pipe',
            '-pix_fmt', 'rgb24',
            '-vcodec', 'rawvideo',
            '-'
        ]
        
        pipe = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=10**8)
        
        frames = []
        while True:
            raw_frame = pipe.stdout.read(width * height * 3)
            if not raw_frame:
                break
            frame = np.frombuffer(raw_frame, dtype=np.uint8).reshape((height, width, 3))
            frames.append(frame)
        
        pipe.stdout.close()
        pipe.wait()
        
        if not frames:
            return np.zeros((0, 398, 224, 3))
        
        frames_array = np.array(frames)
        print(f"Loaded {len(frames_array)} frames")
        return frames_array  # Shape: (T, H, W, C)
    
    def preprocess_batch_frames(self, frames_batch: np.ndarray) -> Optional[torch.Tensor]:
        """
        Preprocess một batch các frames cùng lúc cho CLIP
        
        Args:
            frames_batch: (batch_size, H, W, C) numpy array
            
        Returns:
            processed_batch: torch.Tensor trên device
        """
        try:
            # Convert numpy frames to PIL Images
            pil_images = []
            for frame in frames_batch:
                pil_image = Image.fromarray(frame.astype(np.uint8))
                pil_images.append(pil_image)
            
            # Process batch với CLIP processor
            processed = self.processor(
                images=pil_images,
                return_tensors="pt",
                padding=True
            )
            
            return processed['pixel_values'].to(self.device)
            
        except Exception as e:
            print(f"ERROR in batch preprocessing: {e}")
            return None
    
    def extract_features_batch_frames(self, frames_batch: torch.Tensor, use_projection: bool = True) -> torch.Tensor:
        """
        Extract features cho một batch các frames cùng lúc
        
        Args:
            frames_batch: (batch_size, 3, 224, 224) tensor
            use_projection: True để lấy projected features (512d), False để lấy vision features (768d)
            
        Returns:
            features: (batch_size, embed_dim) tensor
        """
        batch_size = frames_batch.shape[0]
        
        with torch.no_grad():
            with autocast(device_type='cuda', dtype=torch.float16):
                try:
                    # Get vision features
                    vision_outputs = self.model.vision_model(pixel_values=frames_batch)
                    
                    if use_projection:
                        # Lấy [CLS] token và project qua visual_projection
                        pooled_output = vision_outputs.pooler_output  # (batch, 768)
                        features = self.model.visual_projection(pooled_output)  # (batch, 512)
                    else:
                        # Chỉ lấy raw vision features từ [CLS] token
                        features = vision_outputs.pooler_output  # (batch, 768)
                    
                    return features.float()  # Convert về float32 để tránh precision issues
                    
                except Exception as e:
                    print(f"ERROR in batch feature extraction: {e}")
                    embed_dim = self.embed_dim if use_projection else self.vision_embed_dim
                    return torch.zeros((batch_size, embed_dim), device=self.device)

    def extract_features_from_video(
        self, 
        video_frames: np.ndarray,
        use_projection: bool = True
    ) -> torch.Tensor:
        """
        Extract features từ toàn bộ video với batch processing
        
        Args:
            video_frames: (num_frames, H, W, C) numpy array
            use_projection: True cho 512d features, False cho 768d features
            
        Returns:
            features: (num_frames, embed_dim) tensor
        """
        total_frames = video_frames.shape[0]
        embed_dim = self.embed_dim if use_projection else self.vision_embed_dim
        
        print(f"Extracting {'projected' if use_projection else 'vision'} features from {total_frames} frames")
        print(f"Output dimension: {embed_dim}")
        print(f"Batch size: {self.batch_size}")
        
        all_features = []
        
        with torch.no_grad():
            # Process frames in batches
            for batch_start in tqdm(range(0, total_frames, self.batch_size), 
                                  desc="Processing frame batches"):
                batch_end = min(batch_start + self.batch_size, total_frames)
                
                # Get batch of frames
                frames_batch = video_frames[batch_start:batch_end]  # (batch, H, W, C)
                
                # Preprocess batch
                processed_batch = self.preprocess_batch_frames(frames_batch)
                
                if processed_batch is not None:
                    # Extract features for entire batch
                    batch_features = self.extract_features_batch_frames(
                        processed_batch, 
                        use_projection=use_projection
                    )
                    all_features.append(batch_features.cpu())
                else:
                    # Fallback: zero features
                    batch_size = len(frames_batch)
                    zero_features = torch.zeros((batch_size, embed_dim))
                    all_features.append(zero_features)
        
        if not all_features:
            return torch.zeros((0, embed_dim))
        
        final_features = torch.cat(all_features, dim=0)  # (total_frames, embed_dim)
        
        print(f"Final features shape: {final_features.shape}")
        return final_features

    def calculate_video_duration_and_frames(self, video_path: str, target_fps: int = 2) -> tuple:
        """
        Tính toán thời lượng video và số frames dự kiến
        """
        import subprocess
        
        # Sử dụng ffprobe để lấy thông tin video
        cmd = [
            'ffprobe', '-v', 'error', '-show_entries', 
            'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 
            video_path
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            duration_seconds = float(result.stdout.strip())
            duration_minutes = duration_seconds / 60
            expected_frames = int(duration_seconds * target_fps)
            
            print(f"Video duration: {duration_minutes:.1f} minutes ({duration_seconds:.1f} seconds)")
            print(f"Expected frames at {target_fps} FPS: {expected_frames}")
            
            return duration_minutes, expected_frames
            
        except Exception as e:
            print(f"Could not get video duration: {e}")
            return None, None

def has_exactly_two_mkv_files(directory: str) -> bool:
    count = 0
    with os.scandir(directory) as entries:
        for entry in entries:
            # Check if the current entry is a file and ends with ".mkv"
            if entry.is_file() and entry.name.endswith(".mkv"):
                count += 1
                # Exit early if more than two such files are found
                if count > 2:
                    return False
    return count == 2
def list_end_directories(path: str) -> list:
    """
    Recursively traverse a directory and 
    return all paths that are files (end of branch).
    """
    end_files = []
    for root, _, files in os.walk(path):
        for file in files:
            if file.startswith('SoccerNetV2'):                
                pass
            else:
                refined_path = os.path.join(root, file)
                # print(refined_path)
                # if has_exactly_two_mkv_files(refined_path):
                end_files.append(refined_path)
    end_files = ["/".join(file.split("/")[:-1]) for file in end_files]
    end_files = [item for item in end_files if has_exactly_two_mkv_files(item)]
    end_files = sorted(list(set(end_files)))
    return end_files
# ==================== MAIN EXECUTION ====================
if __name__ == "__main__":
    try:
        print("="*60)
        print("CLIP FRAME-LEVEL FEATURE EXTRACTION")
        print("="*60)
        
        # Initialize extractor
        extractor = CLIPVideoFeatureExtractor(
            checkpoint_path="/home/thiendc/projects/video_summarization/v5/openvocab_clipvit/best_model",
            batch_size=64  # Có thể tăng cao hơn vì chỉ xử lý single frames
        )
        games = []
        list_games = list_end_directories("/home/storage/thiendc/soccernet/train")
        for item in list_games:
            item_1 = os.path.join("/home/storage/thiendc/soccernet/train", item, "1_224p.mkv")
            item_2 = os.path.join("/home/storage/thiendc/soccernet/train", item, "2_224p.mkv")
            games.append(item_1)
            games.append(item_2)
        games = games[:300]
        
        for game in tqdm(games):
            video_path = game
            
            # Extract video number and directory
            video_dir = os.path.dirname(video_path)         # "/home/.../2015-05-17 - 18-00 Manchester United 1 - 1 Arsenal/"
            video_filename = os.path.basename(video_path)   # "1_224p.mkv"
            video_number = video_filename.split('_')[0]     # "1"
            
            print(f"Processing video: {video_filename}")
            print(f"Video number: {video_number}")
            print(f"Video directory: {video_dir}")
            
            # Tính toán thông tin video
            duration_min, expected_frames = extractor.calculate_video_duration_and_frames(video_path, target_fps=1)
            
            print("\n" + "="*50)
            print("Loading video frames...")
            
            # Load video với FFMPEG
            video_frames = extractor.load_video_with_ffmpeg(video_path, target_fps=1)
            
            print(f"Actual loaded frames: {video_frames.shape[0]}")
            print(f"Frame shape: {video_frames.shape[1:]}")
            
            print("\n" + "="*50)
            print("Extracting CLIP features...")
            
            # Extract features với raw vision features (768 dimensions)
            features_768d = extractor.extract_features_from_video(
                video_frames=video_frames,
                use_projection=True  # Lấy 768D features
            )
            
            print("\n" + "="*50)
            print("Saving results...")
            
            # Create output path in the same directory as video
            output_filename = f"{video_number}_CLIP_ViT.npy"
            output_path = os.path.join(video_dir, output_filename)
            
            # Save features
            features_numpy = features_768d.cpu().numpy()
            np.save(output_path, features_numpy)
            print(f"CLIP features saved to: {output_path}")
            print(f"Features shape: {features_numpy.shape}")
            
            # Kiểm tra file đã được tạo thành công
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path) / (1024*1024)  # MB
                print(f"- File successfully created: {file_size:.1f} MB")
            else:
                print(f"- ERROR: File was not created!")
        
    except Exception as e:
        print(f"Error occurred: {e}")
        import traceback
        traceback.print_exc()
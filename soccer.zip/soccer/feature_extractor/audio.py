import os
os.environ["CUDA_VISIBLE_DEVICES"] = "6"

import librosa
import numpy as np
import torch
import torch.nn as nn
import cv2
import panns_inference
from panns_inference import AudioTagging
from tqdm import tqdm
import warnings
import subprocess
import json
from typing import List, Tuple, Optional
import math

warnings.filterwarnings("ignore")

from feature_extractor.utils import list_end_directories

def get_video_info_ffmpeg(video_path):
    """
    Sử dụng ffprobe để đọc thông tin video - nhanh và chính xác hơn
    """
    try:
        # Sử dụng ffprobe để lấy thông tin video
        cmd = [
            'ffprobe',
            '-v', 'quiet',
            '-print_format', 'json',
            '-show_format',
            '-show_streams',
            video_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        # Tìm video stream
        video_stream = None
        for stream in data['streams']:
            if stream['codec_type'] == 'video':
                video_stream = stream
                break
        
        if video_stream is None:
            raise ValueError(f"Không tìm thấy video stream trong: {video_path}")
        
        # Lấy thông tin từ ffprobe
        duration = float(data['format']['duration'])
        
        # FPS có thể ở dạng fraction như "25/1" hoặc số thập phân
        fps_str = video_stream.get('r_frame_rate', video_stream.get('avg_frame_rate', '25/1'))
        if '/' in fps_str:
            num, den = map(int, fps_str.split('/'))
            fps = num / den if den != 0 else 25.0
        else:
            fps = float(fps_str)
        
        # Tính frame count
        frame_count = int(duration * fps)
        
        return duration, fps, frame_count
        
    except (subprocess.CalledProcessError, json.JSONDecodeError, KeyError, ValueError) as e:
        print(f"⚠️  FFprobe failed for {video_path}: {e}")
        print("🔄 Fallback to OpenCV...")
        # Fallback to OpenCV nếu ffprobe fail
        return get_video_info_opencv(video_path)

def get_video_info_opencv(video_path):
    """
    Fallback method using OpenCV
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Không thể mở video: {video_path}")
    
    video_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_duration = frame_count / video_fps
    
    cap.release()
    return video_duration, video_fps, frame_count

def prepare_audio_segments_batch(
    audio: np.ndarray,
    timestamps: np.ndarray,
    audio_window: float,
    sampling_rate: int,
    video_duration: float
) -> np.ndarray:
    """
    Chuẩn bị tất cả audio segments trong một batch để xử lý song song
    """
    segment_samples = int(audio_window * sampling_rate)
    half_window = audio_window / 2
    total_audio_samples = len(audio)
    num_frames = len(timestamps)
    
    # Tạo batch array để chứa tất cả segments
    batch_segments = np.zeros((num_frames, segment_samples), dtype=np.float32)
    
    print(f"🔄 Preparing {num_frames} audio segments for batch processing...")
    
    for i, t in enumerate(timestamps):
        # Centered segment cho từng timestamp
        start_time = max(0, t - half_window)
        end_time = min(video_duration, t + half_window)
        
        start_sample = int(round(start_time * sampling_rate))
        end_sample = int(round(end_time * sampling_rate))
        
        # Padding và boundary handling
        pad_left = 0
        pad_right = 0
        
        if start_sample < 0:
            pad_left = -start_sample
            start_sample = 0
        if end_sample > total_audio_samples:
            pad_right = end_sample - total_audio_samples
            end_sample = total_audio_samples
        
        # Extract audio segment
        if start_sample < total_audio_samples and end_sample > 0:
            segment = audio[start_sample:end_sample]
        else:
            segment = np.array([])
        
        # Padding để đảm bảo đúng kích thước
        target_length = segment_samples
        current_length = len(segment)
        
        if current_length < target_length:
            total_pad = target_length - current_length
            pad_left += total_pad // 2
            pad_right += total_pad - (total_pad // 2)
        
        if pad_left > 0 or pad_right > 0:
            segment = np.pad(segment, (pad_left, pad_right), mode='constant')
        
        if len(segment) > segment_samples:
            segment = segment[:segment_samples]
        
        batch_segments[i] = segment
    
    return batch_segments

class LinearProjection(nn.Module):
    """
    Linear projection layer để giảm embedding dimension từ 2048 → 768
    """
    def __init__(self, input_dim: int = 2048, output_dim: int = 768):
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=True)
        
        # Xavier initialization cho better convergence
        nn.init.xavier_uniform_(self.linear.weight)
        nn.init.zeros_(self.linear.bias)
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        
    def forward(self, x):
        """
        x: (..., input_dim) -> (..., output_dim)
        """
        return self.linear(x)

def get_linear_projection_layer(
    device: str, 
    input_dim: int = 2048, 
    output_dim: int = 768
) -> LinearProjection:
    """
    Tạo và khởi tạo linear projection layer
    """
    layer = LinearProjection(input_dim, output_dim)
    layer.to(device)
    layer.eval()  # Set to evaluation mode
    return layer

def reduce_embedding_dimension_linear(
    embeddings: np.ndarray, 
    linear_layer: Optional[LinearProjection] = None,
    device: str = "cpu",
    target_dim: int = 768
) -> np.ndarray:
    """
    Giảm dimension của embeddings từ 2048 về target_dim (768) sử dụng linear projection
    """
    original_shape = embeddings.shape
    input_dim = original_shape[-1]
    
    if input_dim == target_dim:
        return embeddings
    
    # Tạo linear layer nếu chưa có
    if linear_layer is None:
        linear_layer = get_linear_projection_layer(device, input_dim, target_dim)
    
    # Convert to tensor
    embeddings_tensor = torch.from_numpy(embeddings).to(device)
    
    # Apply linear projection
    with torch.no_grad():
        projected = linear_layer(embeddings_tensor)
    
    # Convert back to numpy
    projected_np = projected.cpu().numpy()
    
    return projected_np

def process_audio_batch_panns(
    panns_model: AudioTagging,
    batch_segments: np.ndarray,
    batch_size: int = 32,
    feature_dim: int = 768,
    device: str = "cpu"
) -> np.ndarray:
    """
    Xử lý batch audio segments với PANNs model và linear projection
    """
    num_segments = batch_segments.shape[0]
    features = np.zeros((num_segments, feature_dim), dtype=np.float32)
    
    # Tạo linear projection layer một lần cho toàn bộ batch
    linear_layer = None
    if feature_dim != 2048:
        linear_layer = get_linear_projection_layer(device, 2048, feature_dim)
        print(f"🔧 Created linear projection layer: 2048 → {feature_dim}")
    
    # Chia thành các mini-batches để tránh OOM
    num_batches = math.ceil(num_segments / batch_size)
    
    print(f"🚀 Processing {num_segments} segments in {num_batches} batches (batch_size={batch_size})...")
    
    with torch.no_grad():
        for batch_idx in tqdm(range(num_batches), desc="Processing batches", leave=False):
            start_idx = batch_idx * batch_size
            end_idx = min(start_idx + batch_size, num_segments)
            
            # Lấy batch hiện tại
            current_batch = batch_segments[start_idx:end_idx]
            current_batch_size = current_batch.shape[0]
            
            try:
                # PANNs inference với batch
                # Shape: (batch_size, samples)
                _, embeddings = panns_model.inference(current_batch)
                
                # Linear projection: (batch_size, 2048) -> (batch_size, 768)
                if feature_dim != 2048 and linear_layer is not None:
                    embeddings = reduce_embedding_dimension_linear(
                        embeddings, linear_layer, device, feature_dim
                    )
                
                features[start_idx:end_idx] = embeddings
                
            except Exception as e:
                print(f"⚠️  Batch {batch_idx} inference error: {e}")
                # Fallback: xử lý từng sample trong batch này
                for i in range(current_batch_size):
                    try:
                        segment = current_batch[i:i+1]  # Keep batch dimension
                        _, embedding = panns_model.inference(segment)
                        
                        # Linear projection for single sample
                        if feature_dim != 2048 and linear_layer is not None:
                            embedding = reduce_embedding_dimension_linear(
                                embedding, linear_layer, device, feature_dim
                            )
                        
                        features[start_idx + i] = embedding.squeeze(0)
                    except Exception as e2:
                        print(f"⚠️  Sample {start_idx + i} error: {e2}")
                        # Zero vector fallback
                        features[start_idx + i] = np.zeros(feature_dim, dtype=np.float32)
    
    return features

def get_optimal_batch_size(device: str, available_memory_gb: float = None) -> int:
    """
    Tính toán batch size tối ưu dựa trên device và memory available
    """
    if device == "cpu":
        return 16  # CPU processing thường chậm hơn, batch size nhỏ hơn
    
    # GPU batch size estimation
    if available_memory_gb is None:
        if torch.cuda.is_available():
            # Ước tính memory available
            total_memory = torch.cuda.get_device_properties(0).total_memory / 1e9  # GB
            available_memory_gb = total_memory * 0.7  # Dành 70% memory cho batch processing
        else:
            available_memory_gb = 8.0  # Default fallback
    
    # PANNs + Linear projection memory usage ước tính:
    # - PANNs model: ~80MB
    # - Linear layer: ~6MB (2048*768*4 bytes)
    # - Per sample (16kHz, 2s): ~128KB input + ~4KB output (768-dim)
    # - Overhead: 2x
    memory_per_sample_mb = 0.4  # MB per sample with overhead + linear layer
    
    estimated_batch_size = int(available_memory_gb * 1000 / memory_per_sample_mb)
    
    # Clamp to reasonable range
    batch_size = max(8, min(estimated_batch_size, 128))
    
    print(f"💻 Estimated optimal batch_size: {batch_size} (device: {device}, mem: {available_memory_gb:.1f}GB)")
    return batch_size

def get_panns_model_16k(device: str) -> AudioTagging:
    """
    Load PANNs model optimized for 16kHz
    """
    try:
        # Sử dụng 16kHz model nếu có
        print("🔄 Attempting to load 16kHz PANNs model...")
        # Note: PANNs inference có thể cần custom config cho 16kHz
        # Fallback to default model nhưng sẽ resample internally
        model = AudioTagging(checkpoint_path=None, device=device)
        print(f"✅ PANNs model loaded (will handle 16kHz resampling internally)")
        return model
    except Exception as e:
        print(f"⚠️  Failed to load PANNs model: {e}")
        raise

def create_dummy_audio_features(
    target_num_frames: int,
    feature_dim: int = 768,
    strategy: str = "gaussian"
) -> np.ndarray:
    """
    Tạo dummy audio features
    """
    if strategy == "gaussian":
        return np.random.normal(0, 0.01, (target_num_frames, feature_dim)).astype(np.float32)
    else:
        return np.zeros((target_num_frames, feature_dim), dtype=np.float32)

def extract_audio_features_with_alignment(
    video_path: str,
    panns_model: AudioTagging,
    device: str = "cpu",
    fps: int = 2,
    audio_window: float = 2.0,
    sampling_rate: int = 16000,
    feature_dim: int = 768,
    batch_size: int = 32,
    min_duration: float = 1.0,
    max_duration_diff: float = 5.0,
    dummy_strategy: str = "gaussian"
) -> Tuple[np.ndarray, np.ndarray, float, int]:
    """
    Trích xuất audio features với dummy features cho duration mismatch > 5s
    """
    # Đọc thông tin video
    video_duration, video_fps, video_frame_count = get_video_info_ffmpeg(video_path)
    
    print(f"📹 Video: {os.path.basename(video_path)} | Duration: {video_duration:.1f}s | FPS: {video_fps:.1f}")
    
    # Calculate target frames
    target_num_frames = max(1, int(video_duration * fps))
    
    # Check điều kiện cần dummy features
    need_dummy = False
    dummy_reason = ""
    
    # Check 1: Video quá ngắn
    if video_duration < min_duration:
        need_dummy = True
        dummy_reason = "video_too_short"
        print(f"⚠️  Video too short ({video_duration:.1f}s < {min_duration}s)")
    
    # Check 2: Extract audio và check duration difference
    if not need_dummy:
        try:
            audio, sr = librosa.load(video_path, sr=sampling_rate)
            audio_duration = len(audio) / sampling_rate
            print(f"🎵 Audio duration: {audio_duration:.2f} giây (SR: {sampling_rate}Hz)")
            
            # Check duration difference
            duration_diff = abs(video_duration - audio_duration)
            print(f"📊 Duration diff: {duration_diff:.2f}s")
            
            if duration_diff > max_duration_diff:
                need_dummy = True
                dummy_reason = "duration_mismatch"
                print(f"❌ Duration mismatch too large ({duration_diff:.2f}s > {max_duration_diff}s)")
                print(f"   Video: {video_duration:.2f}s vs Audio: {audio_duration:.2f}s")
            
        except Exception as e:
            need_dummy = True
            dummy_reason = "audio_extraction_failed"
            print(f"❌ Audio extraction failed: {e}")
    
    # Tạo dummy features nếu cần
    if need_dummy:
        print(f"🎭 Creating dummy features: {dummy_reason}")
        
        dummy_features = create_dummy_audio_features(
            target_num_frames=target_num_frames,
            feature_dim=feature_dim,
            strategy=dummy_strategy
        )
        
        dummy_timestamps = np.linspace(0, video_duration, target_num_frames, endpoint=False)
        return dummy_features, dummy_timestamps, video_duration, target_num_frames
    
    # Normal processing
    print(f"✅ Duration sync OK ({duration_diff:.2f}s ≤ {max_duration_diff}s) - Processing normally")
    
    # Tính số frame cho feature extraction
    num_frames = int(video_duration * fps)
    print(f"🎯 Extracting {num_frames} features với PANNs + Linear Projection ({feature_dim}-dim)")
    
    # Timestamps 
    timestamps = np.linspace(0, video_duration, num_frames, endpoint=False)
    
    # BATCH PROCESSING: Chuẩn bị tất cả segments một lần
    batch_segments = prepare_audio_segments_batch(
        audio=audio,
        timestamps=timestamps,
        audio_window=audio_window,
        sampling_rate=sampling_rate,
        video_duration=video_duration
    )
    
    # BATCH PROCESSING: Xử lý tất cả segments với batch inference + linear projection
    features = process_audio_batch_panns(
        panns_model=panns_model,
        batch_segments=batch_segments,
        batch_size=batch_size,
        feature_dim=feature_dim,
        device=device
    )
    
    print(f"✅ Completed! Shape: {features.shape}")
    return features, timestamps, video_duration, num_frames

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🔧 Device: {device}")
    
    # Kiểm tra ffprobe có sẵn không
    try:
        subprocess.run(['ffprobe', '-version'], capture_output=True, check=True)
        print("✅ FFprobe available")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("⚠️  FFprobe not found. Please install ffmpeg")
        print("   Ubuntu/Debian: sudo apt install ffmpeg")
        print("   macOS: brew install ffmpeg")
        print("   Will use OpenCV as fallback")
    
    # Kiểm tra và cài đặt panns_inference
    try:
        import panns_inference
        print("✅ panns_inference already installed")
    except ImportError:
        print("❌ panns_inference not found!")
        print("📦 Please install: pip install panns-inference")
        return
    
    # Tính toán batch size tối ưu
    optimal_batch_size = get_optimal_batch_size(str(device))
    
    list_games = list_end_directories("/home/storage/thiendc/soccernet/train")
    
    games = []
    for item in list_games:
        item_1 = os.path.join("/home/storage/thiendc/soccernet/train", item, "1_224p.mkv")
        item_2 = os.path.join("/home/storage/thiendc/soccernet/train", item, "2_224p.mkv")
        games.append(item_1)
        games.append(item_2)
    
    print("🚀 Loading PANNs model for 16kHz...")
    # Initialize PANNs model optimized for 16kHz
    panns_model = get_panns_model_16k(str(device))
    print(f"🧠 PANNs model loaded! Using device: {device}")
    
    # Processing videos
    for video_path in tqdm(games, desc="🎬 Processing videos"):
        print(f"\n🎬 Processing: {os.path.basename(video_path)}")
        video_base = os.path.dirname(video_path)
        
        # EXTRACT FEATURES với duration diff check
        features, timestamps, video_duration, num_frames = extract_audio_features_with_alignment(
            video_path=video_path,
            panns_model=panns_model,
            device=str(device),
            fps=2,
            audio_window=2.0,
            sampling_rate=16000,
            feature_dim=768,
            batch_size=optimal_batch_size,
            min_duration=1.0,         # Minimum 1 second
            max_duration_diff=5.0,    # Max 5 seconds difference
            dummy_strategy="zeros"  # Use small Gaussian noise
        )
        
        # Save features
        prefix = "1_" if video_path.endswith("1_224p.mkv") else "2_"
        filename = f"{prefix}AST.npy"
        save_path = os.path.join(video_base, filename)
        np.save(save_path, features)
        
        print(f"💾 Saved: {filename} | Shape: {features.shape}")

if __name__ == "__main__":
    main()

import torch
import librosa
import numpy as np
import os
import subprocess
import tempfile
from tqdm import tqdm
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(name="log_mel_spectrogram.log")


def has_exactly_two_mkv_files(directory: str) -> bool:
    count = 0
    with os.scandir(directory) as entries:
        for entry in entries:
            # Check if the current entry is a file and ends with ".mkv"
            if entry.is_file() and entry.name.endswith(".mkv"):
                count += 1
                # Exit early if more than two such files are found
                if count > 2:
                    return False
    return count == 2

def list_end_directories(path: str) -> list:
    """
    Recursively traverse a directory and 
    return all paths that are files (end of branch).
    """
    end_files = []
    for root, _, files in os.walk(path):
        for file in files:
            if file.startswith('SoccerNetV2'):                
                pass
            else:
                refined_path = os.path.join(root, file)
                end_files.append(refined_path)
    end_files = ["/".join(file.split("/")[:-1]) for file in end_files]
    end_files = [item for item in end_files if has_exactly_two_mkv_files(item)]
    end_files = sorted(list(set(end_files)))
    return end_files

def extract_log_mel_spectrogram_from_video(
    video_path, 
target_sr=16000, 
n_fft= 400, 
hop_length=160, 
n_mels=128,
log_offset=1e-10, 
max_log_value=7430.77, 
db_range=80.0
):
    """
    Trích xuất Log-Mel Spectrogram từ video với zero_filled strategy cho trường hợp không có âm thanh
    """
    if not os.path.exists(video_path):
        print(f"Lỗi: File video không tồn tại tại '{video_path}'")
        return _create_zero_filled_spectrogram(n_mels)

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as temp_wav_file:
        temp_wav_path = temp_wav_file.name
        
        try:
            # --- BƯỚC 1: TRÍCH XUẤT ÂM THANH BẰNG FFMPEG ---
            print(f"Đang dùng ffmpeg để trích xuất âm thanh từ '{video_path}' ra file tạm...")
            
            command = [
                'ffmpeg',
                '-i', video_path,
                '-hide_banner', '-loglevel', 'error',
                '-y',
                '-vn',
                '-acodec', 'pcm_s16le',
                '-ar', str(target_sr),
                '-ac', '1',
                temp_wav_path
            ]
            
            subprocess.run(command, check=True)

            # --- BƯỚC 2: ĐỌC FILE WAV VÀ XỬ LÝ ---
            print(f"Đang đọc và xử lý file âm thanh tạm '{temp_wav_path}'...")
            
            audio_waveform, sr = librosa.load(temp_wav_path, sr=target_sr, mono=True)

            # Kiểm tra nếu không có âm thanh
            if audio_waveform.size == 0:
                print(f"Cảnh báo: File âm thanh trích xuất được từ '{video_path}' là rỗng. Tạo zero-filled spectrogram.")
                return _create_zero_filled_spectrogram(n_mels)

            # --- XỬ LÝ BÌNH THƯỜNG ---
            print("Đang chuyển đổi waveform thành Mel Spectrogram...")
            mel_spectrogram = librosa.feature.melspectrogram(
                y=audio_waveform,
                sr=sr,
                n_fft=n_fft,
                hop_length=hop_length,
                n_mels=n_mels
            )
            
            mel_tensor = torch.from_numpy(mel_spectrogram.T).float()
            
            print("Đang chuẩn hóa thành Log-Mel Spectrogram...")
            log_mel_tensor = 10.0 * (torch.log10(torch.maximum(torch.tensor(log_offset), mel_tensor)) - torch.log10(torch.tensor(max_log_value)))
            
            max_val = torch.max(log_mel_tensor)
            normalized_log_mel = torch.maximum(log_mel_tensor, max_val - db_range)
            
            print(f"Trích xuất thành công! Shape của Log-Mel Spectrogram: {normalized_log_mel.shape}")
            
            return normalized_log_mel

        except subprocess.CalledProcessError:
            print(f"Cảnh báo: ffmpeg không thể trích xuất luồng âm thanh từ '{video_path}'. Video có thể không có âm thanh.")
            print("Tạo zero-filled spectrogram thay thế.")
            return _create_zero_filled_spectrogram(n_mels)
            
        except Exception as e:
            import traceback
            print(f"Đã xảy ra một lỗi không mong muốn khi xử lý video '{video_path}': {e}")
            traceback.print_exc()
            print("Tạo zero-filled spectrogram thay thế.")
            return _create_zero_filled_spectrogram(n_mels)


def _create_zero_filled_spectrogram(n_mels=128):
    """
    Tạo zero-filled Log-Mel Spectrogram cho trường hợp không có âm thanh
    """
    dummy_frames = 100  # Tương đương ~1 giây audio ở 16kHz với hop_length=160
    zero_array = np.zeros((dummy_frames, n_mels), dtype=np.float32)
    print(f"Tạo zero-filled spectrogram với shape: {zero_array.shape}")
    return torch.from_numpy(zero_array)


# --- Ví dụ sử dụng ---
if __name__ == '__main__':

    
    list_games = list_end_directories("/home/storage/thiendc/soccernet/train")
    
    games = []
    for item in list_games:
        item_1 = os.path.join("/home/storage/thiendc/soccernet/train", item, "1_224p.mkv")
        item_2 = os.path.join("/home/storage/thiendc/soccernet/train", item, "2_224p.mkv")
        games.append(item_1)
        games.append(item_2)
    
    games = games[300:]
    
    for video_file_path in tqdm(games, desc="Trích xuất Log-Mel Spectrogram"):
        log_mel_spectrogram_tensor = extract_log_mel_spectrogram_from_video(video_file_path)
        
        if log_mel_spectrogram_tensor is not None:
            # Lưu trực tiếp vào file AST.npy
            video_filename = os.path.basename(video_file_path)  # "1_224p.mkv" hoặc "2_224p.mkv"
            prefix = video_filename.split('_')[0]  # "1" hoặc "2"
            
            output_npy_path = os.path.join(os.path.dirname(video_file_path), f"{prefix}_AST.npy")
            np.save(output_npy_path, log_mel_spectrogram_tensor.numpy())
            print(f"\nĐã lưu Log-Mel Spectrogram vào file '{output_npy_path}'")
            
            print("\n--- Thông tin Tensor ---")
            print(f"Kiểu dữ liệu: {log_mel_spectrogram_tensor.dtype}")
            print(f"Shape: {log_mel_spectrogram_tensor.shape}")
            print(f"Giá trị Min: {torch.min(log_mel_spectrogram_tensor):.2f}")
            print(f"Giá trị Max: {torch.max(log_mel_spectrogram_tensor):.2f}")
            
            # Kiểm tra xem có phải zero-filled không
            if torch.all(log_mel_spectrogram_tensor == 0):
                print("⚠️  Đây là zero-filled spectrogram (video không có âm thanh)")
            else:
                print("✓ Spectrogram được trích xuất từ âm thanh thực")
        else:
            logger.info(f"Lỗi: Không thể tạo Log-Mel Spectrogram cho {video_file_path}")
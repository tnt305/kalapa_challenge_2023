import logging
import os
import time
from tqdm import tqdm
import torch
import numpy as np
from sklearn.metrics import average_precision_score
from SoccerNet.Evaluation.utils import AverageMeter, INVERSE_EVENT_DICTIONARY_V2
from SoccerNet.Evaluation.ActionSpotting import evaluate
import json
import zipfile
from torch.amp import GradScaler
from torch import autocast
from eval import pred2vec, compute_mAP
import pandas as pd
from torchvision.io import read_image
from dataset import feats2clip

def trainerAS(train_loader,
            val_loader,
            model,
            optimizer,
            scheduler,
            criterion,
            patience,
            model_name,
            max_epochs=1000,
            chunk_size=32,
            outputrate=2,
            path_experiments=None,
            eval_frequency=1):
    """
    Function to train the action spotting model (with validation early stopping)
    """

    logging.info("start training action spotting")
    best_amap = 0.0
    best_loss = 0
    n_bad_epochs = 0
    
    for epoch in range(max_epochs):
        best_model_path = os.path.join(path_experiments, model_name, 'model.pth.tar')

        #Update scheduler
        scheduler.step(epoch+1)
        logging.info(optimizer.param_groups[0]['lr'])

        # train for one epoch
        loss_training = trainAS(train_loader, model, criterion, optimizer, epoch + 1, train=True, 
                                chunk_size=chunk_size, outputrate=outputrate)
        
        # 🔧 Chỉ evaluate mỗi eval_frequency epochs hoặc epoch cuối cùng
        if (epoch + 1) % eval_frequency == 0 or epoch == max_epochs - 1:
            logging.info(f"🔍 Evaluating at epoch {epoch + 1}...")
            # evaluate on validation set
            current_amap = trainAS(val_loader, model, criterion, optimizer, epoch + 1, train=False,
                                    chunk_size=chunk_size, outputrate=outputrate)
            is_better = current_amap > best_amap
            if is_better:
                best_amap = current_amap
                n_bad_epochs = 0
                logging.info(f"🎯 New best mAP: {best_amap:.4f} at epoch {epoch + 1}")
            else:
                n_bad_epochs += 1
                logging.info(f"⏳ No improvement for {n_bad_epochs} eval epochs (best: {best_amap:.4f})")
        else:
            logging.info(f"⏭️ Skipping evaluation at epoch {epoch + 1} (next eval at epoch {((epoch // eval_frequency) + 1) * eval_frequency})")
            # 🔧 THAY ĐỔI: Không tăng n_bad_epochs khi skip evaluation
            is_better = False

        state = {
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'best_loss': best_loss,
            'best_amap': best_amap,
            'optimizer': optimizer.state_dict(),
        }
        os.makedirs(os.path.join(path_experiments, model_name), exist_ok=True)

        if (epoch + 1) % eval_frequency == 0 or epoch == max_epochs - 1:
            if is_better:
                torch.save(state, best_model_path)
                logging.info(f"💾 Saved best model at epoch {epoch + 1} with mAP: {best_amap:.4f}")

        # 🔧 THAY ĐỔI: Early stopping dựa trên eval epochs, không phải tất cả epochs
        if (epoch + 1) % eval_frequency == 0:
            if n_bad_epochs >= patience:  # patience được tính theo eval epochs
                logging.info(f"🛑 Early stopping triggered! No mAP improvement for {patience} evaluation epochs")
                logging.info(f"🏆 Best mAP achieved: {best_amap:.4f}")
                break

    return best_amap

def trainerAS_test(train_loader,
            model,
            optimizer,
            scheduler,
            criterion,
            patience,
            model_name,
            max_epochs=1000,
            chunk_size=32,
            outputrate=2,
            path_experiments=None):
    
    """
    Function to train the action spotting model (when no validation early stopping - for using all data and evaluate on challenge)
    """

    logging.info("start training action spotting")

    best_loss = 0
    n_bad_epochs = 0

    
    for epoch in range(max_epochs):
        best_model_path = os.path.join(path_experiments, model_name, 'model.pth.tar')

        #Update scheduler
        scheduler.step(epoch+1)
        logging.info(optimizer.param_groups[0]['lr'])

        # train for one epoch
        loss_training = trainAS(train_loader, model, criterion, optimizer, epoch + 1, train=True, 
                                chunk_size=chunk_size, outputrate=outputrate)
        
        state = {
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'best_loss': best_loss,
            'optimizer': optimizer.state_dict(),
        }
        os.makedirs(os.path.join(path_experiments, model_name), exist_ok=True)

        # remember best loss and save checkpoint
        is_better = True
        best_loss = max(loss_training, best_loss)

        # Save the best model based on loss only if validation improves
        if is_better:
            n_bad_epochs = 0
            torch.save(state, best_model_path)
        
        else:
            n_bad_epochs += 1

        #If doesn't improve reduce LR / finish training
        if n_bad_epochs == patience:
            break

    return

#Define train for AS part
def trainAS(dataloader,
        model,
        criterion,
        optimizer,
        epoch,
        train=False,
        chunk_size=32,
        outputrate=2):
    
    """
    Function to train/validate 1 epoch of the MEDet360 model.
    Handles the list-based output from the multi-branch model.
    """

    batch_time = AverageMeter()
    data_time = AverageMeter()

    # Meters để theo dõi tổng loss và loss thành phần
    losses = AverageMeter()
    lossesC = AverageMeter() # Sẽ là tổng lossC của 3 nhánh
    lossesD = AverageMeter() # Sẽ là tổng lossD của 3 nhánh
    
    # (Tùy chọn) Meters để theo dõi loss của từng nhánh
    losses_local = AverageMeter()
    losses_global = AverageMeter()
    losses_hybrid = AverageMeter()

    if train:
        model.train()
    else:
        model.eval()
        list_preds = []
        list_labels = []

    end = time.time()
    scaler = GradScaler()
    
    with tqdm(enumerate(dataloader), total=len(dataloader), ncols=160) as t:
        for i, data in t:
            data_time.update(time.time() - end)
            
            # --- Lấy dữ liệu và đưa lên GPU ---
            labels = data['labels'].cuda()
            labelsD = data['labels_displ'].cuda()
            featB = data['video'].cuda()
            featA = data.get('audio', None)
            if featA is not None:
                featA = featA.cuda()

            with autocast(device_type='cuda', dtype=torch.float16):
                # --- BƯỚC 1: LẤY DỰ ĐOÁN TỪ MODEL ---
                # Model sẽ trả về dictionary chứa các list
                if train:
                    output_dict = model(featsB=featB, featsA=featA, labels=labels, labelsD=labelsD, inference=False)
                else: # Validation
                    with torch.no_grad():
                        output_dict = model(featsB=featB, featsA=featA, labels=labels, labelsD=labelsD, inference=True)

                # --- BƯỚC 2: TÍNH TOÁN LOSS (LOGIC ĐÃ SỬA) ---
                total_loss = 0
                total_lossC = 0
                total_lossD = 0
                branch_losses = []

                # Lặp qua kết quả của 3 nhánh để tính loss
                for j in range(3): # 3 nhánh: local, global, hybrid
                    # Lấy TENSOR thứ j từ mỗi list
                    preds_j = output_dict['preds'][j]
                    predsD_j = output_dict['predsD'][j]
                    labels_j = output_dict['labels'][j]
                    labelsD_j = output_dict['labelsD'][j]

                    # Bây giờ truyền TENSOR vào criterion, không phải list
                    lossC_j, lossD_j = criterion(labels_j, preds_j, labelsD_j, predsD_j)
                    
                    # Cộng dồn loss từ các nhánh
                    branch_loss = lossC_j + lossD_j
                    total_loss += branch_loss
                    total_lossC += lossC_j
                    total_lossD += lossD_j
                    branch_losses.append(branch_loss.item())

            # --- BƯỚC 3: BACKPROPAGATION (chỉ khi train) ---
            if train:
                scaler.scale(total_loss).backward()
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()
            
            # --- BƯỚC 4: CẬP NHẬT METRICS VÀ ĐÁNH GIÁ ---
            losses.update(total_loss.item(), labels.size(0))
            lossesC.update(total_lossC.item(), labels.size(0))
            lossesD.update(total_lossD.item(), labels.size(0))
            losses_local.update(branch_losses[0], labels.size(0))
            losses_global.update(branch_losses[1], labels.size(0))
            losses_hybrid.update(branch_losses[2], labels.size(0))

            if not train:
                # Sử dụng 'full_preds' và 'full_predsD' đã được gộp để đánh giá mAP
                full_preds = output_dict['full_preds']
                full_predsD = output_dict['full_predsD']
                
                # ✅ SỬA LỖI: Model MEDet360 đã xử lý uncertainty trong inference mode
                # Không cần slice thêm vì full_predsD đã có shape 3D
                
                labs = pred2vec([labels, labelsD], chunk_size=chunk_size, outputrate=outputrate, threshold=0.2, target=True, window=4)
                for lab in labs:
                    list_labels.append(lab)
                preds = pred2vec([full_preds, full_predsD], chunk_size=chunk_size, outputrate=outputrate, threshold=0.2, NMS=True, window=4)
                for pred in preds:
                    list_preds.append(pred)

            # --- Cập nhật thanh tiến trình TQDM ---
            # ... (Phần này giữ nguyên)
            batch_time.update(time.time() - end)
            end = time.time()
            desc_prefix = f'Train {epoch}: ' if train else f'Evaluate {epoch}: '
            desc = (f'{desc_prefix}'
                    f'Time {batch_time.avg:.3f}s '
                    f'Loss {losses.avg:.3e} '
                    f'LossC {lossesC.avg:.3e} '
                    f'LossD {lossesD.avg:.3e} '
                    f'| L:{losses_local.avg:.2e} G:{losses_global.avg:.2e} H:{losses_hybrid.avg:.2e}')
            t.set_description(desc)

    if train:
        return losses.avg
    
    else:
        #Compute mAP
        amap, amap_class = compute_mAP(list_preds, list_labels, metric = "tight")
        dataframe = pd.DataFrame(amap_class).T
        dataframe.columns = ["penalty", "kick-off", "goal", "substitution", "offside", "sh. on targ.", "sh. off targ.", "clearance", "ball oop", "throw in", "foul", "ind. fk", "dir. fk", "corner", "yc", "rc", "2nd yc"]
        # Lưu CSV đơn giản
        try:
            csv_path = f"validation_{model.model_cfg['name']}_{epoch}_amap_{amap:.4f}.csv"
            dataframe.to_csv(csv_path, index=False)
            logging.info(f"✅ Saved: {csv_path}")
        except:
            pass
        logging.info('aMAP:' + str(amap))

        # wandb.log({"per_epoch/val/epoch": epoch, "per_epoch/val/ASloss":losses.avg, "per_epoch/val/ASlossC":lossesC.avg, "per_epoch/val/ASlossD":lossesD.avg, "per_epoch/val/aMAP":amap})        
        return amap


def testSpotting(dataloader, model, model_name, overwrite=True, NMS_window=8, NMS_threshold=0.001, outputrate=2,
                 chunk_size=32, stride=8, postprocessing='SNMS', path_experiments=None):
    """
    Function for inference of the action spotting model (and evaluation)
    using a memory-efficient sliding window approach with robust data handling.
    """
    # 1. THIẾT LẬP CÁC ĐƯỜNG DẪN VÀ THƯ MỤC
    # ------------------------------------------------
    split = dataloader.dataset.split[0]
    output_folder_name = f'outputs_{split}'
    postprocessing_folder_name = f'post_{postprocessing}_window_{NMS_window}'
    
    base_results_path = os.path.join(path_experiments, model_name, postprocessing_folder_name)
    output_results_zip = os.path.join(base_results_path, f"results_spotting_{split}.zip")
    output_json_folder = os.path.join(base_results_path, output_folder_name)

    # Chỉ chạy nếu file zip kết quả chưa tồn tại hoặc yêu cầu ghi đè
    if not os.path.exists(output_results_zip) or overwrite:
        batch_time = AverageMeter()
        data_time = AverageMeter()
        model.eval()
        end = time.time()

        # 2. VÒNG LẶP CHÍNH QUA TỪNG TRẬN ĐẤU
        # ------------------------------------------------
        with tqdm(enumerate(dataloader), total=len(dataloader), ncols=120) as t:
            for i, (game_ID, data) in t:
                # ...
                game_ID = game_ID[0]

                # --- BƯỚC 1: Tải và tạo tất cả các clip (giữ nguyên logic cũ) ---
                featB_half1_full = data['video_half1'].reshape(-1, data['video_half1'].shape[-1])
                sec1 = featB_half1_full.shape[0]
                # Chuyển đổi sang float16 ngay trên CPU để tiết kiệm bộ nhớ khi tạo clip
                featB_clips1 = feats2clip(featB_half1_full, stride=stride, clip_length=chunk_size) #.to(dtype=torch.float16)

                featB_half2_full = data['video_half2'].reshape(-1, data['video_half2'].shape[-1])
                sec2 = featB_half2_full.shape[0]
                featB_clips2 = feats2clip(featB_half2_full, stride=stride, clip_length=chunk_size)
                
                featA_clips1, featA_clips2 = None, None
                if model.audio:
                    # Xử lý audio an toàn
                    audio1 = data.get('audio_half1')
                    if audio1 is not None and audio1.numel() > 0:
                        # Chuẩn hóa shape audio
                        if audio1.ndim == 2: audio1 = audio1.unsqueeze(0)
                        audio1 = audio1.squeeze(0)
                        if audio1.shape[0] > audio1.shape[1]: audio1 = audio1.T
                        # Tạo clip audio với float16
                        featA_clips1 = feats2clip(audio1.T, stride=stride * 100, clip_length=chunk_size * 100)

                    audio2 = data.get('audio_half2')
                    if audio2 is not None and audio2.numel() > 0:
                        if audio2.ndim == 2: audio2 = audio2.unsqueeze(0)
                        audio2 = audio2.squeeze(0)
                        if audio2.shape[0] > audio2.shape[1]: audio2 = audio2.T
                        featA_clips2 = feats2clip(audio2.T, stride=stride * 100, clip_length=chunk_size * 100)

                # --- BƯỚC 2: Thiết lập vòng lặp suy luận với batch size nhỏ ---
                # Giảm BS xuống giá trị rất nhỏ để thử
                INFERENCE_BS = 8
                
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

                all_halves_data = [
                    (featB_clips1, featA_clips1, sec1),
                    (featB_clips2, featA_clips2, sec2)
                ]
                timestamps_per_half = []

                for featB_clips, featA_clips, num_seconds in all_halves_data:
                    timestamp_long = np.zeros((num_seconds * outputrate, 17))
                    
                    if featB_clips is None or len(featB_clips) == 0:
                        timestamps_per_half.append(timestamp_long)
                        continue

                    num_video_clips  = len(featB_clips)
                    
                    # Vòng lặp suy luận qua các batch
                    for b_start in range(0, num_video_clips , INFERENCE_BS):
                        b_end = min(b_start + INFERENCE_BS, num_video_clips )
                        
                        # Lấy batch hiện tại và đưa lên GPU
                        # Kiểu dữ liệu đã là float16 từ trước
                        batch_featB = featB_clips[b_start:b_end].cuda()
                        
                        batch_featA = None
                        if model.audio and featA_clips is not None:
                            # Đảm bảo audio và video đồng bộ số lượng clip
                            if b_end <= len(featA_clips):
                                a_end = min(b_end, len(featA_clips)) ## I fix here
                                batch_featA = featA_clips[b_start:a_end].cuda()

                        # Suy luận với AMP
                        with autocast(device_type='cuda', dtype=torch.float16):
                            with torch.no_grad():
                                output = model(featsB=batch_featB, featsA=batch_featA, inference=True)

                        # ✅ SỬA LỖI: Sử dụng full_preds/full_predsD cho testSpotting inference
                        predC = output['full_preds'].cpu().numpy()
                        predD = output['full_predsD'].cpu().numpy()  # Đã được xử lý uncertainty trong model
                        
                        # Tích lũy kết quả (logic cũ được điều chỉnh)
                        for i, clip_idx in enumerate(range(b_start, b_end)):
                            initial_pos = clip_idx * stride * outputrate
                            nf, nc = predC.shape[1], predC.shape[2]
                            for j in range(nf):
                                for k in range(nc - 1):
                                    prob = predC[i, j, k + 1]
                                    if prob > NMS_threshold:
                                        rel_position = j - predD[i, j, k + 1]
                                        position = min(len(timestamp_long) - 1, max(0, int(round(initial_pos + rel_position))))
                                        timestamp_long[position, k] = max(timestamp_long[position, k], prob)

                        # Giải phóng bộ nhớ "hung hăng"
                        del output, predC, predD, batch_featB, batch_featA
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()

                    timestamps_per_half.append(timestamp_long)

                # Cập nhật thời gian và thanh tiến trình
                batch_time.update(time.time() - end)
                end = time.time()
                desc = f'Test (spot.): Game {i+1}/{len(dataloader)} | Time {batch_time.avg:.3f}s'
                t.set_description(desc)

                # 4. POST-PROCESSING VÀ LƯU KẾT QUẢ JSON
                # ------------------------------------------------
                if postprocessing == 'NMS':
                    get_spot = get_spot_from_NMS
                    nms_window_list = [NMS_window] * 17
                elif postprocessing == 'SNMS':
                    get_spot = get_spot_from_SNMS
                    # nms_window_list = [5, 7, 9, 12, 10, 14, 14, 5, 8, 8, 8, 8, 13, 5, 6, 6, 6]
                    nms_window_list = [9, 9, 9, 12, 14, 14, 14, 5, 8, 8, 8, 10, 13, 5, 6, 6, 6]
                json_data = {"UrlLocal": game_ID, "predictions": []}
                for half, timestamp in enumerate(timestamps_per_half):
                    for l in range(dataloader.dataset.num_classes):
                        spots = get_spot(timestamp[:, l], window=nms_window_list[l] * outputrate, thresh=NMS_threshold)
                        for spot in spots:
                            frame_index = int(spot[0])
                            confidence = spot[1]
                            seconds = int((frame_index / outputrate) % 60)
                            minutes = int((frame_index / outputrate) // 60)
                            
                            prediction_data = {
                                "gameTime": f"{half + 1} - {minutes}:{seconds:02d}",
                                "label": INVERSE_EVENT_DICTIONARY_V2[l],
                                "position": str(int((frame_index / outputrate) * 1000)),
                                "half": str(half + 1),
                                "confidence": str(confidence)
                            }
                            json_data["predictions"].append(prediction_data)
                json_data["predictions"] = sorted(
                    json_data["predictions"],
                    key=lambda x: (
                        int(x["half"]),
                        int(x["position"])  # vì position bạn lưu là mili giây
                    )
                )
                game_json_path = os.path.join(output_json_folder, game_ID)
                os.makedirs(game_json_path, exist_ok=True)
                with open(os.path.join(game_json_path, "results_spotting.json"), 'w') as output_file:
                    json.dump(json_data, output_file, indent=4)

        # 5. NÉN KẾT QUẢ THÀNH FILE ZIP
        # ------------------------------------------------
        def zipResults(zip_path, target_dir, filename="results_spotting.json"):
            zipobj = zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED)
            rootlen = len(target_dir) + 1
            for base, dirs, files in os.walk(target_dir):
                for file in files:
                    if file == filename:
                        fn = os.path.join(base, file)
                        zipobj.write(fn, fn[rootlen:])
        
        logging.info(f"Zipping results to {output_results_zip}")
        zipResults(zip_path=output_results_zip, target_dir=output_json_folder)

    # 6. ĐÁNH GIÁ KẾT QUẢ (NẾU KHÔNG PHẢI CHALLENGE SPLIT)
    # ------------------------------------------------
    if split == "challenge":
        print("Visit eval.ai to evaluate performances on Challenge set")
        return None, None
    
    logging.info("Evaluating loose metric...")
    results_l = evaluate(SoccerNet_path=dataloader.dataset.path, Predictions_path=output_results_zip,
                         split="test", prediction_file="results_spotting.json", version=2, metric="loose")
    
    logging.info("Evaluating tight metric...")
    results_t = evaluate(SoccerNet_path=dataloader.dataset.path, Predictions_path=output_results_zip,
                         split="test", prediction_file="results_spotting.json", version=2, metric="tight")
    
    return results_l, results_t


def get_spot_from_NMS(Input, window, thresh=0.0, min_window=0):
    """
    Non-Maximum Suppression
    """
    detections_tmp = np.copy(Input)
    # res = np.empty(np.size(Input), dtype=bool)
    indexes = []
    MaxValues = []
    while(np.max(detections_tmp) >= thresh):
        
        # Get the max remaining index and value
        max_value = np.max(detections_tmp)
        max_index = np.argmax(detections_tmp)
                        
        # detections_NMS[max_index,i] = max_value
        
        nms_from = int(np.maximum(-(window/2)+max_index,0))
        nms_to = int(np.minimum(max_index+int(window/2), len(detections_tmp)))
                            
        if (detections_tmp[nms_from:nms_to] >= thresh).sum() > min_window:
            MaxValues.append(max_value)
            indexes.append(max_index)
        detections_tmp[nms_from:nms_to] = -1
        
    return np.transpose([indexes, MaxValues])

def get_spot_from_SNMS(Input, window, thresh=0.0, decay = 'pow2'):
    """
    Soft Non-Maximum Suppression
    """
    detections_tmp = np.copy(Input)

    indexes = []
    MaxValues = []
    while(np.max(detections_tmp) >= thresh):

        # Get the max remaining index and value
        max_value = np.max(detections_tmp)
        max_index = np.argmax(detections_tmp)

        nms_from = int(np.maximum(-(window/2)+max_index,0))
        nms_to = int(np.minimum(max_index+int(window/2), len(detections_tmp)-1)) + 1

        MaxValues.append(max_value)
        indexes.append(max_index)

        if decay == 'linear':
            weight = np.abs(np.arange(nms_from - max_index, nms_to - max_index)) / (window / 2)
        elif decay == 'sqrt':
            weight = np.sqrt(np.abs(np.arange(nms_from - max_index, nms_to - max_index))) / np.sqrt(window / 2)
        elif decay == 'pow2':
            weight = np.power(np.abs(np.arange(nms_from - max_index, nms_to - max_index)), 2) / np.power(window / 2, 2)

        detections_tmp[nms_from:nms_to] = detections_tmp[nms_from:nms_to] * weight
        detections_tmp[nms_from:nms_to][detections_tmp[nms_from:nms_to] < thresh] = -1


    return np.transpose([indexes, MaxValues])

class LearningRateWarmUP(object):
    """
    Class to implement Learning rate warmup
    """
    def __init__(self, optimizer, warmup_iteration, target_lr, after_scheduler=None):
        self.optimizer = optimizer
        self.warmup_iteration = warmup_iteration
        self.target_lr = target_lr
        self.after_scheduler = after_scheduler
        self.step(1)

    def warmup_learning_rate(self, cur_iteration):
        warmup_lr = self.target_lr*float(cur_iteration)/float(self.warmup_iteration)
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = warmup_lr

    def step(self, cur_iteration):
        if cur_iteration <= self.warmup_iteration:
            self.warmup_learning_rate(cur_iteration)
        else:
            self.after_scheduler.step(cur_iteration-self.warmup_iteration)
    
    def load_state_dict(self, state_dict):
        self.after_scheduler.load_state_dict(state_dict)
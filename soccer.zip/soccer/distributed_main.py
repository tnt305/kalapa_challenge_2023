import os
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
import logging
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import yaml
import numpy as np
from datetime import datetime
import time

from dataset import SoccerNetClips, SoccerNetClipsTesting, create_class_balanced_sampler
from model import ASTRA
from train import testSpotting, LearningRateWarmUP
from train_distributed import trainerAS_distributed, trainAS, testSpotting, get_model_attr
from loss import ASTRALoss

def setup_distributed(rank, world_size, port='12355'):
    """Setup distributed training"""
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = port
    
    # Initialize the process group
    dist.init_process_group("nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)

def cleanup_distributed():
    """Cleanup distributed training"""
    dist.destroy_process_group()

def create_distributed_sampler(dataset, world_size, rank, shuffle=True, balanced=False):
    """Tạo sampler cho distributed training"""
    if balanced and hasattr(dataset, 'clip_class_info'):
        # Tạo balanced sampler, sau đó wrap với DistributedSampler
        # Lưu ý: Cần custom implementation cho distributed balanced sampling
        logging.warning("Balanced sampling với distributed chưa được implement đầy đủ. Sử dụng shuffle sampling.")
        return DistributedSampler(dataset, num_replicas=world_size, rank=rank, shuffle=shuffle)
    else:
        return DistributedSampler(dataset, num_replicas=world_size, rank=rank, shuffle=shuffle)

def run_decoupled_distributed_training(rank, world_size, args, cfg):
    """Main decoupled distributed training function"""
    
    # Setup distributed
    setup_distributed(rank, world_size, args.port)
    
    # Setup logging cho từng process
    if rank == 0:  # Chỉ log từ master process
        os.makedirs(os.path.join("models", args.model_name), exist_ok=True)
        log_path = os.path.join("models", args.model_name,
                               f"decoupled_distributed_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log")
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)-5.5s] [Rank {}] %(message)s".format(rank),
            handlers=[
                logging.FileHandler(log_path),
                logging.StreamHandler()
            ])
        logging.info(f"🚀 Starting DECOUPLED DISTRIBUTED training with {world_size} GPUs")
    else:
        logging.basicConfig(level=logging.WARNING)
    
    # Set seeds
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    
    # === THIẾT LẬP CHUNG ===
    model = ASTRA(chunk_size=args.window_size, 
                  n_output=int(args.framerate * args.window_size), 
                  baidu=True, audio=args.multimodal,
                  model_cfg=cfg['model']).cuda(rank)
    
    # Wrap model với DDP
    model = DDP(model, device_ids=[rank], output_device=rank, find_unused_parameters=True)
    
    criterion = ASTRALoss(wC=100, wD=1, focal=True, nw=5, uncertainty=True, uncertainty_mode='loglikelihood')
    
    if rank == 0:
        total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        logging.info(f"Total parameters: {total_params}")
    
    if not args.test_only:
        # ===== GIAI ĐOẠN 1: HUẤN LUYỆN TOÀN BỘ MÔ HÌNH =====
        if rank == 0:
            logging.info("\n===== GIAI ĐOẠN 1: HUẤN LUYỆN TOÀN BỘ MÔ HÌNH (DISTRIBUTED) =====")
        
        phase1_model_name = args.model_name + "_phase1_distributed"
        
        if not args.skip_phase1:
            # Tạo dataset
            dataset_Train_p1 = SoccerNetClips(path=args.SoccerNet_path, 
                                             frames_features=args.features, 
                                             audio_features=args.audio_features,
                                             multimodal=args.multimodal,
                                             split=args.split_train,
                                             stride=25,
                                             version=args.version, 
                                             framerate=args.framerate, 
                                             window_size=args.window_size,
                                             store=False)
            
            dataset_Valid_p1 = SoccerNetClips(path=args.SoccerNet_path, 
                                             frames_features=args.features, 
                                             audio_features=args.audio_features,
                                             multimodal=args.multimodal,
                                             split=args.split_valid,
                                             stride=25,
                                             version=args.version, 
                                             framerate=args.framerate, 
                                             window_size=args.window_size,
                                             store=False)
            
            # Tạo distributed samplers
            train_sampler_p1 = create_distributed_sampler(dataset_Train_p1, world_size, rank, shuffle=True)
            val_sampler_p1 = create_distributed_sampler(dataset_Valid_p1, world_size, rank, shuffle=False)
            
            # Tạo DataLoaders
            train_loader_p1 = torch.utils.data.DataLoader(
                dataset_Train_p1,
                batch_size=args.batch_size // world_size,
                sampler=train_sampler_p1,
                num_workers=args.max_num_worker // world_size,
                pin_memory=True
            )
            
            val_loader_p1 = torch.utils.data.DataLoader(
                dataset_Valid_p1,
                batch_size=args.batch_size // world_size,
                sampler=val_sampler_p1,
                num_workers=args.max_num_worker // world_size,
                pin_memory=True
            )
            
            # Setup optimizer và scheduler cho Phase 1
            optimizer_p1 = torch.optim.Adam(model.parameters(), 
                                          lr=args.LR * world_size,  # Scale LR
                                          weight_decay=1e-4, amsgrad=True)
            scheduler_cosine_p1 = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer_p1, args.max_epochs_p1 - cfg['warmup_iter'])
            scheduler_p1 = LearningRateWarmUP(optimizer=optimizer_p1, 
                                             warmup_iteration=3,
                                             target_lr=args.LR * world_size, 
                                             after_scheduler=scheduler_cosine_p1)
            
            # Training Phase 1
            trainerAS_distributed(train_loader_p1, val_loader_p1, model, optimizer_p1, scheduler_p1, criterion,
                                patience=args.patience, model_name=phase1_model_name,
                                max_epochs=args.max_epochs_p1, chunk_size=args.window_size,
                                outputrate=args.framerate, path_experiments=cfg['path_experiments'],
                                rank=rank, world_size=world_size, eval_frequency=args.eval_frequency)
        else:
            if rank == 0:
                logging.info("⏭️ Bỏ qua Giai đoạn 1.")
        
        # Sync trước khi chuyển sang Phase 2
        dist.barrier()
        
        # ===== GIAI ĐOẠN 2: HUẤN LUYỆN LẠI PREDICTION HEADS =====
        if rank == 0:
            logging.info("\n===== GIAI ĐOẠN 2: HUẤN LUYỆN PREDICTION HEADS (DISTRIBUTED) =====")
        
        # Load weights từ Phase 1
        best_model_phase1_path = os.path.join(cfg['path_experiments'], phase1_model_name, 'model.pth.tar')
        
        if rank == 0 and os.path.exists(best_model_phase1_path):
            logging.info(f"📥 Loading Phase 1 weights: {best_model_phase1_path}")
        
        # Tất cả ranks đều load weights
        if os.path.exists(best_model_phase1_path):
            checkpoint = torch.load(best_model_phase1_path, map_location=f'cuda:{rank}')
            model.load_state_dict(checkpoint['state_dict'])
        else:
            if rank == 0:
                logging.error(f"❌ Phase 1 checkpoint not found: {best_model_phase1_path}")
            cleanup_distributed()
            return
        
        # Đóng băng backbone (chỉ train prediction heads)
        if rank == 0:
            logging.info("🔒 Freezing backbone...")
        
        for name, param in model.named_parameters():
            if 'clas_head' not in name and 'displ_head' not in name:
                param.requires_grad = False
        
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        if rank == 0:
            logging.info(f"Trainable parameters in Phase 2: {trainable_params}")
        
        # Tạo dataset cho Phase 2
        dataset_Train_p2 = SoccerNetClips(path=args.SoccerNet_path, 
                                         frames_features=args.features, 
                                         audio_features=args.audio_features,
                                         multimodal=args.multimodal,
                                         split=args.split_train,
                                         stride=25,
                                         version=args.version, 
                                         framerate=args.framerate, 
                                         window_size=args.window_size,
                                         store=False)
        
        dataset_Valid_p2 = SoccerNetClips(path=args.SoccerNet_path, 
                                         frames_features=args.features, 
                                         audio_features=args.audio_features,
                                         multimodal=args.multimodal,
                                         split=args.split_valid,
                                         stride=25,
                                         version=args.version, 
                                         framerate=args.framerate, 
                                         window_size=args.window_size,
                                         store=False)
        
        # Distributed samplers cho Phase 2 (có thể cần balanced sampling sau này)
        train_sampler_p2 = create_distributed_sampler(dataset_Train_p2, world_size, rank, shuffle=True, balanced=True)
        val_sampler_p2 = create_distributed_sampler(dataset_Valid_p2, world_size, rank, shuffle=False)
        
        train_loader_p2 = torch.utils.data.DataLoader(
            dataset_Train_p2,
            batch_size=args.batch_size // world_size,
            sampler=train_sampler_p2,
            num_workers=args.max_num_worker // world_size,
            pin_memory=True
        )
        
        val_loader_p2 = torch.utils.data.DataLoader(
            dataset_Valid_p2,
            batch_size=args.batch_size // world_size,
            sampler=val_sampler_p2,
            num_workers=args.max_num_worker // world_size,
            pin_memory=True
        )
        
        # Optimizer chỉ cho trainable parameters
        optimizer_p2 = torch.optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()), 
            lr=args.LR_p2 * world_size,  # Scale LR
            weight_decay=1e-4
        )
        scheduler_p2 = torch.optim.lr_scheduler.StepLR(optimizer_p2, step_size=5, gamma=0.5)
        
        final_model_name = args.model_name + "_decoupled_distributed"
        
        # Training Phase 2
        trainerAS_distributed(train_loader_p2, val_loader_p2, model, optimizer_p2, scheduler_p2, criterion,
                            patience=args.patience, model_name=final_model_name,
                            max_epochs=args.max_epochs_p2, chunk_size=args.window_size,
                            outputrate=args.framerate, path_experiments=cfg['path_experiments'],
                            rank=rank, world_size=world_size, eval_frequency=2)
    else:
        if rank == 0:
            logging.info("🧪 TEST ONLY mode - skipping training")
    
    # Sync trước testing
    dist.barrier()
    
    # === TESTING (chỉ trên rank 0) ===
    if rank == 0:
        logging.info("\n===== TESTING FINAL MODEL =====")
        
        # Load model để test
        if args.load_weights:
            model_path = args.load_weights
        elif not args.test_only:
            final_model_name = args.model_name + "_decoupled_distributed"
            model_path = os.path.join(cfg['path_experiments'], final_model_name, 'model.pth.tar')
            
            # Fallback to phase1 if final doesn't exist
            if not os.path.exists(model_path):
                phase1_model_name = args.model_name + "_phase1_distributed"
                model_path = os.path.join(cfg['path_experiments'], phase1_model_name, 'model.pth.tar')
                logging.warning(f"⚠️ Using Phase 1 model for testing: {model_path}")
        
        if os.path.exists(model_path):
            # Tạo model mới không có DDP wrapper để test
            test_model = ASTRA(chunk_size=args.window_size, 
                              n_output=int(args.framerate * args.window_size), 
                              baidu=True, audio=args.multimodal,
                              model_cfg=cfg['model']).cuda()
            
            # Load state dict (remove 'module.' prefix nếu có)
            checkpoint = torch.load(model_path)
            state_dict = checkpoint['state_dict']
            new_state_dict = {}
            for k, v in state_dict.items():
                if k.startswith('module.'):
                    new_state_dict[k[7:]] = v
                else:
                    new_state_dict[k] = v
            test_model.load_state_dict(new_state_dict)
            
            # Testing
            for split in args.split_test:
                dataset_Test = SoccerNetClipsTesting(path=args.SoccerNet_path, 
                                                   frames_features=args.features, 
                                                   audio_features=args.audio_features,
                                                   multimodal=args.multimodal,
                                                   split=[split], 
                                                   version=args.version, 
                                                   framerate=args.framerate, 
                                                   window_size=args.window_size)
                
                test_loader = torch.utils.data.DataLoader(dataset_Test,
                    batch_size=1, shuffle=False, num_workers=1, pin_memory=False)
                
                results_l, results_t = testSpotting(test_loader, model=test_model, 
                                                  model_name=args.model_name, 
                                                  NMS_threshold=args.NMS_threshold,
                                                  outputrate=args.framerate, 
                                                  chunk_size=args.window_size, 
                                                  path_experiments=cfg['path_experiments'])
                
                if results_l:
                    logging.info("🏆 Final Results (loose metric):")
                    logging.info(f"a_mAP: {results_l['a_mAP']}")
                    logging.info(f"a_mAP per class: {results_l['a_mAP_per_class']}")
        else:
            logging.error(f"❌ Model not found for testing: {model_path}")
    
    # Cleanup
    cleanup_distributed()

def main():
    parser = ArgumentParser(description='Decoupled Distributed Training', 
                          formatter_class=ArgumentDefaultsHelpFormatter)
    
    # Copy tất cả arguments từ decoupled_main.py
    parser.add_argument('--SoccerNet_path', required=False, type=str, 
                       default="/home/storage/thiendc/soccernet", help='Path for SoccerNet')
    parser.add_argument('--features', required=False, type=str, 
                       default="baidu_soccer_embeddings.npy", help='Video features')
    parser.add_argument('--audio_features', required=False, type=str, 
                       default="AST.npy", help='Audio features for multimodal training')
    parser.add_argument('--multimodal', required=False, action='store_true', 
                       help='Enable multimodal training with video and audio features')
    parser.add_argument('--max_epochs', required=False, type=int, default=50, 
                       help='Maximum number of epochs')
    parser.add_argument('--load_weights', required=False, type=str, default=None, 
                       help='weights to load')
    parser.add_argument('--model_name', required=False, type=str, default="ASTRA", 
                       help='named of the model to save')
    parser.add_argument('--path_experiments', required=False, type=str, default="models", 
                       help='Path for experiments')
    parser.add_argument('--test_only', required=False, action='store_true', 
                       help='Perform testing only')
    
    # Decoupled training arguments
    parser.add_argument('--decoupled_training', action='store_true', 
                       help='Thực hiện decoupled training 2 giai đoạn.')
    parser.add_argument('--skip_phase1', action='store_true', 
                       help='Bỏ qua GĐ1 và tải trọng số đã huấn luyện.')
    parser.add_argument('--max_epochs_p1', type=int, default=40, 
                       help='Số epochs cho Giai đoạn 1.')
    parser.add_argument('--max_epochs_p2', type=int, default=10, 
                       help='Số epochs cho Giai đoạn 2.')
    parser.add_argument('--LR_p2', type=float, default=1e-5, 
                       help='Learning rate cho Giai đoạn 2.')
    parser.add_argument('--eval_frequency', type=int, default=5, 
                       help='Evaluate every N epochs')
    
    # Training parameters
    parser.add_argument('--split_train', nargs='+', default=["train"], help='list of split for training')
    parser.add_argument('--split_valid', nargs='+', default=["test"], help='list of split for validation')
    parser.add_argument('--split_test', nargs='+', default=["test"], help='list of split for testing')
    
    parser.add_argument('--version', required=False, type=int, default=2, help='Version of the dataset')
    parser.add_argument('--framerate', required=False, type=int, default=2, help='Framerate of the input features')
    parser.add_argument('--window_size', required=False, type=int, default=50, help='Size of the chunk (in seconds)')
    parser.add_argument('--NMS_threshold', required=False, type=float, default=0.01, help='NMS threshold for positive results')
    
    parser.add_argument('--batch_size', required=False, type=int, default=32, 
                       help='Total batch size (will be divided by world_size)')
    parser.add_argument('--LR', required=False, type=float, default=5e-05, help='Learning Rate')
    parser.add_argument('--patience', required=False, type=int, default=10, help='Patience before reducing LR')
    parser.add_argument('--max_num_worker', required=False, type=int, default=20, help='number of worker to load data')
    parser.add_argument('--seed', required=False, type=int, default=1, help='seed for reproducibility')
    
    # Distributed specific arguments
    parser.add_argument('--world_size', required=False, type=int, 
                       default=torch.cuda.device_count(), help='Number of GPUs to use')
    parser.add_argument('--port', required=False, type=str, default='12355', 
                       help='Port for distributed training')
    
    args = parser.parse_args()
    
    # Load config
    args.config_file = os.path.join('configs', args.model_name + '.yaml')
    with open(args.config_file, 'r') as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)
    cfg['model_name'] = args.model_name
    
    print(f"🚀 Starting DECOUPLED DISTRIBUTED training with {args.world_size} GPUs")
    print(f"📊 Phase 1: {args.max_epochs_p1} epochs, Phase 2: {args.max_epochs_p2} epochs")
    print(f"📦 Total batch size: {args.batch_size} (={args.batch_size//args.world_size} per GPU)")
    
    # Launch distributed training
    mp.spawn(run_decoupled_distributed_training,
             args=(args.world_size, args, cfg),
             nprocs=args.world_size,
             join=True)

if __name__ == '__main__':
    main()
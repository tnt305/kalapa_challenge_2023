import os
import logging
from datetime import datetime
import time
import numpy as np
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import yaml
import torch
import torch.optim.lr_scheduler
from torch.optim.lr_scheduler import ReduceLROnPlateau

from dataset import SoccerNetClips, SoccerNetClipsTesting, create_class_balanced_sampler
from model import ASTRA
from train import trainerAS, testSpotting, LearningRateWarmUP
from loss import NLLLoss, FocalLoss, ASTRALoss


def main(args, cfg):

    logging.info("Parameters:")
    for arg in vars(args):
        logging.info(arg.rjust(15) + " : " + str(getattr(args, arg)))

    for arg in cfg:
        if type(cfg[arg]) is dict:
            logging.info(' '*2 + str(arg) + ':')
            for arg2 in cfg[arg]:
                logging.info(' '*4 + str(arg2) + ' : ' + str(cfg[arg][arg2]))
        else:
            logging.info(' '*2 + str(arg) + ' : ' + str(cfg[arg]))

    torch.manual_seed(cfg['seed'])
    np.random.seed(cfg['seed'])
    
    if args.decoupled_training:
        run_decoupled_training(args, cfg)
    else:
        run_single_training(args, cfg)


def run_single_training(args, cfg):
    logging.info("Standard training base")
    # create dataset
    if not args.test_only:
        dataset_Train = SoccerNetClips(path=args.SoccerNet_path, 
                                    frames_features=args.features, 
                                    audio_features=args.audio_features,
                                    multimodal=args.multimodal,
                                    split=args.split_train,
                                    stride = 25,
                                    version=args.version, 
                                    framerate=args.framerate, 
                                    window_size=args.window_size,
                                    store = True)
        dataset_Valid = SoccerNetClips(path=args.SoccerNet_path, 
                                     frames_features=args.features, 
                                     audio_features=args.audio_features,
                                     multimodal=args.multimodal,
                                     split=args.split_valid, 
                                     stride = 25,
                                     version=args.version, 
                                     framerate=args.framerate, 
                                     window_size=args.window_size,
                                     store = True)
        
        # create model with memory-optimized settings
        model = ASTRA(chunk_size = args.window_size, 
                    n_output = int(args.framerate * args.window_size), 
                    baidu = True, audio = args.multimodal,
                    model_cfg = cfg['model']).cuda()
        logging.info(model)
        total_params = sum(p.numel()
                        for p in model.parameters() if p.requires_grad)
        logging.info("Total number of parameters: " + str(total_params))
        criterion = ASTRALoss(wC = 100, wD = 1, focal = True, nw = 5, uncertainty = True, uncertainty_mode = 'loglikelihood')
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.LR, weight_decay=1e-4, amsgrad=True)
        scheduler_cosine = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, cfg['max_epochs'] - cfg['warmup_iter'])
        scheduler = LearningRateWarmUP(optimizer = optimizer,
                                    warmup_iteration = 3,
                                    target_lr = args.LR,
                                    after_scheduler = scheduler_cosine)
        # start training
        train_loader = torch.utils.data.DataLoader(dataset_Train,
            batch_size=args.batch_size, shuffle=True,
            num_workers=args.max_num_worker, pin_memory=True, drop_last = True)

        val_loader = torch.utils.data.DataLoader(dataset_Valid,
            batch_size=args.batch_size, shuffle=False,
            num_workers=args.max_num_worker, pin_memory=True, drop_last = True)
        trainerAS(train_loader, val_loader, model, 
                optimizer, scheduler, criterion, patience = args.patience, 
                model_name = args.model_name,
                max_epochs = args.max_epochs, chunk_size = args.window_size, outputrate = args.framerate, 
                path_experiments = cfg['path_experiments'],
                )
        
        # checkpoint = torch.load(os.path.join("models", args.model_name, "model.pth.tar"))
        # model.load_state_dict(checkpoint['state_dict'], strict=False)
    # dataset_Test  = SoccerNetClipsTesting(path=args.SoccerNet_path, 
    #                                       frames_features=args.features, 
    #                                       audio_features=args.audio_features,
    #                                       multimodal=args.multimodal,
    #                                       split=args.split_test, 
    #                                       version=args.version, 
    #                                       framerate=args.framerate, 
    #                                    window_size=args.window_size)
    if args.feature_dim is None and not args.test_only:
        args.feature_dim =dataset_Test[0][1]['video_half1'].shape[-1]
        logging.info("FeAture_dim found: " + str(args.feature_dim))

    if args.load_weights:
        logging.info(f"Tải trọng số đã huấn luyện")
        checkpoint = torch.load(os.path.join("models", args.model_name, "model.pth.tar"))
        model.load_state_dict(checkpoint['state_dict'], strict=False)

    # test on multiple splits [test/challenge]
    for split in args.split_test:
        dataset_Test  = SoccerNetClipsTesting(path=args.SoccerNet_path, 
                                              frames_features=args.features, 
                                              audio_features=args.audio_features,
                                              multimodal=args.multimodal,
                                              split=[split], 
                                              version=args.version, 
                                              framerate=args.framerate, 
                                              window_size=args.window_size)

        test_loader = torch.utils.data.DataLoader(dataset_Test,
            batch_size=1, shuffle=False,
            num_workers=1, pin_memory=False)

        results_l, results_t = testSpotting(test_loader, model = model, model_name = args.model_name, NMS_threshold = args.NMS_threshold, 
                            outputrate = args.framerate, chunk_size = args.window_size, path_experiments = cfg['path_experiments'])
        a_mAP = results_l["a_mAP"]
        a_mAP_per_class = results_l["a_mAP_per_class"]
        a_mAP_visible = results_l["a_mAP_visible"]
        a_mAP_per_class_visible = results_l["a_mAP_per_class_visible"]
        a_mAP_unshown = results_l["a_mAP_unshown"]
        a_mAP_per_class_unshown = results_l["a_mAP_per_class_unshown"]

        logging.info("Best Performance at end of training (loose metric)")
        logging.info("a_mAP visibility all: " +  str(a_mAP))
        logging.info("a_mAP visibility all per class: " +  str( a_mAP_per_class))
        logging.info("a_mAP visibility visible: " +  str( a_mAP_visible))
        logging.info("a_mAP visibility visible per class: " +  str( a_mAP_per_class_visible))
        logging.info("a_mAP visibility unshown: " +  str( a_mAP_unshown))
        logging.info("a_mAP visibility unshown per class: " +  str( a_mAP_per_class_unshown))

        a_mAP = results_t["a_mAP"]
        a_mAP_per_class = results_t["a_mAP_per_class"]
        a_mAP_visible = results_t["a_mAP_visible"]
        a_mAP_per_class_visible = results_t["a_mAP_per_class_visible"]
        a_mAP_unshown = results_t["a_mAP_unshown"]
        a_mAP_per_class_unshown = results_t["a_mAP_per_class_unshown"]


        logging.info("Best Performance at end of training (tight metric)")
        logging.info("a_mAP visibility all: " +  str(a_mAP))
        logging.info("a_mAP visibility all per class: " +  str( a_mAP_per_class))
        logging.info("a_mAP visibility visible: " +  str( a_mAP_visible))
        logging.info("a_mAP visibility visible per class: " +  str( a_mAP_per_class_visible))
        logging.info("a_mAP visibility unshown: " +  str( a_mAP_unshown))
        logging.info("a_mAP visibility unshown per class: " +  str( a_mAP_per_class_unshown))

    return 

def run_decoupled_training(args, cfg):
    logging.info("\n===== BẮT ĐẦU HUẤN LUYỆN DECOUPLED TRAINING =====")
    
    # --- THIẾT LẬP CHUNG ---
    model = ASTRA(chunk_size = args.window_size, 
                  n_output = int(args.framerate * args.window_size), 
                  baidu = True, audio = args.multimodal,
                  model_cfg = cfg['model']).cuda()

    criterion = ASTRALoss(wC = 100, wD = 1, focal = True, nw = 5, uncertainty = True, uncertainty_mode = 'loglikelihood')
    
    # Kiểm tra nếu chỉ test thì bỏ qua phần training
    if not args.test_only:
        # ===== GIAI ĐOẠN 1: HUẤN LUYỆN ĐẶC TRƯNG =====
        logging.info("\n----- GIAI ĐOẠN 1: HUẤN LUYỆN TOÀN BỘ MÔ HÌNH -----")
        
        phase1_model_name = args.model_name + "_phase1"
        best_model_phase1_path = os.path.join(cfg['path_experiments'], phase1_model_name, 'model.pth.tar')

        if not args.skip_phase1:
            # Tạo dataset và dataloader như bình thường
            dataset_Train_p1 = SoccerNetClips(path=args.SoccerNet_path, 
                                        frames_features=args.features, 
                                        audio_features=args.audio_features,
                                        multimodal=args.multimodal,
                                        split=args.split_train,
                                        stride = 25,
                                        version=args.version, 
                                        framerate=args.framerate, 
                                        window_size=args.window_size,
                                        store = False)
            train_loader_p1 = torch.utils.data.DataLoader(dataset_Train_p1, batch_size=args.batch_size, shuffle=True,
                                                       num_workers=args.max_num_worker, pin_memory=True)
            
            dataset_Valid_p1 = SoccerNetClips(path=args.SoccerNet_path, 
                                        frames_features=args.features, 
                                        audio_features=args.audio_features,
                                        multimodal=args.multimodal,
                                        split=args.split_valid,
                                        stride = 25,
                                        version=args.version, 
                                        framerate=args.framerate, 
                                        window_size=args.window_size,
                                        store = False)
            val_loader_p1 = torch.utils.data.DataLoader(dataset_Valid_p1, batch_size=args.batch_size, shuffle=False,
                                                     num_workers=args.max_num_worker, pin_memory=True)

            optimizer_p1 = torch.optim.AdamW(model.parameters(), lr=args.LR, weight_decay=1e-5, amsgrad=True)
            scheduler_cosine_p1 = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer_p1, args.max_epochs_p1 - cfg['warmup_iter'])
            scheduler_p1 = LearningRateWarmUP(optimizer=optimizer_p1, warmup_iteration=3,
                                              target_lr=args.LR, after_scheduler=scheduler_cosine_p1)

            trainerAS(train_loader_p1, val_loader_p1, model, optimizer_p1, scheduler_p1, criterion,
                      patience=args.patience, model_name=phase1_model_name,
                      max_epochs=args.max_epochs_p1, chunk_size=args.window_size,
                      outputrate=args.framerate, path_experiments=cfg['path_experiments'])
        else:
            logging.info("Bỏ qua Giai đoạn 1.")
        
        # ===== GIAI ĐOẠN 2: HUẤN LUYỆN LẠI BỘ PHÂN LOẠI =====
        logging.info("\n----- GIAI ĐOẠN 2: HUẤN LUYỆN LẠI PREDICTION HEADS -----")
        
        # Tải lại model tốt nhất từ Giai đoạn 1
        if os.path.exists(best_model_phase1_path):
            logging.info(f"Tải trọng số tốt nhất từ Giai đoạn 1: {best_model_phase1_path}")
            checkpoint = torch.load(best_model_phase1_path, weights_only=False)
            model.load_state_dict(checkpoint['state_dict'], strict=False)
        else:
            logging.error(f"Không tìm thấy checkpoint của Giai đoạn 1 tại '{best_model_phase1_path}'! Dừng lại.")
            return

        # Đóng băng toàn bộ backbone
        logging.info("Đóng băng backbone...")
        for name, param in model.named_parameters():
            if 'clas_head' not in name and 'displ_head' not in name:
                param.requires_grad = False
        
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        logging.info(f"Số lượng tham số có thể huấn luyện trong Giai đoạn 2: {trainable_params}")

        # Tạo DataLoader cân bằng lớp
        logging.info("Tạo DataLoader cân bằng lớp...")
        dataset_Train_p2 = SoccerNetClips(path=args.SoccerNet_path, 
                                        frames_features=args.features, 
                                        audio_features=args.audio_features,
                                        multimodal=args.multimodal,
                                        split=args.split_train,
                                        stride = 25,
                                        version=args.version, 
                                        framerate=args.framerate, 
                                        window_size=args.window_size,
                                        store = False)
        if not hasattr(dataset_Train_p2, 'clip_class_info'):
            logging.error("Lớp Dataset không có thuộc tính 'clip_class_info'. Bạn đã sửa file dataset.py và xóa cache cũ chưa?")
            return
            
        balanced_sampler = create_class_balanced_sampler(dataset_Train_p2.clip_class_info, dataset_Train_p2.num_classes)
        train_loader_balanced = torch.utils.data.DataLoader(dataset_Train_p2, batch_size=args.batch_size, 
                                                            sampler=balanced_sampler,
                                                            num_workers=args.max_num_worker, pin_memory=True)

        dataset_Valid_p2 = SoccerNetClips(path=args.SoccerNet_path, 
                                        frames_features=args.features, 
                                        audio_features=args.audio_features,
                                        multimodal=args.multimodal,
                                        split=args.split_valid,
                                        stride = 25,
                                        version=args.version, 
                                        framerate=args.framerate, 
                                        window_size=args.window_size,
                                        store = False)
        val_loader_p2 = torch.utils.data.DataLoader(dataset_Valid_p2, batch_size=args.batch_size, shuffle=False,
                                                  num_workers=args.max_num_worker, pin_memory=True)

        # Tạo optimizer mới với learning rate rất nhỏ
        optimizer_p2 = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), 
                                        lr=args.LR_p2, weight_decay=1e-4)
        scheduler_p2 = torch.optim.lr_scheduler.StepLR(optimizer_p2, step_size=5, gamma=0.5)

        final_model_name = args.model_name + "_decoupled"
        trainerAS(train_loader_balanced, val_loader_p2, model, optimizer_p2, scheduler_p2, criterion,
                  patience=args.patience, model_name=final_model_name,
                  max_epochs=args.max_epochs_p2, chunk_size=args.window_size,
                  outputrate=args.framerate, path_experiments=cfg['path_experiments'])
    else:
        logging.info("Chế độ TEST ONLY - Bỏ qua toàn bộ quá trình training")

    # Tải trọng số nếu được chỉ định
    if args.load_weights:
        logging.info(f"Tải trọng số đã huấn luyện từ: {args.load_weights}")
        checkpoint = torch.load(args.load_weights, weights_only=False)
        model.load_state_dict(checkpoint['state_dict'], strict=False)
    elif args.test_only:
        # Nếu không phải test_only và không có load_weights, tải model từ decoupled training
        final_model_name = args.model_name + "_decoupled"
        best_model_final_path = os.path.join(cfg['path_experiments'], final_model_name, 'model.pth.tar')
        
        # Fallback to phase1 model if final model doesn't exist
        if not os.path.exists(best_model_final_path):
            phase1_model_name = args.model_name + "_phase1"
            best_model_phase1_path = os.path.join(cfg['path_experiments'], phase1_model_name, 'model.pth.tar')
            logging.warning(f"Không tìm thấy model cuối cùng tại {best_model_final_path}. Sử dụng model từ Giai đoạn 1 để test.")
            best_model_final_path = best_model_phase1_path

        if os.path.exists(best_model_final_path):
            checkpoint = torch.load(best_model_final_path, weights_only=False)
            model.load_state_dict(checkpoint['state_dict'], strict=False)
        else:
            logging.error(f"Không tìm thấy model để test tại {best_model_final_path}")
            return

    # --- ĐÁNH GIÁ MÔ HÌNH CUỐI CÙNG ---
    logging.info("\n----- ĐÁNH GIÁ MÔ HÌNH CUỐI CÙNG TRÊN TẬP TEST -----")
    
    for split in args.split_test:
        test_loader = torch.utils.data.DataLoader(
            SoccerNetClipsTesting(path=args.SoccerNet_path, 
                                  frames_features=args.features, 
                                  audio_features=args.audio_features,
                                  multimodal=args.multimodal,
                                  split=[split], 
                                  version=args.version, 
                                  framerate=args.framerate, 
                                  window_size=args.window_size),
            batch_size=1, shuffle=False, num_workers=1, pin_memory=False
        )
        # Sử dụng model đã được huấn luyện đầy đủ
        results_l, results_t = testSpotting(test_loader, model = model, model_name = args.model_name, NMS_threshold = args.NMS_threshold, 
                            outputrate = args.framerate, chunk_size = args.window_size, path_experiments = cfg['path_experiments'], postprocessing = 'SNMS')
        a_mAP = results_l["a_mAP"]
        a_mAP_per_class = results_l["a_mAP_per_class"]
        a_mAP_visible = results_l["a_mAP_visible"]
        a_mAP_per_class_visible = results_l["a_mAP_per_class_visible"]
        a_mAP_unshown = results_l["a_mAP_unshown"]
        a_mAP_per_class_unshown = results_l["a_mAP_per_class_unshown"]

        logging.info("Best Performance at end of training (loose metric)")
        logging.info("a_mAP visibility all: " +  str(a_mAP))
        logging.info("a_mAP visibility all per class: " +  str( a_mAP_per_class))
        logging.info("a_mAP visibility visible: " +  str( a_mAP_visible))
        logging.info("a_mAP visibility visible per class: " +  str( a_mAP_per_class_visible))
        logging.info("a_mAP visibility unshown: " +  str( a_mAP_unshown))
        logging.info("a_mAP visibility unshown per class: " +  str( a_mAP_per_class_unshown))

        a_mAP = results_t["a_mAP"]
        a_mAP_per_class = results_t["a_mAP_per_class"]
        a_mAP_visible = results_t["a_mAP_visible"]
        a_mAP_per_class_visible = results_t["a_mAP_per_class_visible"]
        a_mAP_unshown = results_t["a_mAP_unshown"]
        a_mAP_per_class_unshown = results_t["a_mAP_per_class_unshown"]


        logging.info("Best Performance at end of training (tight metric)")
        logging.info("a_mAP visibility all: " +  str(a_mAP))
        logging.info("a_mAP visibility all per class: " +  str( a_mAP_per_class))
        logging.info("a_mAP visibility visible: " +  str( a_mAP_visible))
        logging.info("a_mAP visibility visible per class: " +  str( a_mAP_per_class_visible))
        logging.info("a_mAP visibility unshown: " +  str( a_mAP_unshown))
        logging.info("a_mAP visibility unshown per class: " +  str( a_mAP_per_class_unshown))


if __name__ == '__main__':


    parser = ArgumentParser(description='context aware loss function', formatter_class=ArgumentDefaultsHelpFormatter)
    
    parser.add_argument('--SoccerNet_path',   required=False, type=str,   default="/home/storage/thiendc/soccernet",     help='Path for SoccerNet' )
    parser.add_argument('--features',   required=False, type=str,   default="baidu_soccer_embeddings.npy",     help='Video features' )
    parser.add_argument('--audio_features',   required=False, type=str,   default="AST.npy",     help='Audio features for multimodal training' )
    parser.add_argument('--multimodal',   required=False, action='store_true',  help='Enable multimodal training with video and audio features' )
    parser.add_argument('--max_epochs',   required=False, type=int,   default= 50,     help='Maximum number of epochs' )
    parser.add_argument('--load_weights',   required=False, type=str,   default=None,     help='weights to load' )
    parser.add_argument('--model_name',   required=False, type=str,   default="ASTRA",     help='named of the model to save' )
    parser.add_argument('--path_experiments',   required=False, type=str,   default="models",     help='Path for experiments' )
    parser.add_argument('--test_only',   required=False, action='store_true',  help='Perform testing only' )

    # decoupled training
    parser.add_argument('--decoupled_training', action='store_true', help='Thực hiện decoupled training 2 giai đoạn.')
    parser.add_argument('--skip_phase1', action='store_true', help='Bỏ qua GĐ1 và tải trọng số đã huấn luyện (chỉ dùng khi đã chạy GĐ1 trước đó).')
    parser.add_argument('--max_epochs_p1', type=int, default= 40, help='Số epochs cho Giai đoạn 1.')
    parser.add_argument('--max_epochs_p2', type=int, default= 2, help='Số epochs cho Giai đoạn 2.')
    parser.add_argument('--LR_p2', type=float, default=1e-5, help='Learning rate cho Giai đoạn 2.')
    
    parser.add_argument('--split_train', nargs='+', default=["train"], help='list of split for training')
    parser.add_argument('--split_valid', nargs='+', default=["test"], help='list of split for validation')
    parser.add_argument('--split_test', nargs='+', default=["test"], help='list of split for testing')

    parser.add_argument('--version', required=False, type=int,   default=2,     help='Version of the dataset' )
    parser.add_argument('--feature_dim', required=False, type=int,   default=None,     help='Number of input features')
    parser.add_argument('--evaluation_frequency', required=False, type=int,   default= 20,     help='Number of chunks per epoch')
    parser.add_argument('--framerate', required=False, type=int,   default=2,     help='Framerate of the input features')
    parser.add_argument('--window_size', required=False, type=int,   default=50,     help='Size of the chunk (in seconds)')
    parser.add_argument('--pool',       required=False, type=str,   default="ASTRA", help='How to pool')
    parser.add_argument('--vocab_size',       required=False, type=int,   default=64, help='Size of the vocabulary for NetVLAD')
    parser.add_argument('--NMS_window',       required=False, type=int,   default=30, help='NMS window in second' )
    parser.add_argument('--NMS_threshold',       required=False, type=float,   default=0.01, help='NMS threshold for positive results')

    parser.add_argument('--batch_size', required=False, type=int,   default=8,     help='Batch size')
    parser.add_argument('--LR',       required=False, type=float,   default=1e-04, help='Learning Rate')
    parser.add_argument('--LRe',       required=False, type=float,   default=5e-07, help='Learning Rate end (eta_min for CosineAnnealingWarmRestarts)' )
    parser.add_argument('--patience', required=False, type=int,   default=16,     help='Patience before reducing LR (ReduceLROnPlateau)' )
    
    # CosineAnnealingWarmRestarts parameters
    parser.add_argument('--T_0', required=False, type=int, default= 10, 
                       help='Number of iterations for the first restart (CosineAnnealingWarmRestarts)')
    parser.add_argument('--T_mult', required=False, type=int, default= 2, 
                       help='Factor that increases T_i after a restart (CosineAnnealingWarmRestarts)')
    
    # Early Stopping parameters
    parser.add_argument('--early_stopping_min_delta', required=False, type=float, default=0.001,
                       help='Minimum change in validation performance to qualify as improvement')

    parser.add_argument('--GPU',        required=False, type=int,   default=1,     help='ID of the GPU to use' )
    parser.add_argument('--max_num_worker',   required=False, type=int,   default= 20, help='number of worker to load data')
    parser.add_argument('--seed',   required=False, type=int,   default= 1, help='seed for reproducibility')

    # parser.add_argument('--logging_dir',       required=False, type=str,   default="log", help='Where to log' )
    parser.add_argument('--loglevel',   required=False, type=str,   default='INFO', help='logging level')

    # Add mixup argument
    parser.add_argument('--mixup_alpha', required=False, type=float, default=0.2, 
                       help='Mixup alpha parameter (0 = no mixup)')

    args = parser.parse_args()

    args.config_file = os.path.join('configs', args.model_name + '.yaml')
    with open (args.config_file, 'r') as f:
        cfg = yaml.load(f, Loader = yaml.FullLoader)
    cfg['model_name'] = args.model_name
    # for reproducibility
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    numeric_level = getattr(logging, args.loglevel.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError('Invalid log level: %s' % args.loglevel)

    os.makedirs(os.path.join("models", args.model_name), exist_ok=True)
    log_path = os.path.join("models", args.model_name,
                            datetime.now().strftime('%Y-%m-%d_%H-%M-%S.log'))
    logging.basicConfig(
        level=numeric_level,
        format=
        "%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s",
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler()
        ])

    if args.GPU >= 0:
        os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        os.environ["CUDA_VISIBLE_DEVICES"] = str(args.GPU)


    start=time.time()
    logging.info('Starting main function')
    main(args, cfg)
    logging.info(f'Total Execution Time is {time.time()-start} seconds')
from .gating import ConvGatedFusion

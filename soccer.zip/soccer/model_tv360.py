import math
import numpy as np
import torch
import torch.nn as nn
from einops import rearrange

from impl.head_cls import pred_head, uncertainty_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead, FastGELU
from impl.modules import ConvGatedFusion

class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

class TV360(nn.Module):
    """
    TV360GatedUnit model class
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24,
        baidu = True,
        audio = False,
        model_cfg = None,
    ):

        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        
        #Register from dinov2
        self.num_registers = model_cfg.get('num_registers', 0)  # Lấy từ config, ví dụ 4
        if self.num_registers > 0:
            # Khởi tạo ngẫu nhiên, mô hình sẽ học chúng
            self.register_tokens = nn.Parameter(torch.randn(1, self.num_registers, model_cfg['dim']))
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        if self.use_text_gated_fusion:
            print("Using text gated fusion")
            embedding_path = model_cfg.get('text_embedding_path', "/home/thiendc/projects/video_summarization/train_soccernet/class_emb.npy")
            try:
                # Tải embedding và đăng ký như một buffer (không học)
                text_embeddings = torch.from_numpy(np.load(embedding_path)).float()
                self.register_buffer('text_label_embeddings', text_embeddings)
            except FileNotFoundError:
                raise FileNotFoundError(f"Cannot find text embedding file: {embedding_path}")
                
            text_dim = text_embeddings.shape[-1]
            model_dim = model_cfg['dim']

            # 2. Lớp chiếu (Projection Layer)
            # Chiếu text embedding về chiều của mô 
            if text_dim == model_dim:
                self.text_proj = nn.Identity()
            else:
                self.text_proj = nn.Linear(text_dim, model_dim)

            # 3. Gating Mechanism
            # Đầu vào của gate là sự kết hợp của decoder_output và text_embedding
            # Nó sẽ học cách tạo ra một trọng số (gate value) cho mỗi query và mỗi class
            self.fusion_gate = nn.Sequential(
                nn.Linear(model_dim * 2, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, 1), # Ra một giá trị scalar cho mỗi cặp
                nn.Sigmoid() # Đưa giá trị về khoảng [0, 1]
            )
        if self.baidu and self.audio:
            self.video_residual_weight = nn.Parameter(torch.tensor(0.1))
            self.audio_residual_weight = nn.Parameter(torch.tensor(0.1))
        else:
            self.video_residual_weight = None
            self.audio_residual_weight = None
            
        self.use_adaptive_modulation = model_cfg.get('use_adaptive_modulation', False)
        if self.use_adaptive_modulation:
            print("Using Adaptive Modulation for Knowledge Fusion")
            try:
                # 1. Tải và ghép các embedding đối tượng ĐÃ ĐƯỢC AVERAGE POOLING
                red_card_embed = torch.from_numpy(np.load(model_cfg['red_card_embedding_path'])).float()
                yellow_card_embed = torch.from_numpy(np.load(model_cfg['yellow_card_embedding_path'])).float()
                goal_embed = torch.from_numpy(np.load(model_cfg['goal_embedding_path'])).float()
                # referee_embed = torch.from_numpy(np.load(model_cfg['referee_embedding_path'])).float()
                # Ghép chúng lại thành một tensor duy nhất
                # Shape: [num_knowledge_classes, feature_dim]
                static_knowledge_prototypes = torch.stack([red_card_embed, yellow_card_embed, goal_embed], dim=0)

                # 2. Đăng ký như một buffer để đóng băng
                self.register_buffer('static_knowledge_prototypes', static_knowledge_prototypes)
                
            except FileNotFoundError as e:
                raise FileNotFoundError(f"Cannot find prototype embedding file: {e}")
            
            object_dim = self.static_knowledge_prototypes.shape[-1] # 768
            model_dim = model_cfg['dim'] # 512

            # 3. Lớp chiếu (Projection Layer)
            self.knowledge_proj = nn.Linear(object_dim, model_dim)

            # 4. "Bộ điều biến" (Modulator) có thể học được
            # Nó sẽ nhận ngữ cảnh video và tạo ra một vector điều biến.
            # Đây là trái tim của cơ chế adaptive mới.
            self.knowledge_modulator = nn.Sequential(
                nn.Linear(model_dim, model_dim), # Đầu vào là decoder_output
                nn.GELU(),
                nn.Linear(model_dim, model_dim * 2) # Đầu ra có kích thước gấp đôi
            )
        
        # Initialize shared post-fusion normalization layer only if needed
        if self.use_text_gated_fusion or self.use_adaptive_modulation:
            print("Initializing a shared post-fusion normalization layer.")
            self.post_fusion_norm = nn.LayerNorm(model_cfg['dim'])
        
        #Baidu backbone
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            self.encTB = nn.Parameter(torch.rand(self.chunk_size, model_cfg['dim']))
            
            # self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))

        #Audio backbone
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 4096)
            self.vggish_embeddings[4] = nn.Linear(4096, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish

        self.fusion_unit = ConvGatedFusion(model_dim=model_cfg['dim'])
        
        #Features augmentation (for both audio + baidu)
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #ASTRA model

        #Transformer encoder - with memory optimization
        encoder_layer = nn.TransformerEncoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tencoder = nn.TransformerEncoder(encoder_layer, model_cfg['TE_layers'])
    

        #Transformer decoder - with memory optimization
        # ✅ SỬA LỖI: Kiểm tra xem text_label_embeddings có tồn tại không
        if self.use_text_gated_fusion and hasattr(self, 'text_label_embeddings') and self.n_output == self.text_label_embeddings.shape[0]:
            print("Using text label embeddings")
            text_embed_dim = self.text_label_embeddings.shape[1]
            if text_embed_dim != model_cfg['dim']:
                text_projection = nn.Linear(text_embed_dim, model_cfg['dim'])
                # Áp dụng projection và tạo queries
                with torch.no_grad():
                    projected_embeddings = text_projection(self.text_label_embeddings)
                self.queries = nn.Parameter(projected_embeddings.clone())
            else:
                self.queries = nn.Parameter(self.text_label_embeddings.clone())
        else:
            self.queries = nn.Parameter(torch.rand((self.n_output, model_cfg['dim'])))
        decoder_layer = nn.TransformerDecoderLayer(d_model = model_cfg['dim'], nhead = 8, dim_feedforward = model_cfg['dim'] * 4, batch_first = True)
        self.Tdecoder = nn.TransformerDecoder(decoder_layer, model_cfg['TD_layers'])

        # 2. Lớp MultiheadAttention để thực hiện pooling.
        # Nó sẽ tính toán sự tương đồng giữa query và các text info,
        # sau đó tổng hợp chúng lại theo trọng số attention.
        self.text_aggregation_query = nn.Parameter(torch.randn(1, 1, model_cfg['dim']))
        self.text_aggregator = nn.MultiheadAttention(
            embed_dim=model_cfg['dim'], 
            num_heads=8, # Bạn có thể dùng 4 hoặc 8 heads
            batch_first=True,
            dropout=model_cfg['dropout'] # Dùng dropout từ config
        )
        
        #Prediction heads
        self.clas_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = True, drop = model_cfg['dropout'])

        if model_cfg['uncertainty']:
            self.displ_head = uncertainty_head(model_cfg['dim'], model_cfg['num_classes'] + 1, drop = model_cfg['dropout'])
        else:
            self.displ_head = pred_head(model_cfg['dim'], model_cfg['num_classes'] + 1, sigmoid = False, drop = model_cfg['dropout'])


        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            # Tính tổng feature dimension từ self.Bfeat_dim thay vì hard-code
            total_feat_dim = sum(self.Bfeat_dim) if self.baidu else 0
            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, total_feat_dim))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def load_weights(self, weights=None):
        if(weights is not None):
            print("=> loading checkpoint '{}'".format(weights))
            checkpoint = torch.load(weights)
            self.load_state_dict(checkpoint['state_dict'])
            print("=> loaded checkpoint '{}' (epoch {})"
                .format(weights, checkpoint['epoch']))

    def forward(self, featsB = None, featsA = None, labels = None, labelsD = None, inference = False):
        
        # ✅ CLONE tất cả inputs ngay từ đầu
        if featsB is not None:
            featsB = featsB.clone().float()
            b = len(featsB)
        if featsA is not None:
            featsA = featsA.clone().float()
        if labels is not None:
            labels = labels.clone().float()
        if labelsD is not None:
            labelsD = labelsD.clone().float()
            
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()

        #Mixup (not inference) - ✅ SỬA LỖI: Dùng 'and' thay vì '&'
        if self.model_cfg['mixup'] and (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if self.audio:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    # ✅ SỬA LỖI: Dùng device của tensor thay vì hard-code
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device=y.device)
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if self.audio:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if self.audio:
                del xA
            
            if torch.cuda.is_available(): torch.cuda.empty_cache()

        # --- 2. Feature Augmentation (chỉ khi huấn luyện) ---
        if self.model_cfg.get('feature_augmentation', False) and not inference:
            if self.baidu and featsB is not None:
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            if use_audio_in_batch and featsA is not None:
                # Augmentation hoạt động trên featsA thô (128-D)
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
        
        #Baidu features
        if self.baidu:
            featsB = [ll(featsB[:, :, int(sum(self.Bfeat_dim[:i])):int(sum(self.Bfeat_dim[:i+1]))]) for i, ll in enumerate(self.baidu_LL)]
            featsB = torch.stack(featsB, dim=0)
            l, b, cs, d = featsB.shape

            # Áp dụng Positional Encoding cho video
            # featsB_pe = self.video_pos_encoder(rearrange(featsB_stacked, 'l b cs d -> (l b) cs d'))
            # featsB_pe = rearrange(featsB_pe, '(l b) cs d -> l b cs d', l=l)
            
            # Thêm embedding cho các nguồn đặc trưng (modality embedding)
            # featsB = rearrange(featsB_pe, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            # featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')
            featsB += self.encTB.expand(l, b, -1, -1)
            featsB = rearrange(featsB, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
            featsB = rearrange(featsB, 'b cs l d -> b (cs l) d')

        #Audio features
        if use_audio_in_batch:
            fA = featsA.shape[1] // 96
            audio_reshaped = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f=fA)
            audio_out_feat = self.vggish_features(audio_reshaped).flatten(1)
            featsA = self.vggish_embeddings(audio_out_feat)
            featsA = rearrange(featsA, '(b f) d -> b f d', f=fA)
            
            # Thêm Positional Encoding cho audio
            featsA = featsA + self.encTA[:featsA.shape[1]].unsqueeze(0) + self.encA.unsqueeze(0)

        # --- 4. Fusion đa phương thức (Video + Audio) ---
        if self.baidu and use_audio_in_batch:
            x = self.fusion_unit(featsB, featsA)
            x = x  + self.video_residual_weight * featsB #+ self.audio_residual_weight * featsA
        elif self.baidu:
            x = featsB
        elif use_audio_in_batch:
            x = featsA
        else:
            raise ValueError("At least one modality (baidu or audio) must be provided.")


        # --- 5. Transformer Encoder với kiến trúc Hierarchy đã sửa lỗi ---
        if self.num_registers > 0:
            current_regs = self.register_tokens.expand(b, -1, -1)
        else:
            current_regs = None
        # if current_regs is None:
        #     print("current_regs is None")
        
        splits = [4, 2, 1, 1, 1] #hierarchical architecture of TE (split in 4 segments at first layer, 2 at second layer...)
        
        # for i, mod in enumerate(self.Tencoder.layers):
        #     # Ghép registers vào đầu vào của lớp encoder
        #     if current_regs is not None:
        #         x = torch.cat((current_regs, x), dim=1)
                
        #     if i >= len(splits) or splits[i] == 1: # Global attention
        #         x = mod(x)
        #     else: # Hierarchical attention
        #         # Tách registers và data ra
        #         if current_regs is not None:
        #             regs = x[:, :self.num_registers]
        #             data = x[:, self.num_registers:]
        #         else:
        #             regs = None
        #             data = x
                
        #         # Chia data thành các đoạn
        #         num_tokens = data.shape[1]
        #         num_segments = splits[i]
                
        #         # Sử dụng split để chia đều, đoạn cuối có thể ngắn hơn
        #         # Điều này an toàn hơn là tính toán index thủ công
        #         segments = torch.chunk(data, num_segments, dim=1)
                
        #         processed_segments = []
        #         updated_regs_list = []

        #         for seg in segments:
        #             if seg.shape[1] == 0: continue
                    
        #             # Ghép registers (nếu có) với mỗi đoạn để xử lý
        #             seg_in = torch.cat((regs, seg), dim=1) if regs is not None else seg
        #             processed_seg_full = mod(seg_in)
                    
        #             # Tách ra lại
        #             if regs is not None:
        #                 updated_regs_list.append(processed_seg_full[:, :self.num_registers])
        #                 processed_segments.append(processed_seg_full[:, self.num_registers:])
        #             else:
        #                 processed_segments.append(processed_seg_full)
                
        #         # Ghép các đoạn đã xử lý lại
        #         x = torch.cat(processed_segments, dim=1)
        
        #     # Tách registers đã được cập nhật ra khỏi `x` để chuẩn bị cho vòng lặp tiếp theo
        #     if current_regs is not None:
        #         current_regs = x[:, :self.num_registers]
        #         x = x[:, self.num_registers:]
        nB = featsB.shape[1]
        nA = 0
        if use_audio_in_batch:
            nA = featsA.shape[1]
        for i, mod in enumerate(self.Tencoder.layers):
    
            #global attention layers (i.e. split == 1 - 1 segment)
            if splits[i] == 1:
                x = featsB
                if use_audio_in_batch:
                    x = torch.cat((x, featsA), dim = 1)
                x = mod(x)

                featsB = x[:, :(nB)]
                if use_audio_in_batch:
                    featsA = x[:, (nB):]

            #hierarchical attention layers (i.e. split > 1 - split in segments)
            else: 
                x = rearrange(featsB[:, :(splits[i]-1) * (nB // splits[i])], 'b (ns ls) d -> (b ns) ls d', ns = splits[i] - 1) #split in segments 
                x_aux = featsB[:, (splits[i]-1) * (nB // splits[i]):] #residual segment

                if use_audio_in_batch:
                    xA = rearrange(featsA[:, :(splits[i]-1) * (nA // splits[i])], 'b (ns ls) d -> (b ns) ls d', ns = splits[i] - 1) #split in segments
                    xA_aux = featsA[:, (splits[i]-1) * (nA // splits[i]):] #residual segment

                    x = torch.cat((x, xA), dim = 1) #merge visual and audio features
                    x_aux = torch.cat((x_aux, xA_aux), dim = 1) #merge residual segments

                #Apply TE layer to segments
                x = mod(x)
                x_aux = mod(x_aux)

                #Restore in original shape and features distinction
                xB = torch.cat((rearrange(x[:, :(nB // splits[i])], '(b ns) ls d -> b (ns ls) d', ns = splits[i] - 1), x_aux[:, :(nB - (nB // splits[i] * (splits[i] - 1)))]), dim = 1)
                featsB = xB

                if use_audio_in_batch:
                    xA = torch.cat((rearrange(x[:, (nB // splits[i]):(nB // splits[i]) + (nA // splits[i])], '(b ns) ls d -> b (ns ls) d', ns = splits[i] - 1), x_aux[:, (nB - (nB // splits[i] * (splits[i] - 1))):(nB - (nB // splits[i] * (splits[i] - 1))) + (nA - (nA // splits[i] * (splits[i] - 1)))]), dim = 1)
                    featsA = xA
        
        # --- BƯỚC 5: TRANSFORMER DECODER VÀ HEADS ---
        memory  = x
        queries = self.queries.expand((b, -1, -1))
        # Ghép lại registers vào memory cho Decoder
        if current_regs is not None:
            memory = torch.cat((current_regs, memory), dim=1)
            
        decoder_output = self.Tdecoder(queries, memory)
        
        contextual_text_adjustment = torch.zeros_like(decoder_output)
        
        if self.use_text_gated_fusion:
            projected_text_embeds = self.text_proj(self.text_label_embeddings) # Shape: [num_classes+1, d]
            decoder_out_expanded = decoder_output.unsqueeze(2) # Shape: [b, n_output, 1, d]
            text_embeds_expanded = projected_text_embeds.unsqueeze(0).unsqueeze(0) # Shape: [1, 1, num_classes+1, d]

            # Lặp lại (tile) để tạo ra mọi cặp (query, text_embedding)
            # decoder_tiled: [b, n_output, num_classes+1, d]
            # text_tiled:    [b, n_output, num_classes+1, d]
            decoder_tiled = decoder_out_expanded.expand(-1, -1, projected_text_embeds.shape[0], -1)
            text_tiled = text_embeds_expanded.expand(b, self.n_output, -1, -1)
            
            # 3. Tính toán Gate values
            # Ghép các cặp lại với nhau
            fusion_input = torch.cat((decoder_tiled, text_tiled), dim=-1) # Shape: [b, n_output, num_classes+1, d*2]
            
            # Cho qua cổng để có trọng số
            gate_values = self.fusion_gate(fusion_input) # Shape: [b, n_output, num_classes+1, 1]

            # 4. Áp dụng Gating
            # Điều chỉnh thông tin text dựa trên gate
            gated_text_info = text_tiled * gate_values # Shape: [b, n_output, num_classes+1, d]

            # Lấy trung bình thông tin text đã được "gated" trên tất cả các lớp
            # để tạo ra một vector điều chỉnh duy nhất cho mỗi query
            ### REPLACE BEFORE
            b, n_out, n_cls, d = gated_text_info.shape
            gated_text_info_flat = gated_text_info.view(b * n_out, n_cls, d)
            aggregation_query_flat = self.text_aggregation_query.expand(b * n_out, -1, -1)
            
            # Áp dụng attention để tổng hợp thông tin
            # Query "hỏi", Key và Value là các gated text info
            contextual_adjustment_flat, _ = self.text_aggregator(
                query=aggregation_query_flat, 
                key=gated_text_info_flat, 
                value=gated_text_info_flat
            ) # Đầu ra có shape: [B * n_output, 1, D]
            
            # Reshape kết quả về lại đúng shape mong muốn
            # Bỏ chiều 1 không cần thiết và reshape lại
            # Shape: [B * n_output, D] -> [B, n_output, D]
            contextual_text_adjustment = contextual_adjustment_flat.squeeze(1).view(b, n_out, d)
        
        contextual_object_adjustment = torch.zeros_like(decoder_output)
        
        if self.use_adaptive_modulation:
            num_knowledge_classes = self.static_knowledge_prototypes.shape[0]

            # Chiếu kiến thức tĩnh
            projected_knowledge = self.knowledge_proj(self.static_knowledge_prototypes)
            
            # Tạo các tham số điều biến
            decoder_subset = decoder_output[:, :num_knowledge_classes, :]
            modulation_params = self.knowledge_modulator(decoder_subset)
            scale, shift = modulation_params.chunk(2, dim=-1)

            # Áp dụng điều biến (FiLM)
            knowledge_to_modulate = projected_knowledge.unsqueeze(0).expand(b, -1, -1)
            modulated_knowledge = scale * knowledge_to_modulate + shift

            # Đặt kiến thức đã được điều biến vào đúng vị trí trong vector điều chỉnh
            contextual_object_adjustment[:, :num_knowledge_classes, :] = modulated_knowledge
        
        
            
        if self.use_text_gated_fusion and self.use_adaptive_modulation:
            fused_output = decoder_output + contextual_text_adjustment + contextual_object_adjustment
            fused_output = self.post_fusion_norm(fused_output)
            
            final_decoder_output = fused_output
        else:
            # Nếu không dùng fusion, giữ nguyên output gốc
            final_decoder_output = decoder_output

        y1 = self.clas_head(final_decoder_output)
        y2 = self.displ_head(final_decoder_output)

        output = {
            'preds': y1,
            'predsD': y2,
            'labels': labels,
            'labelsD': labelsD
        }
        return output


class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(inplace=False),  # ✅ SỬA: inplace=False
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU(inplace=False)   # ✅ SỬA: inplace=False
        )
    
    def forward(self, x: torch.Tensor):
        return self.head(x)

class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)
        # ✅ SỬA LỖI: Xóa self.n_queues không sử dụng
            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))
        # ✅ SỬA LỖI: Dùng mixup_nqueue từ featBQ thay vì hard-code
        nqueue = featBQ.shape[1]
        idxnq = torch.randint(0, nqueue, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        if not self.training or self.p == 0.0:
            return x
        x_aux = x.clone()  # ✅ Đã có clone
        mask = torch.rand(x_aux.shape[1], device=x.device) < self.p
        x_aux[:, mask] = self.embedding.to(x.device)  # ✅ Đảm bảo device match
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        if not self.training or self.p == 0.0:
            return x
        x_aux = x.clone()  # ✅ Đã có clone
        idxs = torch.arange(x_aux.shape[1]-1, device=x.device)[torch.rand(x_aux.shape[1]-1, device=x.device) < self.p]
        if len(idxs) > 0:
            # ✅ SỬA: Tránh inplace operation
            x_result = x_aux.clone()
            x_result[:, idxs, :] = x_aux[:, idxs+1, :].clone()
            x_result[:, idxs+1, :] = x_aux[:, idxs, :].clone()
            return x_result
        return x_aux
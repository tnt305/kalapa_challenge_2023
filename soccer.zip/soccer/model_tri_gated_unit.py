import math
import numpy as np
import torch
import torch.nn as nn
from einops import rearrange

from impl.head_cls import pred_head, uncertainty_head, FactorizedGroupWise, LighterMLPHead, GroupedConvHead, MoEHead, FastGELU
from impl.modules import ConvGatedFusion


class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for temporal sequences
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 2000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        
        pe = torch.zeros(1, max_len, d_model)
        pe[0, :, 0::2] = torch.sin(position * div_term)
        pe[0, :, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe, persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # x có shape (batch, seq_len, dim)
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)
    
class CNNEncoder(nn.Module):
    """
    Encoder đơn giản dựa trên CNN 1D để nắm bắt các đặc trưng cục bộ.
    """
    def __init__(self, input_dim, num_layers=3, kernel_size=5, dropout=0.2):
        super().__init__()
        layers = []
        for i in range(num_layers):
            # Giữ nguyên số chiều để dễ dàng tích hợp
            conv = nn.Conv1d(
                in_channels=input_dim,
                out_channels=input_dim,
                kernel_size=kernel_size,
                padding='same' # Giữ nguyên độ dài chuỗi
            )
            # Thêm LayerNorm thay vì BatchNorm vì nó hoạt động tốt hơn với Transformer
            norm = nn.LayerNorm(input_dim)
            layers.extend([
                conv,
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
        self.encoder = nn.Sequential(*layers)
        # Thêm một lớp norm cuối cùng
        self.final_norm = nn.LayerNorm(input_dim)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor, shape [batch_size, seq_len, embedding_dim]
        """
        # Conv1d yêu cầu shape (B, C, L), tức là (Batch, Dim, SeqLen)
        x = x.permute(0, 2, 1)
        x = self.encoder(x)
        # Chuyển về shape ban đầu (Batch, SeqLen, Dim)
        x = x.permute(0, 2, 1)
        return self.final_norm(x)

class TridentRegHead(nn.Module):
    """
    Trident Regression Head để dự đoán displacement ở nhiều tỷ lệ.
    Hỗ trợ tùy chọn dự đoán uncertainty.
    """
    def __init__(self, input_dim, num_classes, kernel_size=3, uncertainty=False, drop=0.2):
        super().__init__()
        # Ba nhánh với dilation khác nhau
        self.branch1 = nn.Conv1d(input_dim, input_dim, kernel_size=kernel_size, padding=1, dilation=1)
        self.branch2 = nn.Conv1d(input_dim, input_dim, kernel_size=kernel_size, padding=2, dilation=2)
        self.branch3 = nn.Conv1d(input_dim, input_dim, kernel_size=kernel_size, padding=3, dilation=3)

        self.relu = nn.ReLU()
        self.norm = nn.LayerNorm(input_dim)
        
        # LỚP CUỐI CÙNG được quyết định bởi cờ uncertainty
        if uncertainty:
            print(f"TridentRegHead for {num_classes} classes is using UNCERTAINTY head.")
            self.final_head = uncertainty_head(input_dim, num_classes, drop=drop)
        else:
            print(f"TridentRegHead for {num_classes} classes is using STANDARD head.")
            self.final_head = pred_head(input_dim, num_classes, sigmoid=False, drop=drop)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Tensor từ decoder, shape [batch_size, num_queries, embedding_dim]
        """
        x_permuted = x.permute(0, 2, 1)

        out1 = self.branch1(x_permuted)
        out2 = self.branch2(x_permuted)
        out3 = self.branch3(x_permuted)

        fused_out = self.relu((out1 + out2 + out3) / 3)

        fused_out = fused_out.permute(0, 2, 1)
        fused_out = self.norm(fused_out + x)

        # Cho qua lớp head cuối cùng
        return self.final_head(fused_out)
    
class Bfeat_module(nn.Module):
    def __init__(self, input_dim, output_dim, drop = 0.2):
        super().__init__()
        self.head = nn.Sequential(
                nn.Dropout(drop),
                nn.Linear(input_dim, input_dim),
                nn.ReLU(inplace=False),  
                nn.Dropout(drop),
                nn.Linear(input_dim, output_dim),
                nn.ReLU(inplace=False)  
        )
    def forward(self, x: torch.Tensor):
        return self.head(x)
class MEDet360(nn.Module):
    """
    Kiến trúc MEDet-style với 3 nhánh chuyên biệt cho bài toán Action Spotting.
    - Nhánh 1 (Local): CNN Encoder cho các hành động ngắn.
    - Nhánh 2 (Global): Transformer Encoder cho các hành động dài, có trình tự.
    - Nhánh 3 (Hybrid): CNN -> Transformer Encoder cho các hành động phức hợp.
    """
    def __init__(
        self,
        chunk_size = 8,
        n_output = 24, # Số lượng queries cho mỗi decoder
        baidu = True,
        audio = False,
        model_cfg = None,
    ):
        super().__init__()

        self.chunk_size = chunk_size
        self.n_output = n_output
        self.baidu = baidu
        self.audio = audio
        self.model_cfg = model_cfg
        self.num_total_classes = model_cfg.get('num_classes', 17)
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        self.use_adaptive_modulation = model_cfg.get('use_adaptive_modulation', False)

        # =====================================================================
        # 1. PHẦN TIỀN XỬ LÝ CHUNG (SHARED PRE-PROCESSING)
        # =====================================================================
        # Các phần này được giữ nguyên từ kiến trúc gốc của bạn
        if self.baidu:
            self.Bfeat_dim = [2048, 2048, 384, 2048, 2048]
            self.baidu_LL = nn.ModuleList([Bfeat_module(self.Bfeat_dim[i], model_cfg['dim'], drop = model_cfg['dropout']) for i in range(len(self.Bfeat_dim))])
            self.video_pos_encoder = PositionalEncoding(d_model=model_cfg['dim'])
            self.encFB = nn.Parameter(torch.rand(len(self.Bfeat_dim), model_cfg['dim']))
        
        if self.audio:
            self.vggish = torch.hub.load('harritaylor/torchvggish', 'vggish')
            self.vggish_features = self.vggish.features
            self.vggish_embeddings = self.vggish.embeddings
            self.vggish_embeddings[0] = nn.Linear(24576, 4096) # Giảm từ 4096 xuống 2048
            # Lớp self.vggish_embeddings[2] (nn.Linear(4096, 4096)) vẫn giữ nguyên
            # bạn cần thay đổi cả đầu vào của nó
            self.vggish_embeddings[2] = nn.Linear(4096, 2048)
            self.vggish_embeddings[4] = nn.Linear(2048, model_cfg['dim']) # Đầu vào cũng phải thay đổi
            self.encTA = nn.Parameter(torch.rand(self.chunk_size * 100 // 96, model_cfg['dim']))
            self.encA = nn.Parameter(torch.rand(model_cfg['dim']))
            del self.vggish
        
        self.fusion_unit = ConvGatedFusion(model_dim=model_cfg['dim'])
        
        self.use_text_gated_fusion = model_cfg.get('use_text_gated_fusion', False)
        if self.use_text_gated_fusion:
            print("Using text gated fusion")
            embedding_path = model_cfg.get('text_embedding_path', "/home/thiendc/projects/video_summarization/train_soccernet/label_embeddings.npy")
            try:
                # Tải embedding và đăng ký như một buffer (không học)
                text_embeddings = torch.from_numpy(np.load(embedding_path)).float()
                self.register_buffer('text_label_embeddings', text_embeddings)
            except FileNotFoundError:
                raise FileNotFoundError(f"Cannot find text embedding file: {embedding_path}")
                
            text_dim = text_embeddings.shape[-1]
            model_dim = model_cfg['dim']

            # 2. Lớp chiếu (Projection Layer)
            # Chiếu text embedding về chiều của mô 
            if text_dim == model_dim:
                self.text_proj = nn.Identity()
            else:
                self.text_proj = nn.Linear(text_dim, model_dim)

            # 3. Gating Mechanism
            # Đầu vào của gate là sự kết hợp của decoder_output và text_embedding
            # Nó sẽ học cách tạo ra một trọng số (gate value) cho mỗi query và mỗi class
            self.fusion_gate = nn.Sequential(
                nn.Linear(model_dim * 2, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, 1), # Ra một giá trị scalar cho mỗi cặp
                nn.Sigmoid() # Đưa giá trị về khoảng [0, 1]
            )
        
        self.use_adaptive_modulation = model_cfg.get('use_adaptive_modulation', False)
        if self.use_adaptive_modulation:
            print("Using Adaptive Modulation for Knowledge Fusion")
            # 1. Tải và ghép các embedding đối tượng ĐÃ ĐƯỢC AVERAGE POOLING
            red_card_embed = torch.from_numpy(np.load(model_cfg['red_card_embedding_path'])).float()
            yellow_card_embed = torch.from_numpy(np.load(model_cfg['yellow_card_embedding_path'])).float()
            goal_embed = torch.from_numpy(np.load(model_cfg['goal_embedding_path'])).float()
            referee_embed = torch.from_numpy(np.load(model_cfg['referee_embedding_path'])).float()
            # Ghép chúng lại thành một tensor duy nhất
            # Shape: [num_knowledge_classes, feature_dim]
            
            self.card_prototypes = nn.Parameter(torch.stack([red_card_embed, yellow_card_embed], dim=0), requires_grad=False)
            # Nhóm sự kiện bàn thắng (1 embedding)
            self.goal_prototype = nn.Parameter(goal_embed.unsqueeze(0), requires_grad=False)
            # Nhóm trọng tài (1 embedding)
            self.referee_prototype = nn.Parameter(referee_embed.unsqueeze(0), requires_grad=False)

            object_dim = red_card_embed.shape[-1]
            model_dim = model_cfg['dim']

            # Lớp chiếu chung cho tất cả các prototype
            self.knowledge_proj = nn.Linear(object_dim, model_dim) if object_dim != model_dim else nn.Identity()

            # --- Các bộ điều biến (Modulators) chuyên biệt ---
            # 1. Bộ điều biến cho thẻ phạt (sẽ được dùng trong nhánh Local)
            # Nó sẽ nhìn vào các query và tạo ra scale/shift cho 2 loại thẻ
            self.card_modulator = nn.Sequential(
                nn.Linear(model_dim, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, model_dim * 2 * 2) # *2 cho scale/shift, *2 cho 2 loại thẻ (red, yellow)
            )

            # 2. Bộ điều biến cho bàn thắng (sẽ được dùng trong nhánh Hybrid)
            self.goal_modulator = nn.Sequential(
                nn.Linear(model_dim, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, model_dim * 2) # *2 cho scale/shift
            )

            # 3. Bộ điều biến cho trọng tài (có thể dùng ở nhiều nhánh)
            self.referee_modulator = nn.Sequential(
                nn.Linear(model_dim, model_dim),
                nn.GELU(),
                nn.Linear(model_dim, model_dim * 2) # *2 cho scale/shift
            )

        if self.use_text_gated_fusion or self.use_adaptive_modulation:
            print("Initializing a shared post-fusion normalization layer.")
            self.post_fusion_norm = nn.LayerNorm(model_cfg['dim'])
        
        
        self.local_class_indices = [15, 16, 5, 6, 10, 7, 14]  # Thêm class 14 (2nd yellow card)
        self.global_class_indices = [11, 13, 0, 9, 8, 1, 3]
        self.hybrid_class_indices = [2, 4, 12]
        self.register_buffer('local_indices_tensor', torch.tensor(self.local_class_indices, dtype=torch.long))
        self.register_buffer('global_indices_tensor', torch.tensor(self.global_class_indices, dtype=torch.long))
        self.register_buffer('hybrid_indices_tensor', torch.tensor(self.hybrid_class_indices, dtype=torch.long))

        self.num_local_classes = len(self.local_class_indices)
        self.num_global_classes = len(self.global_class_indices)
        self.num_hybrid_classes = len(self.hybrid_class_indices)

        # --- NHÁNH 1: LOCAL (CNN-based) ---
        self.local_encoder = CNNEncoder(input_dim=model_cfg['dim'], num_layers=3, kernel_size=5)
        local_decoder_layer = nn.TransformerDecoderLayer(d_model=model_cfg['dim'], nhead=8, batch_first=True)
        self.local_decoder = nn.TransformerDecoder(local_decoder_layer, num_layers=model_cfg['TD_layers'])
        self.local_queries = nn.Parameter(torch.rand(self.n_output, model_cfg['dim']))
        self.local_clas_head = pred_head(model_cfg['dim'], self.num_local_classes, sigmoid=True)
        self.local_displ_head = TridentRegHead(model_cfg['dim'], self.num_local_classes, uncertainty= True, drop=model_cfg['dropout'])

        # --- NHÁNH 2: GLOBAL (Transformer-based) ---
        global_encoder_layer = nn.TransformerEncoderLayer(d_model=model_cfg['dim'], nhead=8, batch_first=True)
        self.global_encoder = nn.TransformerEncoder(global_encoder_layer, num_layers=model_cfg['TE_layers'])
        global_decoder_layer = nn.TransformerDecoderLayer(d_model=model_cfg['dim'], nhead=8, batch_first=True)
        self.global_decoder = nn.TransformerDecoder(global_decoder_layer, num_layers=model_cfg['TD_layers'])
        self.global_queries = nn.Parameter(torch.rand(self.n_output, model_cfg['dim']))
        self.global_clas_head = pred_head(model_cfg['dim'], self.num_global_classes, sigmoid=True)
        self.global_displ_head = TridentRegHead(model_cfg['dim'], self.num_global_classes, uncertainty= True, drop=model_cfg['dropout'])

        # --- NHÁNH 3: HYBRID (CNN -> Transformer) ---
        self.hybrid_cnn_encoder = CNNEncoder(input_dim=model_cfg['dim'], num_layers=2, kernel_size=3)
        hybrid_encoder_layer = nn.TransformerEncoderLayer(d_model=model_cfg['dim'], nhead=8, batch_first=True)
        self.hybrid_transformer_encoder = nn.TransformerEncoder(hybrid_encoder_layer, num_layers=model_cfg['TE_layers'] // 2) # Có thể dùng ít lớp hơn
        hybrid_decoder_layer = nn.TransformerDecoderLayer(d_model=model_cfg['dim'], nhead=8, batch_first=True)
        self.hybrid_decoder = nn.TransformerDecoder(hybrid_decoder_layer, num_layers=model_cfg['TD_layers'])
        self.hybrid_queries = nn.Parameter(torch.rand(self.n_output, model_cfg['dim']))
        self.hybrid_clas_head = pred_head(model_cfg['dim'], self.num_hybrid_classes, sigmoid=True)
        self.hybrid_displ_head = TridentRegHead(model_cfg['dim'], self.num_hybrid_classes, uncertainty= True, drop=model_cfg['dropout'])
        
        if model_cfg['feature_augmentation']:
            if self.baidu:
                self.temporal_dropB = temporal_dropM(p = model_cfg['temporal_drop_p'])
            if self.audio:
                self.temporal_dropA = temporal_dropM(p = model_cfg['temporal_drop_p'], dim = 128)
            self.random_switch = random_switchM(p = model_cfg['random_switch_p'])

        #Mixup queue system
        if model_cfg['mixup']:
            #Initialize queues (for labels and inputs)
            self.register_buffer('labelQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1))
            self.labelQ[:, :, :, 0] = 1
            self.register_buffer('labelDQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.n_output, model_cfg['num_classes'] + 1) + 1000)

            # Tính tổng feature dimension từ self.Bfeat_dim thay vì hard-code
            total_feat_dim = sum(self.Bfeat_dim) if self.baidu else 0
            self.register_buffer('featBQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size, total_feat_dim))
            if self.audio:
                self.register_buffer('featAQ', torch.zeros(model_cfg['num_classes'] + 1, model_cfg['mixup_nqueue'], self.chunk_size * 100, 128))
            else:
                self.featAQ = None

            self.do_mixup = mixupYolo(alpha = model_cfg['mixup_alpha'], beta = model_cfg['mixup_beta'])

    def _apply_knowledge_fusion(self, decoder_output, branch_name):
        """
        Hàm phụ trợ để áp dụng Text-Gated Fusion và Adaptive Modulation.
        Args:
            decoder_output: Đầu ra từ một trong các decoder.
            branch_name: Tên của nhánh ('local', 'global', 'hybrid').
        Returns:
            Tensor đầu ra đã được tăng cường.
        """
        if not self.use_text_gated_fusion and not self.use_adaptive_modulation:
            return decoder_output

        b, nq, d = decoder_output.shape
        adjustment = torch.zeros_like(decoder_output)

        # --- 1. Text-Gated Fusion (ĐÃ SỬA LỖI LOGIC) ---
        if self.use_text_gated_fusion:
            # Lấy chỉ số lớp dựa trên tên nhánh
            if branch_name == 'local': class_indices = self.local_indices_tensor
            elif branch_name == 'global': class_indices = self.global_indices_tensor
            else: class_indices = self.hybrid_indices_tensor
            
            relevant_text_embeds = self.text_label_embeddings.index_select(0, class_indices)
            projected_text = self.text_proj(relevant_text_embeds)
            num_branch_classes = projected_text.shape[0]

            # Mở rộng chiều của cả hai tensor để tạo ra mọi cặp (query, text_embedding)
            # decoder_output: [B, NQ, D] -> [B, NQ, 1, D] -> [B, NQ, N_Classes, D]
            decoder_expanded = decoder_output.unsqueeze(2).expand(-1, -1, num_branch_classes, -1)
            
            # projected_text: [N_Classes, D] -> [1, 1, N_Classes, D] -> [B, NQ, N_Classes, D]
            text_expanded = projected_text.unsqueeze(0).unsqueeze(0).expand(b, nq, -1, -1)
            
            # Bây giờ chúng có cùng shape và có thể được cat lại
            fusion_input = torch.cat((decoder_expanded, text_expanded), dim=-1)
            
            # Cho qua cổng để có trọng số
            gate_values = self.fusion_gate(fusion_input) # Shape: [B, NQ, N_Classes, 1]

            # Áp dụng Gating: Điều chỉnh thông tin text dựa trên gate
            gated_text_info = text_expanded * gate_values # Shape: [B, NQ, N_Classes, D]
            
            # Lấy trung bình thông tin text đã được "gated" trên tất cả các lớp
            # để tạo ra một vector điều chỉnh duy nhất cho mỗi query
            contextual_text_adjustment = gated_text_info.mean(dim=2) # Shape: [B, NQ, D]
            
            adjustment = adjustment + contextual_text_adjustment

        # --- 2. Adaptive Modulation (Áp dụng có chọn lọc) ---
        if self.use_adaptive_modulation:
            contextual_object_adjustment = torch.zeros_like(decoder_output)

            # A. Xử lý kiến thức Trọng tài (áp dụng cho Local & Hybrid)
            if branch_name in ['local', 'hybrid']:
                projected_referee = self.knowledge_proj(self.referee_prototype) # Shape: [1, D]
                modulation_params = self.referee_modulator(decoder_output).view(b, nq, 1, d * 2)
                scale, shift = modulation_params.chunk(2, dim=-1)
                modulated_referee = scale * projected_referee.view(1, 1, 1, d) + shift
                contextual_object_adjustment = contextual_object_adjustment + modulated_referee.squeeze(2)

            # B. Xử lý kiến thức Thẻ phạt (chỉ áp dụng cho nhánh Local)
            if branch_name == 'local':
                projected_cards = self.knowledge_proj(self.card_prototypes) # Shape: [2, D]
                modulation_params = self.card_modulator(decoder_output[:, :2, :]).view(b, 2, 2, d * 2)
                scale, shift = modulation_params.chunk(2, dim=-1)
                modulated_cards = scale * projected_cards.view(1, 1, 2, d) + shift
                contextual_object_adjustment[:, :2, :] = contextual_object_adjustment[:, :2, :] + modulated_cards.sum(dim=2)

            # C. Xử lý kiến thức Bàn thắng (chỉ áp dụng cho nhánh Hybrid)
            if branch_name == 'hybrid':
                projected_goal = self.knowledge_proj(self.goal_prototype) # Shape: [1, D]
                modulation_params = self.goal_modulator(decoder_output[:, 0, :]).view(b, 1, 1, d * 2)
                scale, shift = modulation_params.chunk(2, dim=-1)
                modulated_goal = scale * projected_goal.view(1, 1, 1, d) + shift
                contextual_object_adjustment[:, 0, :] = contextual_object_adjustment[:, 0, :] + modulated_goal.squeeze(1).squeeze(1)

            adjustment = adjustment + contextual_object_adjustment

        # --- 3. Kết hợp và chuẩn hóa ---
        fused_output = decoder_output + adjustment
        fused_output = self.post_fusion_norm(fused_output)
        return fused_output
    
    def forward(self, featsB, labels=None, labelsD=None, featsA=None, inference=False):
        """
        Hàm forward hoàn chỉnh cho kiến trúc MEDet360.
        - Xử lý đầu vào (Baidu, Audio, Mixup).
        - Chạy song song 3 nhánh encoder (Local, Global, Hybrid).
        - Chạy song song 3 nhánh decoder.
        - Áp dụng knowledge fusion (Text-Gated, Adaptive Modulation) cho từng nhánh.
        - Đưa ra dự đoán cuối cùng qua các prediction head.
        - Tính toán loss khi huấn luyện hoặc tổng hợp kết quả khi suy luận.
        """
        if featsB is not None:
            featsB = featsB.clone().float()
            b = len(featsB)
        if featsA is not None:
            featsA = featsA.clone().float()
        if labels is not None:
            labels = labels.clone().float()
        if labelsD is not None:
            labelsD = labelsD.clone().float()
        
        if self.baidu:
            featsB = featsB.float()
            b = len(featsB)
        use_audio_in_batch = self.audio and featsA is not None
        if use_audio_in_batch:   
            featsA = featsA.float()
        
        if self.model_cfg['mixup'] and (not inference):
            y = labels.clone()
            yD = labelsD.clone()
            if self.baidu:
                xB = featsB.clone()
            if use_audio_in_batch:
                xA = featsA.clone()

            featsB, featsA, labels, labelsD = self.do_mixup(featsB, self.featBQ, featsA, self.featAQ, labels, self.labelQ, labelsD, self.labelDQ)

            #Update mixup queue
            batch_action = (y[:, :, :] == 1).sum(1).nonzero() #(batch, action) pairs of clip with action
                
            for i in range(self.model_cfg['num_classes']+1):
                aux = batch_action[batch_action[:, 1] == i] #idxs containing action i

                if len(aux) >= self.model_cfg['mixup_nqueue']:
                    idx = aux[:self.model_cfg['mixup_nqueue'], 0] #keep first ones
                    self.labelQ[i, :] = y[idx].clone().detach()
                    self.labelDQ[i, :] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, :] = xB[idx].clone().detach()
                    if use_audio_in_batch:
                        self.featAQ[i, :] = xA[idx].clone().detach()

                elif len(aux) > 0:
                    # ✅ SỬA LỖI: Dùng device của tensor thay vì hard-code
                    idx1 = torch.randint(0, self.model_cfg['mixup_nqueue'], (len(aux),), device=y.device)
                    idx = aux[:, 0]
                    self.labelQ[i, idx1] = y[idx].clone().detach()
                    self.labelDQ[i, idx1] = yD[idx].clone().detach()
                    if self.baidu:
                        self.featBQ[i, idx1] = xB[idx].clone().detach()
                    if use_audio_in_batch:
                        self.featAQ[i, idx1] = xA[idx].clone().detach()
            # Clear temporary variables và cache
            del y, yD
            if self.baidu:
                del xB
            if use_audio_in_batch:
                del xA
            
            if torch.cuda.is_available(): torch.cuda.empty_cache()

        # --- 2. Feature Augmentation (chỉ khi huấn luyện) ---
        if self.model_cfg.get('feature_augmentation', False) and not inference:
            if self.baidu and featsB is not None:
                featsB = self.temporal_dropB(featsB)
                featsB = self.random_switch(featsB)
            if use_audio_in_batch and featsA is not None:
                # Augmentation hoạt động trên featsA thô (128-D)
                featsA = self.temporal_dropA(featsA)
                featsA = self.random_switch(featsA)
        
        featsB_list = [ll(featsB[:, :, int(sum(self.Bfeat_dim[:i])):int(sum(self.Bfeat_dim[:i+1]))]) for i, ll in enumerate(self.baidu_LL)]
        featsB_stacked = torch.stack(featsB_list, dim=0)
        l, b_local, cs, d = featsB_stacked.shape
        featsB_pe = self.video_pos_encoder(rearrange(featsB_stacked, 'l b cs d -> (l b) cs d'))
        featsB_pe = rearrange(featsB_pe, '(l b) cs d -> l b cs d', l=l)
        video_features = rearrange(featsB_pe, 'l b cs d -> b cs l d') + self.encFB.expand(b, cs, -1, -1)
        video_features = rearrange(video_features, 'b cs l d -> b (cs l) d')
        
        
        x = video_features # Bắt đầu với đặc trưng video đã xử lý
        
        #Audio features
        if use_audio_in_batch:
            fA = featsA.shape[1] // 96
            audio_reshaped = rearrange(featsA[:, :fA * 96, :], 'b (f ns) h -> (b f) 1 ns h', f=fA)
            audio_out_feat = self.vggish_features(audio_reshaped).flatten(1)
            audio_features_processed = self.vggish_embeddings(audio_out_feat)
            audio_features_processed = rearrange(audio_features_processed, '(b f) d -> b f d', f=fA)
            audio_features_processed = audio_features_processed + self.encTA[:audio_features_processed.shape[1]].unsqueeze(0) + self.encA.unsqueeze(0)
            
            # SỬA LỖI: Fusion `video_features` (trong 'x') và `audio_features_processed`
            x = self.fusion_unit(x, audio_features_processed) + x # Residual connection
        
        # --- Nhánh 1: Local ---
        memory_local = self.local_encoder(x)
        queries_local = self.local_queries.expand(b, -1, -1)
        decoder_out_local = self.local_decoder(queries_local, memory_local)
        fused_out_local = self._apply_knowledge_fusion(decoder_out_local, branch_name='local')
        preds_local = self.local_clas_head(fused_out_local)
        predsD_local = self.local_displ_head(fused_out_local)

        memory_global = self.global_encoder(x)
        queries_global = self.global_queries.expand(b, -1, -1)
        decoder_out_global = self.global_decoder(queries_global, memory_global)
        fused_out_global = self._apply_knowledge_fusion(decoder_out_global, branch_name='global')
        preds_global = self.global_clas_head(fused_out_global)
        predsD_global = self.global_displ_head(fused_out_global)

        hybrid_cnn_feats = self.hybrid_cnn_encoder(x)
        memory_hybrid = self.hybrid_transformer_encoder(hybrid_cnn_feats)
        queries_hybrid = self.hybrid_queries.expand(b, -1, -1)
        decoder_out_hybrid = self.hybrid_decoder(queries_hybrid, memory_hybrid)
        fused_out_hybrid = self._apply_knowledge_fusion(decoder_out_hybrid, branch_name='hybrid')
        preds_hybrid = self.hybrid_clas_head(fused_out_hybrid)
        predsD_hybrid = self.hybrid_displ_head(fused_out_hybrid)


        # =====================================================================
        #  PHẦN 3: TỔNG HỢP KẾT QUẢ ĐỂ TRẢ VỀ
        # =====================================================================
        output = {
            'preds': [preds_local, preds_global, preds_hybrid],
            'predsD': [predsD_local, predsD_global, predsD_hybrid]
        }
        
        if labels is not None and labelsD is not None:
            output['labels'] = [
                labels.index_select(2, self.local_indices_tensor),
                labels.index_select(2, self.global_indices_tensor),
                labels.index_select(2, self.hybrid_indices_tensor)
            ]
            output['labelsD'] = [
                labelsD.index_select(2, self.local_indices_tensor),
                labelsD.index_select(2, self.global_indices_tensor),
                labelsD.index_select(2, self.hybrid_indices_tensor)
            ]

        # <<< SỬA LỖI Ở ĐÂY >>>
        if inference:
            # Khởi tạo tensor đích với kiểu dữ liệu của tensor đầu vào `x`
            # Đây là thực hành tốt nhất để đảm bảo tính nhất quán
            dtype_dest = x.dtype
            device_dest = x.device
            full_preds = torch.zeros(b, self.n_output, self.num_total_classes, dtype=dtype_dest, device=device_dest)
            full_predsD = torch.zeros(b, self.n_output, self.num_total_classes, dtype=dtype_dest, device=device_dest)

            # Lấy ra các tensor dự đoán từ mỗi nhánh
            predsD_local_inf, predsD_global_inf, predsD_hybrid_inf = predsD_local, predsD_global, predsD_hybrid
            
            # Nếu đang bật uncertainty, chỉ lấy giá trị MEAN để đánh giá
            if self.model_cfg.get('uncertainty', False):
                predsD_local_inf = predsD_local[:, :, :, 0]
                predsD_global_inf = predsD_global[:, :, :, 0]
                predsD_hybrid_inf = predsD_hybrid[:, :, :, 0]

            # THỰC HIỆN SAO CHÉP MỘT CÁCH AN TOÀN
            # .to(dtype_dest) sẽ đảm bảo tensor nguồn luôn có cùng kiểu với tensor đích
            # Nếu chúng đã cùng kiểu, thao tác này rất nhanh.
            full_preds.index_copy_(2, self.local_indices_tensor, preds_local.to(dtype_dest))
            full_predsD.index_copy_(2, self.local_indices_tensor, predsD_local_inf.to(dtype_dest))

            full_preds.index_copy_(2, self.global_indices_tensor, preds_global.to(dtype_dest))
            full_predsD.index_copy_(2, self.global_indices_tensor, predsD_global_inf.to(dtype_dest))

            full_preds.index_copy_(2, self.hybrid_indices_tensor, preds_hybrid.to(dtype_dest))
            full_predsD.index_copy_(2, self.hybrid_indices_tensor, predsD_hybrid_inf.to(dtype_dest))
            
            output['full_preds'] = full_preds
            output['full_predsD'] = full_predsD
            if labels is not None:
                output['full_labels'] = labels
                output['full_labelsD'] = labelsD
                
        return output
class mixupYolo(torch.nn.Module):
    """
    Mixup module class
    """
    def __init__(self, alpha = 0.3, beta = 0.3):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

        self.betaD = torch.distributions.beta.Beta(alpha, beta)

            
    def forward(self, featB, featBQ, featA, featAQ, labels, labelsQ, labelsD, labelsDQ):
        #len of batch
        b = len(labels)
        classes = labels.shape[-1]

        #same lambda for all the batch
        lamb = self.betaD.sample()

        #Index of action and nqueue to do mixup
        idxa = torch.randint(0, classes, (b,))

        nqueue = featBQ.shape[1]
        idxnq = torch.randint(0, nqueue, (b,))

        #Mixture
        if featB != None:
            featB = featB * lamb + (1-lamb) * featBQ[idxa, idxnq]
        if featA != None:
            featA = featA * lamb + (1-lamb) * featAQ[idxa, idxnq]
        if labels != None:
            labels = labels * lamb + (1-lamb) * labelsQ[idxa, idxnq]
        if labelsD != None:
            labelsD = ((labelsD == 1000) & (labelsDQ[idxa, idxnq] == 1000)) * 1000 + ((labelsD == 1000) & (labelsDQ[idxa, idxnq] != 1000)) * labelsDQ[idxa, idxnq] + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] == 1000)) * labelsD + ((labelsD != 1000) & (labelsDQ[idxa, idxnq] != 1000)) * (labelsD * lamb + (1-lamb) * labelsDQ[idxa, idxnq])

        return featB, featA, labels, labelsD
        
# Augmentation modules
class temporal_dropM(nn.Module):
    def __init__(self, p = 0.0, dim = 8576):
        super().__init__()
        self.p = p
        self.embedding = nn.Parameter(torch.rand(dim))
        
    def forward(self, x: torch.Tensor):
        if not self.training or self.p == 0.0:
            return x
        x_aux = x.clone()  
        mask = torch.rand(x_aux.shape[1], device=x.device) < self.p
        x_aux[:, mask] = self.embedding.to(x.device) 
        return x_aux
    
class random_switchM(nn.Module):
    def __init__(self, p = 0.0):
        super().__init__()
        self.p = p
    
    def forward(self, x: torch.Tensor):
        if not self.training or self.p == 0.0:
            return x
        x_aux = x.clone()  
        idxs = torch.arange(x_aux.shape[1]-1, device=x.device)[torch.rand(x_aux.shape[1]-1, device=x.device) < self.p]
        if len(idxs) > 0:
            x_result = x_aux.clone()
            x_result[:, idxs, :] = x_aux[:, idxs+1, :].clone()
            x_result[:, idxs+1, :] = x_aux[:, idxs, :].clone()
            return x_result
        return x_aux

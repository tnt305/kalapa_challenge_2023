import torch
import torch.nn as nn
import torch.nn.functional as F

class NLLLoss(torch.nn.Module):
    def __init__(self):
        super(NLLLoss, self).__init__()
    
    # def forward(self, labels, output):
    #     # return torch.mean(labels * -torch.log(output) + (1 - labels) * -torch.log(1 - output))

    #     return torch.mean(torch.mean(labels * -torch.log(output) + (1 - labels) * -torch.log(1 - output)))
    def forward(self, output, labels): 
        # output: probabilities đã sigmoid [0,1]
        # labels: binary labels [0,1]
        eps = 1e-8
        output = torch.clamp(output, eps, 1 - eps)  # Tránh log(0)
        return torch.mean(labels * -torch.log(output) + (1 - labels) * -torch.log(1 - output))
    

class FocalLoss(nn.Module):
    def __init__(self, gamma: float = 2.0, alpha: float = 1.0, reduction: str = 'mean'):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, output, targets):
        # Convert to float32 if needed
        targets = targets.float()
        
        """
        output: (batch_size, num_classes) - probabilities đã sigmoid [0,1] 
        targets: (batch_size, num_classes) - nhãn 0/1
        """
        probas = output  # Đã sigmoid rồi
        eps = 1e-8
        probas = torch.clamp(probas, eps, 1 - eps)
        
        ce_loss = F.binary_cross_entropy(probas, targets, reduction='mean')
        p_t = probas * targets + (1 - probas) * (1 - targets)
        alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        focal_loss = alpha_t * (1 - p_t) ** self.gamma * ce_loss

        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss
        
import torch
import torch.nn.functional as F
from torch import nn


class LogLikelihoodLoss(torch.nn.Module):
    """
    Class to compute the loglikelihood loss (displacement loss uncertaint-aware)
    """
    def __init__(self, alpha = 0.6, beta = 0.4):
        super(LogLikelihoodLoss, self).__init__()
        self.alpha = alpha
        self.beta = 1 - alpha

    def forward(self, labelsD, predictionsD):
        '''
        labelsD: b x 18
        predictionsD: b x 2 (with mean in 0 and logvar in 1)
        '''

        rec_loss = self.alpha * (labelsD - predictionsD[:, 0])**2 / (predictionsD[:, 1].exp())
        sup_loss = self.beta * predictionsD[:, 1]
        return rec_loss+sup_loss

class ASTRALoss(torch.nn.Module):
    """
    Class to compute the ASTRA loss (classification + displacement)
    """
    def __init__(self, wC = 1, wD = 1, focal = False, nw = 7, uncertainty = False, uncertainty_mode = 'mse', gamma = 1):
        super(ASTRALoss, self).__init__()

        self.wC = wC
        self.wD = wD
        self.maxpool = nn.MaxPool2d((nw, 1), stride = (1, 1), padding = (nw//2, 0))
        self.uncertainty = uncertainty
        self.uncertainty_mode = uncertainty_mode
        if self.uncertainty & (self.uncertainty_mode == 'loglikelihood'):
            self.loglikelihood = LogLikelihoodLoss(alpha = 0.3)
        self.focal = focal
        self.gamma = gamma
    def forward(self, labels, predictions, labelsD = None, predictionsD = None):

        b, nf, nc = labels.shape #b x cs*fr+1 x 18

        #Classification loss
        if self.focal:
            lossC = - torch.log(predictions + 7e-05) * labels * (labels - predictions).abs()**self.gamma - torch.log(1 - predictions + 7e-05) * (1 - labels) * (labels - predictions).abs()**self.gamma 
        else:
            lossC = - torch.log(predictions + 7e-05) * labels - torch.log(1 - predictions + 7e-05) * (1 - labels)
        lossC = lossC.mean() * self.wC

        #Displacement loss
        if len(labelsD[labelsD != 1000]) == 0:
            lossD = torch.tensor(0, device = 'cuda')
        else:
            labels_aux = self.maxpool(labels) #auxiliar labels to weight displacement loss by the probability of the class
            if self.uncertainty & (self.uncertainty_mode == 'loglikelihood'):
                lossD = (self.loglikelihood(labelsD[labelsD != 1000], predictionsD[labelsD != 1000]) * labels_aux[labelsD != 1000]).sum() / (b * nf)
            else:
                lossD = ((labelsD[labelsD != 1000] - predictionsD[labelsD != 1000]).pow(2) * labels_aux[labelsD != 1000]).sum() / (b * nf)
            lossD = lossD * self.wD

        return lossC, lossD


class ASTRALoss_v2(torch.nn.Module):
    def __init__(self, wC = 1, wD = 1, focal = False, nw = 7, uncertainty = False, uncertainty_mode = 'mse', gamma = 1):
        super(ASTRALoss_v2, self).__init__()

        self.wC = wC
        self.wD = wD
        self.maxpool = nn.MaxPool2d((nw, 1), stride = (1, 1), padding = (nw//2, 0))
        self.uncertainty = uncertainty
        self.uncertainty_mode = uncertainty_mode
        if self.uncertainty and (self.uncertainty_mode == 'loglikelihood'):
            self.loglikelihood = LogLikelihoodLoss(alpha = 0.3)
        self.focal = focal
        self.gamma = gamma

    def forward(self, labels, predictions, labelsD=None, predictionsD=None):
        b, nf, nc = labels.shape

        # Classification loss (giữ nguyên)
        if self.focal:
            lossC = - torch.log(predictions + 7e-05) * labels * (labels - predictions).abs()**self.gamma - torch.log(1 - predictions + 7e-05) * (1 - labels) * (labels - predictions).abs()**self.gamma
        else:
            lossC = - torch.log(predictions + 7e-05) * labels - torch.log(1 - predictions + 7e-05) * (1 - labels)
        lossC = lossC.mean() * self.wC

        # Displacement loss
        # Tạo mask cho các vị trí có nhãn hợp lệ
        valid_mask = (labelsD != 1000)

        if not valid_mask.any(): # Nếu không có nhãn hợp lệ nào
            lossD = torch.tensor(0.0, device=labels.device)
        else:
            labels_aux = self.maxpool(labels)
            
            # Lấy ra các giá trị tại vị trí hợp lệ
            valid_labelsD = labelsD[valid_mask]
            valid_labels_aux = labels_aux[valid_mask]

            if self.uncertainty and (self.uncertainty_mode == 'loglikelihood'):
                # Lọc predictionsD bằng cùng mask, nó sẽ giữ nguyên chiều cuối cùng
                valid_predictionsD = predictionsD[valid_mask] # Shape: [N, 2]
                
                # Truyền các tensor đã lọc vào loglikelihood
                # Giả sử self.loglikelihood đã được khởi tạo
                # likelihood_loss = self.loglikelihood(valid_labelsD, valid_predictionsD)
                
                # *** GIẢ SỬ LOGIC CỦA LOGLIKELIHOODLOSS LÀ ĐÚNG ***
                # Đây là logic tính toán chính xác
                mean_pred = valid_predictionsD[:, 0]
                log_var_pred = valid_predictionsD[:, 1]
                # Công thức loss cho Gaussian Log-Likelihood
                likelihood_loss = 0.5 * (torch.exp(-log_var_pred) * (valid_labelsD - mean_pred).pow(2) + log_var_pred)

                lossD = (likelihood_loss * valid_labels_aux).sum() / (b * nf)
            else:
                # Xử lý cho trường hợp không có uncertainty hoặc uncertainty_mode='mse'
                valid_predictionsD = predictionsD[valid_mask]
                
                # Nếu có uncertainty nhưng dùng mse, chỉ lấy mean
                if self.uncertainty:
                    valid_predictionsD = valid_predictionsD[:, 0]

                lossD = ((valid_labelsD - valid_predictionsD).pow(2) * valid_labels_aux).sum() / (b * nf)
            
            lossD = lossD * self.wD

        return lossC, lossD